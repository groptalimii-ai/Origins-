import React from 'react'
import { useQuery } from 'react-query'
import { UsersIcon } from '@heroicons/react/24/outline'
import { api } from '../lib/api'
import { formatCurrency, formatDate, formatPercent } from '../lib/format'
import DataTable from '../components/DataTable'
import AgentPanel from '../components/AgentPanel'

interface Employee {
  id: string
  full_name: string
  department: string | null
  position: string | null
  salary: number | null
  performance_score: number | null
  hire_date: string | null
  is_active: boolean
}

interface AtRiskEmployee {
  id: string
  name: string
  risk_score: number
  reason: 'low_engagement' | 'compensation_gap' | null
}

const REASON_LABEL: Record<string, string> = {
  low_engagement: 'انخفاض الأداء/الانخراط',
  compensation_gap: 'فجوة تعويضية عن متوسط القسم',
}

const HR: React.FC = () => {
  const { data: employees, isLoading, isError } = useQuery(
    'hr-employees',
    async () => (await api.get<Employee[]>('/hr/employees')).data
  )

  const activeCount = (employees ?? []).filter((e) => e.is_active).length

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white mb-2">الموارد البشرية</h1>
        <p className="text-gray-400">فريق العمل، مخاطر الاستبقاء، وفرز المرشحين بالذكاء الاصطناعي</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 hover-glow">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary-500/10 rounded-lg"><UsersIcon className="w-6 h-6 text-primary-400" /></div>
            <div>
              <p className="text-sm text-gray-400">إجمالي الموظفين</p>
              <p className="text-xl font-bold text-white">{employees?.length ?? 0}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-6 hover-glow">
          <p className="text-sm text-gray-400 mb-1">نشطون حالياً</p>
          <p className="text-xl font-bold text-white">{activeCount}</p>
        </div>
        <div className="glass-card p-6 hover-glow">
          <p className="text-sm text-gray-400 mb-1">الأقسام</p>
          <p className="text-xl font-bold text-white">
            {new Set((employees ?? []).map((e) => e.department).filter(Boolean)).size}
          </p>
        </div>
      </div>

      <AgentPanel
        title="تحليل مخاطر الاستبقاء"
        description="يحسب درجة مخاطرة استقالة حقيقية لكل موظف بمقارنة الأداء والتعويض بمتوسط قسمه"
        endpoint="/hr/ai/retention-analysis"
        minRole="manager"
        buttonLabel="تحليل المخاطر"
        renderResult={(result) => {
          // نقطة تحويل واحدة صريحة ومُبرَّرة من unknown إلى الأنواع المتوقَّعة فعلياً -
          // نفس المبرر المذكور في Finance.tsx (حدود API/UI هي المكان الصحيح الوحيد
          // لـ cast صريح، بدل تسرّب any ضمنياً عبر الملف).
          const atRisk = (result.at_risk_employees as AtRiskEmployee[] | undefined) ?? []
          const overallTurnover = result.overall_turnover_prediction as number | undefined
          const costOfTurnover = result.cost_of_turnover as number | undefined
          return (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-6 text-sm">
                <span className="text-gray-400">
                  معدل الاستقالة المتوقع: <span className="text-white font-medium">{formatPercent(overallTurnover, 1)}</span>
                </span>
                <span className="text-gray-400">
                  الكلفة التقديرية للاستبدال: <span className="text-white font-medium">{formatCurrency(costOfTurnover)}</span>
                </span>
              </div>
              {atRisk.length > 0 ? (
                <div className="space-y-2">
                  {atRisk.map((e) => (
                    <div key={e.id} className="flex items-center gap-3 p-2.5 bg-white/5 rounded-lg">
                      <span className="text-sm text-white flex-1">{e.name}</span>
                      <span className="text-xs text-gray-500">{e.reason ? REASON_LABEL[e.reason] : '—'}</span>
                      <div className="w-24 bg-white/10 rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full ${e.risk_score > 0.6 ? 'bg-red-500' : 'bg-yellow-500'}`}
                          style={{ width: `${Math.min(100, e.risk_score * 100)}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-400 w-10 text-left">{formatPercent(e.risk_score, 0)}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">لا يوجد موظفون بمخاطر استقالة ملحوظة حالياً.</p>
              )}
            </div>
          )
        }}
      />

      <AgentPanel
        title="فرز المرشحين"
        description="يقيس أداء القسم الحالي كخط أساس لفرز المرشحين الجدد"
        endpoint="/hr/ai/recruitment-screening"
        minRole="manager"
      />

      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold text-white mb-4">فريق العمل</h3>
        <DataTable
          columns={[
            { header: 'الاسم', accessor: (r: Employee) => r.full_name },
            { header: 'القسم', accessor: (r: Employee) => r.department ?? '—' },
            { header: 'المنصب', accessor: (r: Employee) => r.position ?? '—' },
            { header: 'الراتب', accessor: (r: Employee) => (r.salary != null ? formatCurrency(r.salary) : '—') },
            {
              header: 'الأداء',
              accessor: (r: Employee) =>
                r.performance_score != null ? (
                  <span className={r.performance_score < 0.6 ? 'text-yellow-400' : 'text-green-400'}>
                    {formatPercent(r.performance_score, 0)}
                  </span>
                ) : (
                  '—'
                ),
            },
            { header: 'تاريخ التعيين', accessor: (r: Employee) => formatDate(r.hire_date) },
            {
              header: 'الحالة',
              accessor: (r: Employee) =>
                r.is_active ? <span className="text-green-400">نشط</span> : <span className="text-gray-500">غير نشط</span>,
            },
          ]}
          rows={employees}
          isLoading={isLoading}
          isError={isError}
          keyField={(r) => r.id}
          emptyMessage="لا يوجد موظفون مسجّلون بعد"
        />
      </div>
    </div>
  )
}

export default HR
