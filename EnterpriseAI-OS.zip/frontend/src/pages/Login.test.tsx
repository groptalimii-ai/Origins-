import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import Login from '../pages/Login'
import { api } from '../lib/api'
import { useAuthStore } from '../store/auth'

// إصلاح: لم يكن يوجد أي اختبار frontend إطلاقًا في المشروع (لا حتى إعداد vitest
// يعمل فعليًا). هذا أول اختبار حقيقي يغطي أهم مكوّن أُضيف في إصلاح المصادقة:
// صفحة تسجيل الدخول ومسارها الناجح والفاشل.

vi.mock('../lib/api', () => ({
  api: {
    post: vi.fn(),
    get: vi.fn(),
  },
}))

describe('Login page', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    useAuthStore.setState({ accessToken: null, refreshToken: null, user: null })
  })

  it('يعرض حقول البريد وكلمة المرور وزر الدخول', () => {
    render(
      <MemoryRouter>
        <Login />
      </MemoryRouter>
    )

    expect(screen.getByText(/تسجيل الدخول/i)).toBeInTheDocument()
    expect(screen.getByText('البريد الإلكتروني')).toBeInTheDocument()
    expect(screen.getByText('كلمة المرور')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /دخول/i })).toBeInTheDocument()
  })

  it('عند نجاح الدخول يحفظ التوكن في مخزن المصادقة', async () => {
    const user = userEvent.setup()

    vi.mocked(api.post).mockResolvedValueOnce({
      data: { access_token: 'fake-access-token', refresh_token: 'fake-refresh-token' },
    })
    vi.mocked(api.get).mockResolvedValueOnce({
      data: { email: 'test@example.com', name: 'Test User', role: 'analyst' },
    })

    render(
      <MemoryRouter>
        <Login />
      </MemoryRouter>
    )

    const emailInput = document.querySelector('input[type="email"]') as HTMLInputElement
    const passwordInput = document.querySelector('input[type="password"]') as HTMLInputElement

    await user.type(emailInput, 'test@example.com')
    await user.type(passwordInput, 'SomePassword123!')
    await user.click(screen.getByRole('button', { name: /دخول/i }))

    await waitFor(() => {
      expect(useAuthStore.getState().accessToken).toBe('fake-access-token')
    })
    expect(useAuthStore.getState().user?.email).toBe('test@example.com')
  })

  it('عند فشل الدخول يعرض رسالة خطأ ولا يحفظ أي توكن', async () => {
    const user = userEvent.setup()

    vi.mocked(api.post).mockRejectedValueOnce({
      response: { data: { detail: 'بيانات دخول غير صحيحة' } },
    })

    render(
      <MemoryRouter>
        <Login />
      </MemoryRouter>
    )

    const emailInput = document.querySelector('input[type="email"]') as HTMLInputElement
    const passwordInput = document.querySelector('input[type="password"]') as HTMLInputElement

    await user.type(emailInput, 'wrong@example.com')
    await user.type(passwordInput, 'WrongPassword')
    await user.click(screen.getByRole('button', { name: /دخول/i }))

    await waitFor(() => {
      expect(screen.getByText('بيانات دخول غير صحيحة')).toBeInTheDocument()
    })
    expect(useAuthStore.getState().accessToken).toBeNull()
  })
})
