import React, { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { api, getApiErrorDetail } from '../lib/api'
import { useAuthStore } from '../store/auth'

/**
 * إصلاح: لم تكن توجد أي صفحة تسجيل دخول في المشروع سابقاً رغم أن كل
 * الـ backend (JWT + MFA) جاهز فعلياً - كان لا توجد وسيلة على الإطلاق
 * للحصول على توكن من الواجهة الأمامية.
 */
const Login: React.FC = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mfaCode, setMfaCode] = useState('')
  const [needsMfa, setNeedsMfa] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const login = useAuthStore((s) => s.login)
  const navigate = useNavigate()
  const location = useLocation()
  const from = (location.state as { from?: string })?.from || '/'

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      const { data } = await api.post('/auth/login', {
        email,
        password,
        mfa_code: mfaCode || undefined,
      })
      const me = await api.get('/auth/me', {
        headers: { Authorization: `Bearer ${data.access_token}` },
      })
      login(data.access_token, data.refresh_token, {
        email: me.data.email,
        name: me.data.name,
        role: me.data.role,
      })
      navigate(from, { replace: true })
    } catch (err: unknown) {
      const detail = getApiErrorDetail(err)
      if (typeof detail === 'string' && detail.toLowerCase().includes('mfa')) {
        setNeedsMfa(true)
        setError('مطلوب رمز التحقق الثنائي (MFA)')
      } else {
        setError(detail || 'فشل تسجيل الدخول - تحقق من البريد الإلكتروني وكلمة المرور')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex h-screen items-center justify-center bg-enterprise-dark">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-lg bg-slate-800 p-8 shadow-xl"
        dir="rtl"
      >
        <h1 className="mb-6 text-center text-xl font-bold text-white">
          EnterpriseAI-OS — تسجيل الدخول
        </h1>

        {error && (
          <div className="mb-4 rounded bg-red-900/50 p-3 text-sm text-red-200">{error}</div>
        )}

        <label className="mb-1 block text-sm text-slate-300">البريد الإلكتروني</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mb-4 w-full rounded border border-slate-600 bg-slate-900 p-2 text-white"
        />

        <label className="mb-1 block text-sm text-slate-300">كلمة المرور</label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mb-4 w-full rounded border border-slate-600 bg-slate-900 p-2 text-white"
        />

        {needsMfa && (
          <>
            <label className="mb-1 block text-sm text-slate-300">رمز التحقق الثنائي</label>
            <input
              type="text"
              value={mfaCode}
              onChange={(e) => setMfaCode(e.target.value)}
              className="mb-4 w-full rounded border border-slate-600 bg-slate-900 p-2 text-white"
            />
          </>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded bg-blue-600 p-2 font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'جارٍ الدخول...' : 'دخول'}
        </button>
      </form>
    </div>
  )
}

export default Login
