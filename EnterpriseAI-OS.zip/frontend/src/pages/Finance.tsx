import React from 'react'
import { useQuery } from 'react-query'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { BanknotesIcon, ArrowUpCircleIcon, ArrowDownCircleIcon } from '@heroicons/react/24/outline'
import { api } from '../lib/api'
import { formatCurrency, formatDate } from '../lib/format'
import DataTable from '../components/DataTable'
import AgentPanel from '../components/AgentPanel'

interface Transaction {
  id: string
  date: string
  amount: number
  type: 'income' | 'expense'
  category: string | null
  vendor: string | null
  department: string | null
  is_flagged: boolean
}

interface BudgetRow {
  id: string
  department: string
  period: string
  allocated: number
  spent: number
}

const Finance: React.FC = () => {
  const { data: transactions, isLoading: txLoading, isError: txError } = useQuery(
    'finance-transactions',
    async () => (await api.get<Transaction[]>('/finance/transactions?limit=25')).data
  )

  const { data: budgets, isLoading: budgetLoading, isError: budgetError } = useQuery(
    'finance-budgets',
    async () => (await api.get<BudgetRow[]>('/finance/budgets')).data
  )

  const income = (transactions ?? []).filter((t) => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0)
  const expense = (transactions ?? []).filter((t) => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white mb-2">المالية</h1>
        <p className="text-gray-400">التدفق النقدي، الميزانيات، والتحليل المالي المدعوم بالذكاء الاصطناعي</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 hover-glow">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary-500/10 rounded-lg"><BanknotesIcon className="w-6 h-6 text-primary-400" /></div>
            <div>
              <p className="text-sm text-gray-400">صافي آخر 25 معاملة</p>
              <p className="text-xl font-bold text-white">{formatCurrency(income - expense)}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-6 hover-glow">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-500/10 rounded-lg"><ArrowUpCircleIcon className="w-6 h-6 text-green-400" /></div>
            <div>
              <p className="text-sm text-gray-400">إجمالي الدخل</p>
              <p className="text-xl font-bold text-white">{formatCurrency(income)}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-6 hover-glow">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-red-500/10 rounded-lg"><ArrowDownCircleIcon className="w-6 h-6 text-red-400" /></div>
            <div>
              <p className="text-sm text-gray-400">إجمالي المصروفات</p>
              <p className="text-xl font-bold text-white">{formatCurrency(expense)}</p>
            </div>
          </div>
        </div>
      </div>

      <AgentPanel
        title="تنبؤ التدفق النقدي"
        description="يبني نموذج Prophet على 5 سنوات من معاملات الدخل الفعلية للتنبؤ بـ 90 يوماً قادمة"
        endpoint="/finance/ai/cash-flow-forecast"
        minRole="analyst"
        buttonLabel="تشغيل التنبؤ"
        renderResult={(result) => {
          // نقطة تحويل واحدة صريحة ومُبرَّرة من unknown (حدود استجابة JSON الديناميكية
          // من الـ backend) إلى النوع المتوقَّع فعلياً - بدل تسرّب any ضمنياً عبر كل
          // الملف. هذا هو المكان الصحيح الوحيد المقبول لـ cast صريح: حدود API/UI.
          const trend = (result.trend as number[] | undefined) ?? []
          if (trend.length === 0) return null
          const chartData = trend.map((v, i) => ({ day: i, value: v }))
          return (
            <div className="h-56 -mx-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="cashflow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="day" stroke="#64748b" fontSize={12} tickFormatter={(v) => `يوم ${v}`} />
                  <YAxis stroke="#64748b" fontSize={12} width={70} tickFormatter={(v) => formatCurrency(v)} />
                  <Tooltip
                    contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8 }}
                    labelFormatter={(v) => `يوم ${v}`}
                    formatter={(v: number) => [formatCurrency(v), 'الاتجاه']}
                  />
                  <Area type="monotone" dataKey="value" stroke="#3b82f6" fill="url(#cashflow)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )
        }}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AgentPanel
          title="تحسين الميزانية"
          description="يحلّل بيانات الميزانيات الفعلية عبر الأقسام ويقترح إعادة توزيع"
          endpoint="/finance/ai/budget-optimization"
          minRole="manager"
        />
        <AgentPanel
          title="تحليل المصروفات"
          description="يكشف الأنماط الشاذة في المصروفات المسجّلة فعلياً"
          endpoint="/finance/ai/expense-analysis"
          minRole="analyst"
        />
      </div>

      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold text-white mb-4">المعاملات الأخيرة</h3>
        <DataTable
          columns={[
            { header: 'التاريخ', accessor: (r: Transaction) => formatDate(r.date) },
            {
              header: 'النوع',
              accessor: (r: Transaction) => (
                <span className={r.type === 'income' ? 'text-green-400' : 'text-red-400'}>
                  {r.type === 'income' ? 'دخل' : 'مصروف'}
                </span>
              ),
            },
            { header: 'المبلغ', accessor: (r: Transaction) => formatCurrency(r.amount) },
            { header: 'الفئة', accessor: (r: Transaction) => r.category ?? '—' },
            { header: 'المورد/الجهة', accessor: (r: Transaction) => r.vendor ?? '—' },
            { header: 'القسم', accessor: (r: Transaction) => r.department ?? '—' },
            {
              header: 'الحالة',
              accessor: (r: Transaction) =>
                r.is_flagged ? <span className="text-yellow-400">⚠️ مُعلَّمة</span> : <span className="text-gray-500">عادية</span>,
            },
          ]}
          rows={transactions}
          isLoading={txLoading}
          isError={txError}
          keyField={(r) => r.id}
          emptyMessage="لا توجد معاملات مسجّلة بعد"
        />
      </div>

      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold text-white mb-4">الميزانيات حسب القسم</h3>
        <DataTable
          columns={[
            { header: 'القسم', accessor: (r: BudgetRow) => r.department },
            { header: 'الفترة', accessor: (r: BudgetRow) => r.period },
            { header: 'المخصَّص', accessor: (r: BudgetRow) => formatCurrency(r.allocated) },
            { header: 'المُنفَق', accessor: (r: BudgetRow) => formatCurrency(r.spent) },
            {
              header: 'نسبة الاستهلاك',
              accessor: (r: BudgetRow) => {
                const pct = r.allocated ? Math.min(100, (Number(r.spent) / Number(r.allocated)) * 100) : 0
                return (
                  <div className="w-32 bg-white/10 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${pct > 90 ? 'bg-red-500' : pct > 70 ? 'bg-yellow-500' : 'bg-green-500'}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                )
              },
            },
          ]}
          rows={budgets}
          isLoading={budgetLoading}
          isError={budgetError}
          keyField={(r) => r.id}
          emptyMessage="لا توجد ميزانيات مسجّلة بعد"
        />
      </div>
    </div>
  )
}

export default Finance
