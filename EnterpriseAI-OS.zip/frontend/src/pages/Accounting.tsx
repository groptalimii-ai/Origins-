import React from 'react'
import { useQuery } from 'react-query'
import { ClipboardDocumentCheckIcon } from '@heroicons/react/24/outline'
import { api } from '../lib/api'
import { formatCurrency, formatDate } from '../lib/format'
import DataTable from '../components/DataTable'
import AgentPanel from '../components/AgentPanel'

interface Invoice {
  id: string
  invoice_number: string
  customer_name: string
  amount: number
  status: 'pending' | 'paid' | 'overdue'
  due_date: string | null
  issued_at: string
}

const STATUS_STYLE: Record<string, string> = {
  paid: 'bg-green-500/10 text-green-400',
  pending: 'bg-yellow-500/10 text-yellow-400',
  overdue: 'bg-red-500/10 text-red-400',
}

const STATUS_LABEL: Record<string, string> = {
  paid: 'مدفوعة',
  pending: 'معلّقة',
  overdue: 'متأخرة',
}

const Accounting: React.FC = () => {
  const { data: invoices, isLoading, isError } = useQuery(
    'accounting-invoices',
    async () => (await api.get<Invoice[]>('/accounting/invoices')).data
  )

  const totals = (invoices ?? []).reduce(
    (acc, inv) => {
      acc.total += Number(inv.amount)
      if (inv.status === 'overdue') acc.overdue += Number(inv.amount)
      return acc
    },
    { total: 0, overdue: 0 }
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white mb-2">المحاسبة</h1>
        <p className="text-gray-400">دفتر الفواتير، القيود اليومية، والتسويات البنكية</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 hover-glow">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary-500/10 rounded-lg"><ClipboardDocumentCheckIcon className="w-6 h-6 text-primary-400" /></div>
            <div>
              <p className="text-sm text-gray-400">عدد الفواتير</p>
              <p className="text-xl font-bold text-white">{invoices?.length ?? 0}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-6 hover-glow">
          <p className="text-sm text-gray-400 mb-1">إجمالي قيمة الفواتير</p>
          <p className="text-xl font-bold text-white">{formatCurrency(totals.total)}</p>
        </div>
        <div className="glass-card p-6 hover-glow">
          <p className="text-sm text-gray-400 mb-1">فواتير متأخرة</p>
          <p className="text-xl font-bold text-red-400">{formatCurrency(totals.overdue)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AgentPanel
          title="إنشاء قيد يومية"
          description="يصنّف المعاملة على دليل الحسابات ويتحقق من توازن المدين/الدائن تلقائياً"
          endpoint="/accounting/ai/journal-entry"
          minRole="analyst"
        />
        <AgentPanel
          title="تسوية بنكية"
          description="يطابق كشف الحساب البنكي مع دفتر الأستاذ ويحدد الفروقات فعلياً"
          endpoint="/accounting/ai/reconciliation"
          minRole="manager"
        />
      </div>

      <div className="glass-card p-6">
        <h3 className="text-lg font-semibold text-white mb-4">الفواتير</h3>
        <DataTable
          columns={[
            { header: 'رقم الفاتورة', accessor: (r: Invoice) => r.invoice_number },
            { header: 'العميل', accessor: (r: Invoice) => r.customer_name },
            { header: 'المبلغ', accessor: (r: Invoice) => formatCurrency(r.amount) },
            {
              header: 'الحالة',
              accessor: (r: Invoice) => (
                <span className={`px-2 py-1 rounded-md text-xs ${STATUS_STYLE[r.status] ?? ''}`}>
                  {STATUS_LABEL[r.status] ?? r.status}
                </span>
              ),
            },
            { header: 'تاريخ الاستحقاق', accessor: (r: Invoice) => formatDate(r.due_date) },
            { header: 'تاريخ الإصدار', accessor: (r: Invoice) => formatDate(r.issued_at) },
          ]}
          rows={invoices}
          isLoading={isLoading}
          isError={isError}
          keyField={(r) => r.id}
          emptyMessage="لا توجد فواتير مسجّلة بعد"
        />
      </div>
    </div>
  )
}

export default Accounting
