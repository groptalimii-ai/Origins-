import React, { useState } from 'react'
import { useMutation } from 'react-query'
import {
  SparklesIcon,
  ExclamationTriangleIcon,
  LightBulbIcon,
  ShieldExclamationIcon,
  LockClosedIcon,
} from '@heroicons/react/24/outline'
import { api, getApiErrorMessage } from '../lib/api'
import { useAuthStore } from '../store/auth'
import { hasMinRole, ROLE_LABELS } from '../lib/roles'

interface AgentResponse {
  task_id: string
  agent: string
  status: string
  confidence: number
  explanation: string
  result: Record<string, unknown>
  insights: string[]
  recommendations: string[]
  warnings: string[]
  processing_time: number
}

interface AgentPanelProps {
  title: string
  description: string
  endpoint: string
  minRole: string
  buttonLabel?: string
  /** بيانات إضافية تُرسَل مع الطلب (مثال: {sku: 'X'}) */
  payload?: Record<string, unknown>
  /** عرض مخصص لمحتوى result بعد نجاح التنفيذ - إن لم يُمرَّر، تُعرض insights/recommendations فقط */
  renderResult?: (result: Record<string, unknown>) => React.ReactNode
}

const AgentPanel: React.FC<AgentPanelProps> = ({
  title,
  description,
  endpoint,
  minRole,
  buttonLabel = 'تشغيل التحليل',
  payload,
  renderResult,
}) => {
  const user = useAuthStore((s) => s.user)
  const [response, setResponse] = useState<AgentResponse | null>(null)
  const allowed = hasMinRole(user?.role, minRole)

  const mutation = useMutation(
    async () => {
      const { data } = await api.post<AgentResponse>(endpoint, payload ?? {})
      return data
    },
    { onSuccess: (data) => setResponse(data) }
  )

  return (
    <div className="glass-card p-6">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <SparklesIcon className="w-5 h-5 text-primary-400" />
            {title}
          </h3>
          <p className="text-sm text-gray-400 mt-1">{description}</p>
        </div>
        {allowed ? (
          <button
            onClick={() => mutation.mutate()}
            disabled={mutation.isLoading}
            className="shrink-0 px-4 py-2 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2"
          >
            {mutation.isLoading ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                جاري التحليل...
              </>
            ) : (
              buttonLabel
            )}
          </button>
        ) : (
          <div className="shrink-0 flex items-center gap-1.5 px-3 py-2 bg-white/5 rounded-lg text-xs text-gray-500">
            <LockClosedIcon className="w-4 h-4" />
            يتطلب صلاحية {ROLE_LABELS[minRole] ?? minRole}
          </div>
        )}
      </div>

      {mutation.isError && (
        <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-sm text-red-400 mb-3">
          {getApiErrorMessage(mutation.error, 'تعذّر تنفيذ التحليل - حاول مرة أخرى')}
        </div>
      )}

      {response && (
        <div className="space-y-4 pt-2">
          <div className="flex items-center gap-4 text-xs text-gray-400 flex-wrap">
            <span>الوكيل: <span className="text-gray-300">{response.agent}</span></span>
            <span>الثقة: <span className="text-gray-300">{(response.confidence * 100).toFixed(0)}%</span></span>
            <span>زمن التنفيذ: <span className="text-gray-300">{response.processing_time?.toFixed(2)}ث</span></span>
          </div>

          {response.explanation && (
            <p className="text-sm text-gray-300 bg-white/5 p-3 rounded-lg">{response.explanation}</p>
          )}

          {renderResult && response.result && Object.keys(response.result).length > 0 && (
            <div>{renderResult(response.result)}</div>
          )}

          {response.insights.length > 0 && (
            <div className="space-y-2">
              {response.insights.map((text, i) => (
                <div key={i} className="flex items-start gap-2 text-sm text-gray-300">
                  <LightBulbIcon className="w-4 h-4 text-primary-400 shrink-0 mt-0.5" />
                  <span>{text}</span>
                </div>
              ))}
            </div>
          )}

          {response.warnings.length > 0 && (
            <div className="space-y-2">
              {response.warnings.map((text, i) => (
                <div key={i} className="flex items-start gap-2 text-sm text-yellow-400 bg-yellow-500/10 p-2.5 rounded-lg">
                  <ExclamationTriangleIcon className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{text}</span>
                </div>
              ))}
            </div>
          )}

          {response.recommendations.length > 0 && (
            <div className="space-y-2">
              {response.recommendations.map((text, i) => (
                <div key={i} className="flex items-start gap-2 text-sm text-green-400 bg-green-500/10 p-2.5 rounded-lg">
                  <ShieldExclamationIcon className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{text}</span>
                </div>
              ))}
            </div>
          )}

          {response.insights.length === 0 &&
            response.warnings.length === 0 &&
            response.recommendations.length === 0 &&
            !renderResult && (
              <p className="text-sm text-gray-500">اكتمل التحليل بلا ملاحظات إضافية.</p>
            )}
        </div>
      )}
    </div>
  )
}

export default AgentPanel
