import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuthStore } from '../store/auth'

/**
 * إصلاح: لم يكن يوجد أي حارس مصادقة على المسارات - كل صفحات لوحة التحكم
 * كانت تُعرض مباشرة بلا أي تحقق من وجود جلسة دخول صالحة.
 */
const ProtectedRoute: React.FC<{ children: React.ReactElement }> = ({ children }) => {
  const accessToken = useAuthStore((s) => s.accessToken)
  const location = useLocation()

  if (!accessToken) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />
  }

  return children
}

export default ProtectedRoute
