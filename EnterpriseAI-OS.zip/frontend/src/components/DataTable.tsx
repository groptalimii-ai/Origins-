import React from 'react'

interface Column<T> {
  header: string
  accessor: (row: T) => React.ReactNode
  className?: string
}

interface DataTableProps<T> {
  columns: Column<T>[]
  rows: T[] | undefined
  isLoading: boolean
  isError: boolean
  emptyMessage?: string
  keyField: (row: T) => string
}

function DataTable<T>({ columns, rows, isLoading, isError, emptyMessage, keyField }: DataTableProps<T>) {
  if (isLoading) {
    return <div className="p-8 text-center text-sm text-gray-400">جاري التحميل...</div>
  }
  if (isError) {
    return <div className="p-8 text-center text-sm text-red-400">تعذّر جلب البيانات</div>
  }
  if (!rows || rows.length === 0) {
    return <div className="p-8 text-center text-sm text-gray-500">{emptyMessage ?? 'لا توجد بيانات بعد'}</div>
  }

  return (
    <div className="overflow-x-auto -mx-6">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-enterprise-border text-gray-400">
            {columns.map((col, i) => (
              <th key={i} className={`text-right font-medium px-6 py-3 whitespace-nowrap ${col.className ?? ''}`}>
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={keyField(row)} className="border-b border-enterprise-border/50 hover:bg-white/[0.03] transition-colors">
              {columns.map((col, i) => (
                <td key={i} className={`px-6 py-3 text-gray-200 whitespace-nowrap ${col.className ?? ''}`}>
                  {col.accessor(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default DataTable
