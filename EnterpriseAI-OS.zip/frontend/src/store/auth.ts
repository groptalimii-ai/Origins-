/**
 * مخزن حالة المصادقة - إصلاح: لم يكن يوجد أي إدارة حالة لتسجيل الدخول في
 * الواجهة الأمامية إطلاقاً (لا AuthContext، لا صفحة Login، لا تخزين توكن)،
 * رغم أن كل الـ backend مبني بالكامل حول JWT. هذا المخزن هو مصدر الحقيقة
 * الوحيد للتوكن وبيانات المستخدم الحالي، ويُقرأ من قبل عميل الـ API (lib/api.ts)
 * وحارس المسارات (ProtectedRoute في App.tsx).
 */
import { create } from 'zustand'

interface AuthUser {
  email: string
  name: string
  role: string
}

interface AuthState {
  accessToken: string | null
  refreshToken: string | null
  user: AuthUser | null
  setTokens: (accessToken: string, refreshToken: string) => void
  setUser: (user: AuthUser) => void
  login: (accessToken: string, refreshToken: string, user: AuthUser) => void
  logout: () => void
}

const ACCESS_KEY = 'enterpriseai_access_token'
const REFRESH_KEY = 'enterpriseai_refresh_token'
const USER_KEY = 'enterpriseai_user'

function readStoredUser(): AuthUser | null {
  const raw = localStorage.getItem(USER_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw) as AuthUser
  } catch {
    return null
  }
}

export const useAuthStore = create<AuthState>((set) => ({
  accessToken: localStorage.getItem(ACCESS_KEY),
  refreshToken: localStorage.getItem(REFRESH_KEY),
  user: readStoredUser(),

  setTokens: (accessToken, refreshToken) => {
    localStorage.setItem(ACCESS_KEY, accessToken)
    localStorage.setItem(REFRESH_KEY, refreshToken)
    set({ accessToken, refreshToken })
  },

  setUser: (user) => {
    localStorage.setItem(USER_KEY, JSON.stringify(user))
    set({ user })
  },

  login: (accessToken, refreshToken, user) => {
    localStorage.setItem(ACCESS_KEY, accessToken)
    localStorage.setItem(REFRESH_KEY, refreshToken)
    localStorage.setItem(USER_KEY, JSON.stringify(user))
    set({ accessToken, refreshToken, user })
  },

  logout: () => {
    localStorage.removeItem(ACCESS_KEY)
    localStorage.removeItem(REFRESH_KEY)
    localStorage.removeItem(USER_KEY)
    set({ accessToken: null, refreshToken: null, user: null })
  },
}))
