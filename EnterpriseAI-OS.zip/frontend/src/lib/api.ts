/**
 * عميل API مركزي - إصلاح: لم يكن يوجد سابقاً أي مكان مركزي يُرفق توكن JWT
 * بطلبات الواجهة الأمامية (Dashboard.tsx كان يستخدم fetch() مباشرة بلا أي
 * ترويسة Authorization)، بينما كل نقاط نهاية الـ backend الفعلية تتطلب توكن
 * صالح (get_current_user / require_min_role) - أي أن كل طلب كان سيفشل بـ 401
 * دائماً. هذا الملف هو المصدر الوحيد الذي يجب أن تستخدمه كل الصفحات للاتصال
 * بالـ API.
 */
import axios from 'axios'
import { useAuthStore } from '../store/auth'

export const api = axios.create({
  baseURL: '/api/v1',
})

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken
  if (token) {
    config.headers = config.headers ?? {}
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// إصلاح: عند انتهاء صلاحية التوكن أو رفضه (401)، نحاول تجديده مرة واحدة عبر
// refresh_token قبل تسجيل خروج المستخدم تلقائياً - بدل ترك الطلبات تفشل بصمت.
let isRefreshing = false
let pendingQueue: Array<() => void> = []

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config
    if (error.response?.status !== 401 || originalRequest._retry) {
      return Promise.reject(error)
    }

    const { refreshToken, setTokens, logout } = useAuthStore.getState()
    if (!refreshToken) {
      logout()
      return Promise.reject(error)
    }

    originalRequest._retry = true

    if (isRefreshing) {
      return new Promise((resolve) => {
        pendingQueue.push(() => resolve(api(originalRequest)))
      })
    }

    isRefreshing = true
    try {
      const { data } = await axios.post('/api/v1/auth/refresh', { refresh_token: refreshToken })
      setTokens(data.access_token, data.refresh_token)
      pendingQueue.forEach((cb) => cb())
      pendingQueue = []
      return api(originalRequest)
    } catch (refreshError) {
      logout()
      return Promise.reject(refreshError)
    } finally {
      isRefreshing = false
    }
  }
)

/**
 * مراجعة معمارية (Type Hinting صارم + DRY): كان استخراج رسالة الخطأ من استجابة
 * axios مكرَّراً بمنطق `(err as any)?.response?.data?.detail` في أكثر من مكوّن
 * (Login.tsx وAgentPanel.tsx) - بلا أي أمان نوعي (err: any يُسقط فحص TypeScript
 * بالكامل عن الكائن). الدالتان أدناه هما المصدر الوحيد لهذا المنطق، تستقبلان
 * unknown (النوع الصحيح لأي catch block حسب TS الحديث) وتُضيّقان النوع فعلياً
 * عبر axios.isAxiosError بدل type assertion عشوائي.
 */
export function getApiErrorDetail(err: unknown): string | undefined {
  if (axios.isAxiosError<{ detail?: string }>(err)) {
    const detail = err.response?.data?.detail
    if (typeof detail === 'string' && detail.length > 0) return detail
  }
  return undefined
}

export function getApiErrorMessage(err: unknown, fallback: string): string {
  return getApiErrorDetail(err) ?? fallback
}


