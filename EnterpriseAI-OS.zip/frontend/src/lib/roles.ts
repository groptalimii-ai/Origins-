/**
 * تسلسل الأدوار الهرمي - نسخة مطابقة لـ backend/core/security.py::ROLE_HIERARCHY.
 * يُستخدم هنا فقط لتحسين تجربة المستخدم (إخفاء/تعطيل أزرار إجراءات لا يملك
 * صلاحيتها بدل تركه يكتشف ذلك عبر خطأ 403 بعد الانتظار) - التحقق الفعلي الملزم
 * يبقى دائماً من طرف الـ backend عبر require_min_role، وهذا الملف لا يغني عنه.
 */
export const ROLE_HIERARCHY: Record<string, number> = {
  admin: 100,
  executive: 80,
  manager: 60,
  analyst: 40,
  user: 20,
}

export const ROLE_LABELS: Record<string, string> = {
  admin: 'مدير النظام',
  executive: 'تنفيذي',
  manager: 'مدير',
  analyst: 'محلل',
  user: 'مستخدم',
}

export function hasMinRole(userRole: string | undefined, minRole: string): boolean {
  if (!userRole) return false
  return (ROLE_HIERARCHY[userRole] ?? 0) >= (ROLE_HIERARCHY[minRole] ?? 0)
}
