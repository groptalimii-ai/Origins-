import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
      '/ws': {
        target: 'ws://localhost:8000',
        ws: true,
      },
    },
  },
  build: {
    outDir: 'build',
    sourcemap: true,
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  // إصلاح: لم يكن يوجد أي إعداد vitest إطلاقًا رغم وجود سكربت "test": "vitest" في
  // package.json - كان يفشل فورًا بـ "No test files found" (بيئة node الافتراضية
  // غير مناسبة أصلًا لاختبار مكوّنات React). أُضيفت بيئة jsdom + إعداد testing-library.
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
  },
})
