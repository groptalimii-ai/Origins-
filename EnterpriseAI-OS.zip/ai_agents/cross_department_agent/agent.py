#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Cross Department Agent
وكيل التنسيق بين الأقسام
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class CrossDepartmentAgent(BaseAgent):
    """وكيل التنسيق بين الأقسام المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="CrossDepartmentAgent",
            description="وكيل متخصص في تنسيق العمليات بين الأقسام وحل النزاعات",
            capabilities=[
                "cross_functional_analysis",
                "conflict_resolution",
                "process_optimization",
                "resource_allocation",
                "workflow_automation",
                "interdepartmental_reporting",
                "bottleneck_identification",
                "collaboration_scoring"
            ],
            models=["collaboration-analyzer", "conflict-resolver", "process-optimizer"],
            data_sources=["all_departments", "workflows", "communications", "projects"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        if task.type == "cross_functional_analysis":
            return Plan(steps=[
                Step("map_processes", {"scope": "end_to_end"}),
                Step("identify_handoffs", {}),
                Step("measure_delays", {}),
                Step("detect_conflicts", {}),
                Step("propose_integrations", {}),
                Step("generate_roadmap", {})
            ], estimated_time=45.0)
        elif task.type == "purchase_request":
            return Plan(steps=[
                Step("validate_request", {}),
                Step("check_inventory", {"agent": "InventoryAgent"}),
                Step("check_budget", {"agent": "FinancialAgent"}),
                Step("evaluate_suppliers", {"agent": "InventoryAgent"}),
                Step("calculate_impact", {"departments": ["finance", "operations"]}),
                Step("generate_approval_workflow", {})
            ], estimated_time=30.0)
        else:
            return Plan(steps=[
                Step("analyze_cross_request", {}),
                Step("coordinate_with_agents", {}),
                Step("synthesize_response", {})
            ], estimated_time=20.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "identify_handoffs":
            return await self._step_identify_handoffs(step.params)
        elif step.name == "calculate_impact":
            return await self._step_calculate_impact(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_identify_handoffs(self, params: Dict) -> StepResult:
        """
        قياس فعلي لتأخر أوامر الإنتاج (production_orders): نقارن scheduled_end الفعلي
        بحالة delayed لتقدير 'اختناق' حقيقي (بدل sales→production 2.3 يوم ثابتة سابقًا
        التي لا ترتبط بأي جدول فعلي - لا يوجد جدول workflows/handoffs صريح في المخطط).
        """
        orders_result = await self.tools.execute(
            "query_database",
            query="SELECT status, scheduled_start, scheduled_end, created_at FROM production_orders "
                  "WHERE scheduled_start IS NOT NULL AND scheduled_end IS NOT NULL"
        )
        orders = orders_result.get("rows", [])

        if not orders:
            return StepResult(
                step_name="identify_handoffs", success=True,
                data={"handoffs": [], "total_process_time": None, "optimization_potential": None,
                      "note": "لا يوجد جدول handoffs/workflows صريح؛ ولا بيانات أوامر إنتاج كافية"}
            )

        delayed = [o for o in orders if o.get("status") == "delayed"]
        delay_ratio = round(len(delayed) / len(orders), 3)

        handoffs = [{
            "from": "production_planning", "to": "production_execution",
            "sample_size": len(orders),
            "delayed_orders": len(delayed),
            "delay_ratio": delay_ratio,
            "bottleneck": delay_ratio > 0.15
        }]

        return StepResult(
            step_name="identify_handoffs",
            success=True,
            data={
                "handoffs": handoffs,
                "total_process_time": None,
                "optimization_potential": f"{round(delay_ratio * 100, 1)}%",
                "note": "لا يوجد جدول workflows/handoffs بين الأقسام صراحة؛ هذا مبني على حالة أوامر الإنتاج فقط"
            }
        )

    async def _step_calculate_impact(self, params: Dict) -> StepResult:
        """
        تقييم تأثير طلب شراء استنادًا لبيانات budgets الفعلية (متاح/مُستهلك للقسم)
        بدل قيم ثابتة budget_required=50000/roi=120% سابقًا التي لا ترتبط بأي طلب فعلي.
        """
        department = params.get("department") or (params.get("data") or {}).get("department")
        requested_amount = params.get("amount") or (params.get("data") or {}).get("amount")

        query = "SELECT department, period, allocated, spent FROM budgets"
        if department:
            query += " WHERE department = :department"
        budgets_result = await self.tools.execute(
            "query_database", query=query,
            params={"department": department} if department else None
        )
        budgets = budgets_result.get("rows", [])

        if not budgets:
            return StepResult(
                step_name="calculate_impact", success=True,
                data={"financial_impact": None, "operational_impact": None, "approved": False,
                      "conditions": [], "note": "لا توجد بيانات ميزانية لهذا القسم"}
            )

        total_allocated = sum(float(b["allocated"]) for b in budgets)
        total_spent = sum(float(b["spent"] or 0) for b in budgets)
        available = total_allocated - total_spent

        approved = bool(requested_amount is not None and requested_amount <= available)
        conditions = []
        if requested_amount is not None and not approved:
            conditions.append("insufficient_budget")
        if requested_amount is None:
            conditions.append("amount_not_specified")

        return StepResult(
            step_name="calculate_impact",
            success=True,
            data={
                "financial_impact": {
                    "budget_allocated": round(total_allocated, 2),
                    "budget_spent": round(total_spent, 2),
                    "budget_available": round(available, 2),
                    "requested_amount": requested_amount
                },
                "operational_impact": None,
                "approved": approved,
                "conditions": conditions
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if "handoffs" in combined:
            bottlenecks = [h for h in combined["handoffs"] if h.get("bottleneck")]
            if bottlenecks:
                warnings.append(f"⚠️ {len(bottlenecks)} نقاط اختناق في العمليات المتداخلة")
                recommendations.append("🔄 أتمتة عمليات التسليم بين الأقسام")

        if "optimization_potential" in combined:
            insights.append(f"⚡ إمكانية تحسين العمليات: {combined['optimization_potential']}")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.89,
            explanation="تم التنسيق بين الأقسام وتحليل العمليات المتداخلة",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
