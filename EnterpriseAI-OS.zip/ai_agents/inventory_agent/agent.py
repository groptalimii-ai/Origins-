#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Inventory Agent
وكيل إدارة المخزون
"""

import logging
from typing import Dict, Any, List
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class InventoryAgent(BaseAgent):
    """وكيل إدارة المخزون المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="InventoryAgent",
            description="وكيل متخصص في إدارة المخزون والتنبؤ بالطلب",
            capabilities=[
                "demand_forecasting",
                "inventory_optimization",
                "reorder_point_calculation",
                "supplier_evaluation",
                "stockout_prevention",
                "excess_inventory_detection",
                "abc_analysis",
                "lead_time_prediction"
            ],
            models=[
                "demand-forecaster-v2",
                "inventory-optimizer",
                "supplier-scorer"
            ],
            data_sources=[
                "inventory_levels",
                "sales_history",
                "purchase_orders",
                "supplier_data",
                "seasonal_trends"
            ],
            confidence_threshold=0.85
        ))
        self.demand_model = None

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        # إصلاح (الجولة الثانية عشرة): راوت /inventory/ai/demand-forecast يرسل
        # task_type="demand_prediction" (مطابق لمفتاح orchestrator الذي يوجّه بنجاح
        # لهذا الوكيل)، لكن هذا الشرط كان يتحقق من "demand_forecast" حصرًا - فيسقط
        # دومًا للخطة العامة بلا أي تنبؤ طلب فعلي رغم توجيهه للوكيل الصحيح.
        if task.type in ("demand_forecast", "demand_prediction"):
            return Plan(steps=[
                Step("gather_sales_history", {"period": "3_years"}),
                Step("identify_seasonality", {"granularity": "weekly"}),
                Step("analyze_external_factors", {"weather": True, "holidays": True}),
                Step("build_demand_model", {"algorithm": "ensemble", "horizon": 60}),
                Step("calculate_safety_stock", {"service_level": 0.95}),
                Step("generate_reorder_plan", {})
            ], estimated_time=40.0)

        elif task.type == "inventory_check":
            return Plan(steps=[
                Step("scan_current_inventory", {}),
                Step("calculate_turnover_rates", {}),
                Step("identify_slow_movers", {"threshold": 90}),
                Step("flag_stockouts", {"lead_time_buffer": 7}),
                Step("generate_action_items", {})
            ], estimated_time=20.0)

        elif task.type == "supplier_evaluation":
            return Plan(steps=[
                Step("gather_supplier_data", {"period": "2_years"}),
                Step("calculate_kpis", {"delivery": True, "quality": True, "cost": True}),
                Step("score_suppliers", {"weights": {"delivery": 0.4, "quality": 0.35, "cost": 0.25}}),
                Step("identify_risks", {}),
                Step("generate_recommendations", {})
            ], estimated_time=35.0)

        else:
            return Plan(steps=[
                Step("analyze_request", {}),
                Step("gather_inventory_data", {}),
                Step("process_with_ai", {}),
                Step("generate_response", {})
            ], estimated_time=20.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "build_demand_model":
            return await self._step_build_demand_model(step.params)
        elif step.name == "calculate_safety_stock":
            return await self._step_calculate_safety_stock(step.params)
        elif step.name == "scan_current_inventory":
            return await self._step_scan_inventory(step.params)
        elif step.name == "score_suppliers":
            return await self._step_score_suppliers(step.params)
        else:
            return StepResult(
                step_name=step.name,
                success=True,
                data={"status": "completed"}
            )

    async def _step_build_demand_model(self, params: Dict) -> StepResult:
        """
        بناء نموذج الطلب من بيانات حركة المخزون الفعلية (inventory_movements، النوع sale)
        باستخدام RandomForestRegressor على متوسط الطلب اليومي الفعلي، بدل قائمة ثابتة
        [120, 135, 128...] سابقًا.
        """
        horizon = params.get("horizon", 60)
        movements = await self.tools.execute(
            "query_database",
            query="SELECT date, quantity FROM inventory_movements "
                  "WHERE movement_type = 'sale' AND date >= NOW() - INTERVAL '180 days' "
                  "ORDER BY date"
        )
        rows = movements.get("rows", [])

        if not rows:
            return StepResult(
                step_name="build_demand_model",
                success=True,
                data={
                    "forecast": {"next_period_days": horizon, "note": "لا توجد بيانات حركة مبيعات كافية بعد"},
                    "model_accuracy": 0.0,
                    "confidence_interval": {"lower": 0.0, "upper": 0.0}
                },
                metrics={"mape": None}
            )

        df = pd.DataFrame(rows)
        df["date"] = pd.to_datetime(df["date"])
        daily = df.groupby(df["date"].dt.date)["quantity"].sum().abs()
        daily = daily.sort_index()

        avg_daily_demand = float(daily.mean())
        std_daily_demand = float(daily.std()) if len(daily) > 1 else 0.0
        trend = "increasing" if len(daily) > 7 and daily.iloc[-7:].mean() > daily.iloc[:7].mean() else "stable"

        # نموذج انحدار بسيط باستخدام المؤشر الزمني كخاصية، لتوليد تنبؤ فعلي بدل قيمة ثابتة
        X = np.arange(len(daily)).reshape(-1, 1)
        y = daily.values
        model = RandomForestRegressor(n_estimators=50, random_state=42)
        model.fit(X, y)
        future_X = np.arange(len(daily), len(daily) + horizon).reshape(-1, 1)
        forecast_values = model.predict(future_X).round(1).tolist()

        return StepResult(
            step_name="build_demand_model",
            success=True,
            data={
                "forecast": {
                    "next_period": forecast_values,
                    "trend": trend,
                    "avg_daily_demand": round(avg_daily_demand, 2),
                    "std_daily_demand": round(std_daily_demand, 2)
                },
                "model_accuracy": None,
                "confidence_interval": {"lower": round(avg_daily_demand - std_daily_demand, 2),
                                         "upper": round(avg_daily_demand + std_daily_demand, 2)}
            },
            metrics={"data_points": len(daily)}
        )

    async def _step_calculate_safety_stock(self, params: Dict) -> StepResult:
        """
        حساب المخزون الاحتياطي فعليًا بصيغة: SS = Z * std(الطلب اليومي) * sqrt(lead_time)
        باستخدام inventory_items.lead_time_days وانحراف الطلب من inventory_movements،
        بدل قيم ثابتة (150/80/200) سابقًا.
        """
        service_level = params.get("service_level", 0.95)
        z_scores = {0.90: 1.28, 0.95: 1.65, 0.975: 1.96, 0.99: 2.33}
        z = z_scores.get(round(service_level, 3), 1.65)

        items_result = await self.tools.execute(
            "query_database",
            query="SELECT sku, quantity_on_hand, lead_time_days, unit_cost FROM inventory_items"
        )
        items = items_result.get("rows", [])

        # إصلاح (الجولة الحادية عشرة، N+1 query): كانت هذه الدالة تنفّذ استعلام
        # منفصل على inventory_movements لكل صنف داخل الحلقة (استعلام واحد لكل SKU
        # بدل استعلام واحد إجمالي) - مع مخزون كبير (آلاف الأصناف) هذا يعني آلاف
        # جولات الشبكة المتتالية لقاعدة البيانات بدل استعلام واحد مجمَّع، ما يبطئ
        # هذه الخطوة بشكل كبير جدًا وقد يسبب مهلة انتظار (timeout) فعلية. الآن نجلب
        # كل حركات آخر 90 يوماً لكل الأصناف دفعة واحدة ونجمّعها في الذاكرة حسب sku.
        all_movements_result = await self.tools.execute(
            "query_database",
            query="SELECT sku, date, quantity FROM inventory_movements "
                  "WHERE movement_type = 'sale' AND date >= NOW() - INTERVAL '90 days'"
        )
        all_mv_rows = all_movements_result.get("rows", [])

        movements_by_sku: Dict[str, List[Dict]] = {}
        for mv in all_mv_rows:
            movements_by_sku.setdefault(mv["sku"], []).append(mv)

        safety_stock_levels = {}
        reorder_points = {}
        holding_cost_estimate = 0.0

        for item in items:
            sku = item["sku"]
            lead_time = float(item.get("lead_time_days") or 7)

            mv_rows = movements_by_sku.get(sku, [])
            if not mv_rows:
                continue

            mv_df = pd.DataFrame(mv_rows)
            mv_df["date"] = pd.to_datetime(mv_df["date"])
            daily = mv_df.groupby(mv_df["date"].dt.date)["quantity"].sum().abs()
            avg_demand = float(daily.mean()) if len(daily) else 0.0
            std_demand = float(daily.std()) if len(daily) > 1 else 0.0

            safety_stock = round(z * std_demand * (lead_time ** 0.5), 1)
            reorder_point = round(safety_stock + avg_demand * lead_time, 1)

            safety_stock_levels[sku] = safety_stock
            reorder_points[sku] = reorder_point
            holding_cost_estimate += safety_stock * float(item.get("unit_cost") or 0)

        return StepResult(
            step_name="calculate_safety_stock",
            success=True,
            data={
                "safety_stock_levels": safety_stock_levels,
                "reorder_points": reorder_points,
                "service_level_achieved": service_level,
                "holding_cost_estimate": round(holding_cost_estimate, 2)
            }
        )

    async def _step_scan_inventory(self, params: Dict) -> StepResult:
        """
        فحص المخزون الفعلي من جدول inventory_items (بدل 15000/45/... ثابتة سابقًا):
        نفاد المخزون = quantity_on_hand <= reorder_point، والزيادة = أكثر من ضعف reorder_quantity.
        """
        items_result = await self.tools.execute(
            "query_database",
            query="SELECT sku, quantity_on_hand, reorder_point, reorder_quantity, unit_cost, supplier "
                  "FROM inventory_items"
        )
        items = items_result.get("rows", [])

        total_items = len(items)
        stockouts = sum(1 for i in items if (i.get("quantity_on_hand") or 0) <= (i.get("reorder_point") or 0))
        overstock = sum(
            1 for i in items
            if (i.get("reorder_quantity") or 0) > 0
            and (i.get("quantity_on_hand") or 0) > 2 * (i.get("reorder_quantity") or 0)
        )
        inventory_value = sum(
            float(i.get("quantity_on_hand") or 0) * float(i.get("unit_cost") or 0) for i in items
        )
        suppliers = {i.get("supplier") for i in items if i.get("supplier")}

        # حساب سرعة الدوران التقريبية من حركات آخر 90 يوم
        movements_result = await self.tools.execute(
            "query_database",
            query="SELECT SUM(ABS(quantity)) AS total_out FROM inventory_movements "
                  "WHERE movement_type = 'sale' AND date >= NOW() - INTERVAL '90 days'"
        )
        mv_rows = movements_result.get("rows", [])
        total_out = float(mv_rows[0]["total_out"]) if mv_rows and mv_rows[0].get("total_out") else 0.0
        turnover_ratio = round(total_out / inventory_value, 3) if inventory_value > 0 else 0.0

        return StepResult(
            step_name="scan_current_inventory",
            success=True,
            data={
                "total_items": total_items,
                "categories": len(suppliers),
                "stockouts": stockouts,
                "overstock": overstock,
                "slow_movers": None,
                "inventory_value": round(inventory_value, 2),
                "turnover_ratio": turnover_ratio
            }
        )

    async def _step_score_suppliers(self, params: Dict) -> StepResult:
        """
        تقييم الموردين من بيانات inventory_items الفعلية (بدل Supplier A/B/C ثابتة سابقًا):
        نقيّم كل مورد بناءً على متوسط lead_time_days (كلما قل كان أفضل) ومتوسط unit_cost
        (كلما قل كان أفضل)، مع عدد الأصناف كمؤشر اعتماد.
        """
        weights = params.get("weights", {"delivery": 0.4, "quality": 0.35, "cost": 0.25})

        items_result = await self.tools.execute(
            "query_database",
            query="SELECT supplier, lead_time_days, unit_cost, quantity_on_hand, reorder_point "
                  "FROM inventory_items WHERE supplier IS NOT NULL"
        )
        items = items_result.get("rows", [])

        if not items:
            return StepResult(
                step_name="score_suppliers", success=True,
                data={"suppliers": [], "top_supplier": None, "risk_suppliers": [],
                      "diversification_score": 0.0, "note": "لا توجد بيانات موردين مسجّلة بعد"}
            )

        df = pd.DataFrame(items)
        df["lead_time_days"] = df["lead_time_days"].astype(float)
        df["unit_cost"] = df["unit_cost"].astype(float)

        max_lead = df["lead_time_days"].max() or 1
        max_cost = df["unit_cost"].max() or 1

        grouped = df.groupby("supplier").agg(
            avg_lead_time=("lead_time_days", "mean"),
            avg_cost=("unit_cost", "mean"),
            stockout_items=("quantity_on_hand", lambda s: (s <= df.loc[s.index, "reorder_point"]).sum()),
            item_count=("supplier", "count")
        ).reset_index()

        suppliers = []
        for _, row in grouped.iterrows():
            delivery_score = round(1 - (row["avg_lead_time"] / max_lead), 3)
            cost_score = round(1 - (row["avg_cost"] / max_cost), 3)
            quality_score = round(1 - (row["stockout_items"] / row["item_count"]), 3)
            overall = round(
                delivery_score * weights.get("delivery", 0.4)
                + quality_score * weights.get("quality", 0.35)
                + cost_score * weights.get("cost", 0.25), 3
            )
            suppliers.append({
                "name": row["supplier"],
                "delivery_score": delivery_score,
                "quality_score": quality_score,
                "cost_score": cost_score,
                "overall": overall
            })

        suppliers.sort(key=lambda s: s["overall"], reverse=True)
        top_supplier = suppliers[0]["name"] if suppliers else None
        risk_suppliers = [s["name"] for s in suppliers if s["overall"] < 0.5]
        diversification_score = round(1 - (1 / len(suppliers)), 3) if len(suppliers) > 1 else 0.0

        return StepResult(
            step_name="score_suppliers",
            success=True,
            data={
                "suppliers": suppliers,
                "top_supplier": top_supplier,
                "risk_suppliers": risk_suppliers,
                "diversification_score": diversification_score
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for result in results:
            combined.update(result.data)

        insights = []
        recommendations = []
        warnings = []

        if "stockouts" in combined and combined["stockouts"] > 0:
            warnings.append(f"⚠️ هناك {combined['stockouts']} منتجات نفدت من المخزون")
            recommendations.append("🛒 قم بإنشاء أوامر شراء عاجلة للمنتجات النفدت")

        if "overstock" in combined and combined["overstock"] > 10:
            insights.append(f"📦 هناك {combined['overstock']} منتجات بمخزون زائد")
            recommendations.append("💰 فكر في عروض ترويجية لتصفية المخزون الزائد")

        forecast = combined.get("forecast")
        if forecast and isinstance(forecast, dict) and forecast.get("trend"):
            insights.append(f"📈 اتجاه الطلب المتوقع: {forecast['trend']} "
                             f"(متوسط يومي ≈ {forecast.get('avg_daily_demand', 'غير متوفر')})")
            if forecast.get("trend") == "increasing":
                recommendations.append("📊 راجع مستويات إعادة الطلب مع اتجاه الطلب المتصاعد")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.87,
            explanation="تم تحليل المخزون والطلب وإعداد التوصيات",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
