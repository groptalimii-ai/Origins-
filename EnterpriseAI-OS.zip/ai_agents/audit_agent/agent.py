#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Audit Agent
وكيل التدقيق
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class AuditAgent(BaseAgent):
    """وكيل التدقيق المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="AuditAgent",
            description="وكيل متخصص في التدقيق المستمر وكشف الاحتيال",
            capabilities=[
                "continuous_auditing",
                "fraud_detection",
                "compliance_monitoring",
                "risk_assessment",
                "anomaly_detection",
                "pattern_analysis",
                "control_testing",
                "regulatory_reporting"
            ],
            models=["fraud-detector", "anomaly-transformer", "graph-neural-network"],
            data_sources=["transactions", "journal_entries", "user_logs", "access_logs", "approvals"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        if task.type == "fraud_detection":
            return Plan(steps=[
                Step("scan_all_transactions", {"period": "30_days"}),
                Step("apply_statistical_tests", {"benford": True, "z_score": True}),
                Step("run_graph_analysis", {"relationship_depth": 3}),
                Step("detect_anomalies", {"sensitivity": "high"}),
                Step("score_risk", {"threshold": 0.75}),
                Step("generate_alert", {"severity": "auto"})
            ], estimated_time=30.0)
        elif task.type in ("compliance_check", "audit"):
            # إصلاح (الجولة الثانية عشرة): راوت /audit/ai/compliance-check يرسل
            # task_type="audit" (مطابق لمفتاح orchestrator الذي يوجّه بنجاح لهذا
            # الوكيل)، لكن هذا الشرط كان يتحقق من "compliance_check" حصرًا - فيسقط
            # دومًا للخطة العامة بلا أي فحص ضوابط فعلي (test_controls).
            return Plan(steps=[
                Step("load_regulations", {"jurisdiction": "auto_detect"}),
                Step("scan_processes", {}),
                Step("test_controls", {"sample_size": 100}),
                Step("identify_gaps", {}),
                Step("generate_remediation_plan", {})
            ], estimated_time=40.0)
        else:
            return Plan(steps=[
                Step("analyze_audit_request", {}),
                Step("gather_evidence", {}),
                Step("apply_tests", {}),
                Step("generate_findings", {})
            ], estimated_time=25.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "detect_anomalies":
            return await self._step_detect_anomalies(step.params)
        elif step.name == "test_controls":
            return await self._step_test_controls(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_detect_anomalies(self, params: Dict) -> StepResult:
        """
        كشف شذوذ فعلي على جدول transactions (بدل 5 شذوذ ثابتة سابقًا):
        قواعد بسيطة قابلة للتفسير: مبالغ كبيرة جدًا (> 3 انحراف معياري عن المتوسط)
        ومعاملات مُعلَّمة مسبقًا is_flagged = true.
        """
        stats = await self.tools.execute(
            "query_database",
            query="SELECT AVG(amount) AS avg_amt, STDDEV(amount) AS std_amt "
                  "FROM transactions WHERE date >= NOW() - INTERVAL '90 days'"
        )
        stats_rows = stats.get("rows", [])
        avg_amt = float(stats_rows[0]["avg_amt"]) if stats_rows and stats_rows[0].get("avg_amt") else 0.0
        std_amt = float(stats_rows[0]["std_amt"]) if stats_rows and stats_rows[0].get("std_amt") else 0.0

        flagged = await self.tools.execute(
            "query_database",
            query="SELECT id, amount, vendor, department, date FROM transactions "
                  "WHERE date >= NOW() - INTERVAL '90 days' AND is_flagged = true "
                  "ORDER BY date DESC LIMIT 50"
        )
        flagged_rows = flagged.get("rows", [])

        outliers = []
        if std_amt > 0:
            outlier_result = await self.tools.execute(
                "query_database",
                query="SELECT id, amount, vendor, department, date FROM transactions "
                      "WHERE date >= NOW() - INTERVAL '90 days' "
                      f"AND ABS(amount - {avg_amt}) > 3 * {std_amt} "
                      "ORDER BY amount DESC LIMIT 50"
            )
            outliers = outlier_result.get("rows", [])

        details = []
        for r in flagged_rows[:20]:
            details.append({"type": "flagged_transaction", "id": r["id"], "amount": float(r["amount"]), "confidence": 0.75})
        for r in outliers[:20]:
            details.append({"type": "statistical_outlier", "id": r["id"], "amount": float(r["amount"]), "confidence": 0.9})

        high_risk = len(outliers)
        medium_risk = len(flagged_rows)
        total = high_risk + medium_risk

        return StepResult(
            step_name="detect_anomalies",
            success=True,
            data={
                "anomalies_found": total,
                "high_risk": high_risk,
                "medium_risk": medium_risk,
                "low_risk": 0,
                "details": details[:20]
            }
        )

    async def _step_test_controls(self, params: Dict) -> StepResult:
        """
        اختبار الضوابط الداخلية استنادًا لبيانات فعلية: نسبة المعاملات الموافَق عليها
        (تحتوي created_by) مقابل الإجمالي، ونسبة قرارات AI المعتمدة (ai_decisions.approved_by)
        كمؤشر تقريبي على فعالية ضوابط الموافقة (بدل 25/22/2/1 ثابتة سابقًا).
        """
        sample_size = params.get("sample_size", 100)

        txn_result = await self.tools.execute(
            "query_database",
            query=f"SELECT id, created_by FROM transactions ORDER BY date DESC LIMIT {int(sample_size)}"
        )
        txn_rows = txn_result.get("rows", [])
        tested = len(txn_rows)
        with_owner = sum(1 for r in txn_rows if r.get("created_by"))
        without_owner = tested - with_owner

        decisions_result = await self.tools.execute(
            "query_database",
            query="SELECT id, approved_by FROM ai_decisions ORDER BY created_at DESC LIMIT 100"
        )
        decisions_rows = decisions_result.get("rows", [])
        approved = sum(1 for r in decisions_rows if r.get("approved_by"))

        effective = with_owner
        partial = 0
        ineffective = without_owner
        compliance_score = round(effective / tested, 3) if tested else 0.0

        return StepResult(
            step_name="test_controls",
            success=True,
            data={
                "controls_tested": tested,
                "effective": effective,
                "partial": partial,
                "ineffective": ineffective,
                "ai_decisions_reviewed": len(decisions_rows),
                "ai_decisions_approved": approved,
                "compliance_score": compliance_score
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if "anomalies_found" in combined and combined["anomalies_found"] > 0:
            warnings.append(f"🚨 تم اكتشاف {combined['anomalies_found']} شذوذ")
            if combined.get("high_risk", 0) > 0:
                warnings.append(f"🔴 {combined['high_risk']} شذوذ عالي الخطورة")
                recommendations.append("⚡ تحقيق فوري مطلوب")

        if "compliance_score" in combined:
            if combined["compliance_score"] < 0.90:
                recommendations.append("📋 تحسين الضوابط الداخلية مطلوب")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.91,
            explanation="تم إكمال التدقيق وكشف الشذوذ",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
