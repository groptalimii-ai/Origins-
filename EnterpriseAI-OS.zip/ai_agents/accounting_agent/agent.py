#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Accounting Agent
وكيل المحاسبة
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class AccountingAgent(BaseAgent):
    """وكيل المحاسبة المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="AccountingAgent",
            description="وكيل متخصص في المحاسبة التلقائية والتصنيف الذكي",
            capabilities=[
                "transaction_classification",
                "bank_reconciliation",
                "invoice_processing",
                "tax_compliance",
                "journal_entry_automation",
                "financial_statement_preparation",
                "variance_analysis",
                "audit_trail_generation"
            ],
            models=["accounting-bert", "invoice-parser"],
            data_sources=["transactions", "invoices", "bank_statements", "chart_of_accounts"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        # إصلاح (الجولة الثانية عشرة): راوت /accounting/ai/reconciliation يرسل
        # task_type="reconciliation" (وهو نفس المفتاح المستخدَم في
        # orchestrator.select_optimal_agent لتوجيه الطلب فعليًا لهذا الوكيل بنجاح)،
        # لكن هذا الشرط كان يتحقق من "bank_reconciliation" حصرًا. النتيجة: الوكيل
        # الصحيح كان يُختار، لكن plan() كان يفشل في التعرّف على المهمة فيسقط دومًا
        # للخطة العامة الفارغة (analyze/process/generate بلا أي منطق مطابقة تسوية
        # فعلي) - يعني /ai/reconciliation لم يكن ينفّذ match_transactions الحقيقية
        # إطلاقًا رغم نجاح التوجيه للوكيل الصحيح. نفس الخلل تكرر بعدة وكلاء أخرى
        # (راجع FIX_STATUS.md الجولة 12 لكل الحالات المشابهة).
        if task.type == "journal_entry":
            return Plan(steps=[
                Step("analyze_transaction", {}),
                Step("classify_accounts", {"chart_of_accounts": True}),
                Step("calculate_amounts", {"vat": True}),
                Step("validate_entry", {"debit_credit_balance": True}),
                Step("post_to_ledger", {}),
                Step("generate_audit_trail", {})
            ], estimated_time=15.0)
        elif task.type in ("bank_reconciliation", "reconciliation"):
            return Plan(steps=[
                Step("fetch_bank_statements", {"period": "current_month"}),
                Step("fetch_ledger_entries", {"period": "current_month"}),
                Step("match_transactions", {"tolerance": 0.01}),
                Step("identify_discrepancies", {}),
                Step("suggest_adjustments", {}),
                Step("generate_reconciliation_report", {})
            ], estimated_time=25.0)
        else:
            return Plan(steps=[
                Step("analyze_accounting_request", {}),
                Step("process_data", {}),
                Step("generate_output", {})
            ], estimated_time=15.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "classify_accounts":
            return await self._step_classify_accounts(step.params)
        elif step.name == "match_transactions":
            return await self._step_match_transactions(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_classify_accounts(self, params: Dict) -> StepResult:
        """
        تصنيف الحسابات بناءً على أحدث معاملة مصروف فعلية مسجّلة، بدل قيم ثابتة
        ("6100 - Office Expenses" دائمًا كما كانت سابقًا بغض النظر عن أي شيء).
        خريطة تصنيف بسيطة قابلة للتوسعة حسب category الفعلية في الجدول.
        """
        chart_map = {
            "operations": "6000 - Operations Expenses",
            "marketing": "6200 - Marketing Expenses",
            "salaries": "6300 - Salaries & Wages",
            "technology": "6400 - Technology & Software",
        }

        result = await self.tools.execute(
            "query_database",
            query="SELECT id, category, amount FROM transactions "
                  "WHERE type = 'expense' ORDER BY date DESC LIMIT 1"
        )
        rows = result.get("rows", [])
        if not rows:
            return StepResult(
                step_name="classify_accounts", success=True,
                data={"debit_account": None, "credit_account": "1100 - Cash",
                      "vat_account": "2200 - VAT Payable", "confidence": 0.0,
                      "note": "لا توجد معاملات مصروفات مسجّلة بعد"}
            )

        category = rows[0].get("category") or "operations"
        debit_account = chart_map.get(category, "6900 - Other Expenses")

        return StepResult(
            step_name="classify_accounts",
            success=True,
            data={
                "debit_account": debit_account,
                "credit_account": "1100 - Cash",
                "vat_account": "2200 - VAT Payable",
                "confidence": 0.96 if category in chart_map else 0.6
            }
        )

    async def _step_match_transactions(self, params: Dict) -> StepResult:
        """
        تسوية بنكية فعلية: مطابقة الفواتير المسددة (invoices.status = paid) مع
        معاملات الدخل المقابلة ضمن هامش تسامح، بدل الأرقام الثابتة (245/3) سابقًا.
        """
        tolerance = params.get("tolerance", 0.01)

        invoices_result = await self.tools.execute(
            "query_database",
            query="SELECT id, invoice_number, amount FROM invoices WHERE status = 'paid'"
        )
        income_result = await self.tools.execute(
            "query_database",
            query="SELECT id, amount FROM transactions WHERE type = 'income'"
        )

        invoices = invoices_result.get("rows", [])
        incomes = [float(r["amount"]) for r in income_result.get("rows", [])]

        matched, unmatched_items = 0, []
        for inv in invoices:
            amt = float(inv["amount"])
            if any(abs(amt - inc) <= amt * tolerance for inc in incomes):
                matched += 1
            else:
                unmatched_items.append({
                    "invoice": inv["invoice_number"], "amount": amt,
                    "suggestion": "لم يُعثر على معاملة دخل مطابقة"
                })

        total = len(invoices) or 1
        return StepResult(
            step_name="match_transactions",
            success=True,
            data={
                "matched": matched,
                "unmatched": len(unmatched_items),
                "match_rate": round(matched / total, 3),
                "unmatched_items": unmatched_items[:20]
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if "unmatched" in combined and combined["unmatched"] > 0:
            warnings.append(f"⚠️ {combined['unmatched']} معاملة غير متطابقة")
            recommendations.append("🔍 راجع المعاملات غير المتطابقة يدوياً")

        if "confidence" in combined and combined["confidence"] < 0.90:
            warnings.append("⚠️ ثقة التصنيف منخفضة - تحتاج مراجعة")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.93,
            explanation="تمت المعالجة المحاسبية بنجاح",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
