#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Marketing Agent
وكيل التسويق
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class MarketingAgent(BaseAgent):
    """وكيل التسويق المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="MarketingAgent",
            description="وكيل متخصص في تحسين الحملات وتحليل المشاعر",
            capabilities=[
                "campaign_optimization",
                "sentiment_analysis",
                "customer_segmentation",
                "content_generation",
                "competitor_monitoring",
                "roi_analysis",
                "attribution_modeling",
                "social_listening"
            ],
            models=["sentiment-bert", "segmentation-model", "content-generator"],
            data_sources=["campaigns", "social_media", "web_analytics", "crm", "sales_data"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        # إصلاح (الجولة الثانية عشرة): راوت /marketing/ai/campaign-optimization يرسل
        # task_type="campaign"، وراوت /marketing/ai/sentiment-analysis يرسل
        # task_type="sentiment" (كلاهما مطابق لمفاتيح orchestrator التي توجّه بنجاح
        # لهذا الوكيل)، لكن هذا الشرط كان يتحقق من "campaign_optimization"/
        # "sentiment_analysis" حصرًا - فيسقط كلا الراوتين دومًا للخطة العامة بلا أي
        # تحسين ميزانية حقيقي رغم توجيههما للوكيل الصحيح.
        if task.type in ("campaign_optimization", "campaign"):
            return Plan(steps=[
                Step("analyze_current_campaigns", {}),
                Step("segment_audience", {"method": "kmeans", "clusters": 5}),
                Step("a_b_test_analysis", {}),
                Step("optimize_budget", {"channels": ["social", "search", "email", "display"]}),
                Step("predict_performance", {"horizon": 30}),
                Step("generate_recommendations", {})
            ], estimated_time=40.0)
        elif task.type in ("sentiment_analysis", "sentiment"):
            return Plan(steps=[
                Step("gather_mentions", {"sources": ["twitter", "facebook", "instagram", "news"]}),
                Step("preprocess_text", {"language": "auto_detect"}),
                Step("run_sentiment_model", {}),
                Step("identify_themes", {}),
                Step("detect_crises", {"threshold": -0.5}),
                Step("generate_response_strategy", {})
            ], estimated_time=30.0)
        else:
            return Plan(steps=[
                Step("analyze_marketing_request", {}),
                Step("gather_data", {}),
                Step("process_with_ai", {}),
                Step("generate_output", {})
            ], estimated_time=20.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "optimize_budget":
            return await self._step_optimize_budget(step.params)
        elif step.name == "run_sentiment_model":
            return await self._step_run_sentiment_model(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_optimize_budget(self, params: Dict) -> StepResult:
        """
        تحسين توزيع ميزانية الحملات من بيانات campaigns الفعلية (بدل نسب ثابتة
        social_media 35%/search 30%... سابقًا): نحسب ROI الحالي لكل قناة (conversions
        مقابل spend) ونعيد التوزيع تناسبيًا مع أداء كل قناة.
        """
        campaigns_result = await self.tools.execute(
            "query_database",
            query="SELECT channel, budget, spend, conversions FROM campaigns "
                  "WHERE spend > 0"
        )
        campaigns = campaigns_result.get("rows", [])

        if not campaigns:
            return StepResult(
                step_name="optimize_budget", success=True,
                data={"optimized_allocation": {}, "expected_roi": None, "current_roi": None,
                      "improvement": "0%", "note": "لا توجد بيانات حملات بإنفاق فعلي بعد"}
            )

        by_channel: Dict[str, Dict[str, float]] = {}
        for c in campaigns:
            ch = c.get("channel") or "other"
            entry = by_channel.setdefault(ch, {"spend": 0.0, "conversions": 0.0, "budget": 0.0})
            entry["spend"] += float(c.get("spend") or 0)
            entry["conversions"] += float(c.get("conversions") or 0)
            entry["budget"] += float(c.get("budget") or 0)

        total_spend = sum(v["spend"] for v in by_channel.values())
        total_conversions = sum(v["conversions"] for v in by_channel.values())
        current_roi = round(total_conversions / total_spend, 3) if total_spend else 0.0

        roi_per_channel = {
            ch: (v["conversions"] / v["spend"] if v["spend"] else 0.0) for ch, v in by_channel.items()
        }
        total_roi_weight = sum(roi_per_channel.values()) or 1.0
        optimized_allocation = {
            ch: round(roi / total_roi_weight, 3) for ch, roi in roi_per_channel.items()
        }

        # الميزانية الجديدة المتوقعة إذا أعيد توزيعها حسب أداء كل قناة
        expected_conversions = sum(
            optimized_allocation[ch] * total_spend * roi_per_channel[ch] for ch in by_channel
        )
        expected_roi = round(expected_conversions / total_spend, 3) if total_spend else 0.0
        improvement = round(((expected_roi - current_roi) / current_roi) * 100, 1) if current_roi else 0.0

        return StepResult(
            step_name="optimize_budget",
            success=True,
            data={
                "optimized_allocation": optimized_allocation,
                "expected_roi": expected_roi,
                "current_roi": current_roi,
                "improvement": f"{improvement}%"
            }
        )

    async def _step_run_sentiment_model(self, params: Dict) -> StepResult:
        """
        لا يوجد جدول منشورات/إشارات على وسائل التواصل (social_media mentions) في المخطط
        الحالي، لذا لا يمكن حساب مشاعر فعلية (كانت overall_sentiment=0.72 ثابتة سابقًا
        بلا أي مصدر بيانات حقيقي). نستخدم بديلاً تقريبيًا شفافًا: معدل النقر إلى الظهور
        (CTR) للحملات النشطة كمؤشر تفاعل موجب/سالب تقريبي، مع توضيح أنه ليس تحليل مشاعر نصي حقيقي.
        """
        campaigns_result = await self.tools.execute(
            "query_database",
            query="SELECT impressions, clicks FROM campaigns WHERE impressions > 0"
        )
        campaigns = campaigns_result.get("rows", [])

        if not campaigns:
            return StepResult(
                step_name="run_sentiment_model", success=True,
                data={"overall_sentiment": None, "note": "لا يوجد جدول لإشارات وسائل التواصل في المخطط الحالي، "
                                                          "ولا بيانات حملات كافية لمؤشر تقريبي"}
            )

        total_impressions = sum(float(c["impressions"]) for c in campaigns)
        total_clicks = sum(float(c["clicks"] or 0) for c in campaigns)
        ctr = total_clicks / total_impressions if total_impressions else 0.0
        engagement_proxy = round(min(ctr * 10, 1.0), 3)  # تطبيع تقريبي فقط

        return StepResult(
            step_name="run_sentiment_model",
            success=True,
            data={
                "overall_sentiment": None,
                "engagement_proxy_ctr": round(ctr, 4),
                "engagement_score_normalized": engagement_proxy,
                "crisis_detected": False,
                "note": "لا يوجد مصدر بيانات مشاعر نصية فعلي؛ هذا مؤشر تفاعل تقريبي من CTR فقط"
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if combined.get("expected_roi") is not None:
            insights.append(f"📈 ROI المتوقع: {combined['expected_roi']}x (تحسن {combined.get('improvement', '')})")
            recommendations.append("🎯 نفذ خطة إعادة تخصيص الميزانية")

        sentiment = combined.get("overall_sentiment")
        if sentiment is not None:
            if sentiment < 0.5:
                warnings.append("⚠️ المشاعر السلبية مرتفعة - رد فعل سريع مطلوب")
            else:
                insights.append(f"😊 المشاعر الإيجابية: {sentiment:.0%}")
        elif combined.get("engagement_score_normalized") is not None:
            insights.append(f"📊 مؤشر تفاعل تقريبي (CTR): {combined['engagement_score_normalized']:.0%}")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.84,
            explanation="تم تحليل التسويق وتحسين الحملات",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
