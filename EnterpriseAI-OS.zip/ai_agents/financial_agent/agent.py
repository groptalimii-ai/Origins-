#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Financial Agent
وكيل الإدارة المالية
"""

import logging
from typing import Dict, Any, List
from datetime import datetime, timedelta

import pandas as pd
import numpy as np
from prophet import Prophet
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class FinancialAgent(BaseAgent):
    """وكيل الإدارة المالية المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="FinancialAgent",
            description="وكيل متخصص في الإدارة المالية والتنبؤات المالية",
            capabilities=[
                "cash_flow_forecast",
                "budget_optimization",
                "fraud_detection",
                "financial_reporting",
                "expense_analysis",
                "revenue_prediction",
                "debt_management",
                "investment_screening"
            ],
            models=[
                "finbert-base",
                "time-series-transformer",
                "anomaly-detection-v2"
            ],
            data_sources=[
                "transactions",
                "budgets",
                "invoices",
                "bank_statements",
                "financial_reports"
            ],
            confidence_threshold=0.88
        ))
        self.forecast_model = None
        self.fraud_model = None

    async def initialize(self):
        await super().initialize()
        # تهيئة نماذج التنبؤ
        await self._init_forecast_model()
        await self._init_fraud_model()

    async def _init_forecast_model(self):
        """تهيئة نموذج التنبؤ"""
        self.forecast_model = Prophet(
            yearly_seasonality=True,
            weekly_seasonality=True,
            daily_seasonality=False,
            changepoint_prior_scale=0.05
        )

    async def _init_fraud_model(self):
        """
        تهيئة نموذج كشف الاحتيال.

        إصلاح حرج: كانت هذه الدالة تستدعي from_pretrained() (تحميل شبكي فعلي من
        Hugging Face Hub) بلا أي شرط، بمعزل تام عن علم settings.MODEL_LOADING_ENABLED
        الذي أضافته الجولة الرابعة خصيصًا لمنع هذا النوع بالضبط من التأخير/الفشل عند
        كل إقلاع للتطبيق (راجع base_agent._load_llm). بما أن FinancialAgent يملك
        initialize() خاصًا به يستدعي _init_fraud_model مباشرة، كان هذا المسار يتجاوز
        الحماية تمامًا: كل إقلاع (تطوير/اختبار/CI بلا شبكة) كان يعلق لمهلة شبكة طويلة
        ثم يفشل بصمت (except عارٍ) - بالضبط نفس العطل الذي زُعم إصلاحه في الجولة
        الرابعة، لكنه بقي حيًا في هذا المسار تحديدًا لأنه غير مُغطى بواسطة base_agent.
        """
        from core.config import settings

        if not settings.MODEL_LOADING_ENABLED:
            logger.info(
                "⏭️ تخطي تحميل نموذج كشف الاحتيال (FinancialAgent) "
                "(MODEL_LOADING_ENABLED=false - راجع core/config.py)"
            )
            self.fraud_model = None
            return

        try:
            self.fraud_model = AutoModelForSequenceClassification.from_pretrained(
                "distilbert-base-uncased",
                num_labels=2
            )
        except Exception as e:
            logger.warning(f"تعذّر تحميل نموذج كشف الاحتيال، سيُستخدم كشف قائم على قواعد: {e}")
            self.fraud_model = None

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        """التخطيط المالي"""

        if task.type == "cash_flow_forecast":
            return Plan(steps=[
                Step("gather_transactions", {"period": "5_years"}),
                Step("clean_data", {"remove_outliers": True}),
                Step("analyze_seasonality", {"methods": ["yearly", "monthly", "weekly"]}),
                Step("build_forecast_model", {"algorithm": "prophet", "horizon": 90}),
                Step("validate_predictions", {"confidence_threshold": 0.85}),
                Step("generate_report", {"include_charts": True, "language": "ar"})
            ], estimated_time=45.0)

        elif task.type == "budget_optimization":
            return Plan(steps=[
                Step("gather_budget_data", {"departments": "all"}),
                Step("analyze_spending_patterns", {}),
                Step("identify_inefficiencies", {}),
                Step("optimize_allocations", {"method": "linear_programming"}),
                Step("simulate_scenarios", {"scenarios": ["best", "worst", "expected"]}),
                Step("generate_recommendations", {})
            ], estimated_time=60.0)

        elif task.type == "fraud_detection":
            return Plan(steps=[
                Step("scan_transactions", {"period": "30_days"}),
                Step("apply_anomaly_detection", {"sensitivity": "high"}),
                Step("cross_reference_patterns", {"historical": True}),
                Step("calculate_risk_scores", {}),
                Step("flag_suspicious", {"threshold": 0.8}),
                Step("generate_alert", {"urgency": "immediate"})
            ], estimated_time=15.0)

        elif task.type == "expense_analysis":
            return Plan(steps=[
                Step("categorize_expenses", {"ai_classification": True}),
                Step("compare_to_budget", {"variance_threshold": 0.1}),
                Step("identify_trends", {"period": "12_months"}),
                Step("benchmark_against_industry", {}),
                Step("generate_savings_opportunities", {})
            ], estimated_time=30.0)

        else:
            return Plan(steps=[
                Step("analyze_request", {}),
                Step("gather_relevant_data", {}),
                Step("process_with_ai", {}),
                Step("generate_response", {})
            ], estimated_time=20.0)

    async def execute_step(self, step: Step) -> StepResult:
        """تنفيذ الخطوة المالية"""

        if step.name == "build_forecast_model":
            return await self._step_build_forecast(step.params)
        elif step.name == "optimize_allocations":
            return await self._step_optimize_budget(step.params)
        elif step.name == "apply_anomaly_detection":
            return await self._step_detect_fraud(step.params)
        elif step.name == "categorize_expenses":
            return await self._step_categorize_expenses(step.params)
        elif step.name == "gather_transactions":
            return await self._step_gather_transactions(step.params)
        else:
            return StepResult(
                step_name=step.name,
                success=True,
                data={"status": "completed", "step": step.name}
            )

    async def _step_build_forecast(self, params: Dict) -> StepResult:
        """
        بناء نموذج التنبؤ (Prophet) على معاملات الدخل الفعلية.

        إصلاح (الجولة الحادية عشرة): هذه كانت الدالة الوحيدة المتبقية في هذا الملف
        التي لم تُشمل بتنظيف الجولة الثانية:
        1) لم يكن فيها أي تحقق من عدم وجود بيانات - على عكس كل دالة أخرى في هذا
           الملف - فكانت `pd.DataFrame(transactions["rows"])` مع صفوف فارغة تنتج
           DataFrame بلا أعمدة، فيفشل `df.columns = ['ds', 'y', 'type']` بـ
           ValueError (يُبتلَع بالخطأ العام try/except فيُعيد رسالة خطأ غامضة
           بدل "لا توجد بيانات" الواضحة مثل بقية الدوال).
        2) `metrics={"mape": 0.05, "rmse": 15000}` كانت قيمًا وهمية ثابتة تمامًا -
           بالضبط نفس نمط "الأرقام الثابتة" الذي وثّقت الجولة الثانية استبداله في كل
           الوكلاء الآخرين، لكنه بقي هنا تحديدًا دون أن يُلاحَظ. الآن تُحسَب MAPE/RMSE
           فعليًا من مقارنة قيم Prophet المُتوقَّعة (yhat) بالقيم الفعلية على بيانات
           التدريب نفسها (in-sample)، بدل رقمين ثابتين لا علاقة لهما بالبيانات.
        """
        transactions = await self.tools.execute(
            "query_database",
            query="SELECT date, amount, type FROM transactions WHERE date >= NOW() - INTERVAL '5 years'"
        )
        rows = transactions.get("rows", [])

        if not rows:
            return StepResult(
                step_name="build_forecast_model",
                success=True,
                data={
                    "forecast": {}, "trend": [], "seasonality": [],
                    "confidence_intervals": {"lower": [], "upper": []},
                    "note": "لا توجد معاملات مسجّلة خلال آخر 5 سنوات لبناء نموذج تنبؤ"
                },
                metrics={"mape": None, "rmse": None}
            )

        try:
            df = pd.DataFrame(rows)
            df.columns = ['ds', 'y', 'type']

            income_df = df[df['type'] == 'income'][['ds', 'y']]
            if len(income_df) < 2:
                return StepResult(
                    step_name="build_forecast_model",
                    success=True,
                    data={
                        "forecast": {}, "trend": [], "seasonality": [],
                        "confidence_intervals": {"lower": [], "upper": []},
                        "note": "بيانات دخل غير كافية (أقل من نقطتين) لتدريب نموذج Prophet"
                    },
                    metrics={"mape": None, "rmse": None}
                )

            # تدريب النموذج
            self.forecast_model.fit(income_df)

            # التنبؤ
            future = self.forecast_model.make_future_dataframe(periods=params.get('horizon', 90))
            forecast = self.forecast_model.predict(future)

            # مقاييس دقة فعلية (in-sample): مقارنة yhat بالقيم الفعلية على فترة التدريب
            merged = income_df.merge(forecast[['ds', 'yhat']], on='ds', how='inner')
            if len(merged) > 0:
                errors = (merged['y'] - merged['yhat']).abs()
                nonzero = merged['y'] != 0
                mape = float((errors[nonzero] / merged['y'][nonzero]).mean()) if nonzero.any() else None
                rmse = float(np.sqrt((errors ** 2).mean()))
            else:
                mape, rmse = None, None

            return StepResult(
                step_name="build_forecast_model",
                success=True,
                data={
                    "forecast": forecast.tail(params.get('horizon', 90)).to_dict(),
                    "trend": forecast['trend'].tolist(),
                    "seasonality": forecast['yearly'].tolist() if 'yearly' in forecast else [],
                    "confidence_intervals": {
                        "lower": forecast['yhat_lower'].tolist(),
                        "upper": forecast['yhat_upper'].tolist()
                    }
                },
                metrics={
                    "mape": round(mape, 4) if mape is not None else None,
                    "rmse": round(rmse, 2) if rmse is not None else None,
                }
            )

        except Exception as e:
            logger.error(f"فشل بناء نموذج التنبؤ المالي: {e}")
            return StepResult(
                step_name="build_forecast_model",
                success=False,
                data={"error": str(e)}
            )

    async def _step_optimize_budget(self, params: Dict) -> StepResult:
        """
        تحسين الميزانية - يستعلم جدول budgets الفعلي بدل الأرقام الثابتة السابقة
        (كانت ترجع نفس القيم الحرفية 85000/195000/180000 بغض النظر عن أي بيانات).
        المنطق: لكل قسم، نقارن المُخصَّص (allocated) بالمُستهلك فعلياً (spent)؛
        القسم الذي يستهلك أقل بكثير من المخصص (فائض) نقترح تخفيضه، والقسم الذي
        يستهلك كل مخصصه تقريباً (عجز/ضغط) نقترح زيادته.
        """
        result = await self.tools.execute(
            "query_database",
            query="SELECT department, SUM(allocated) AS allocated, SUM(spent) AS spent "
                  "FROM budgets GROUP BY department"
        )
        rows = result.get("rows", [])

        if not rows:
            return StepResult(
                step_name="optimize_allocations",
                success=True,
                data={
                    "optimized_budget": {},
                    "total_savings": 0,
                    "note": "لا توجد بيانات ميزانيات (جدول budgets) لتحليلها بعد"
                }
            )

        optimized = {}
        total_savings = 0.0
        for row in rows:
            dept = row["department"]
            allocated = float(row["allocated"] or 0)
            spent = float(row["spent"] or 0)
            if allocated <= 0:
                continue

            utilization = spent / allocated
            if utilization < 0.7:
                # فائض واضح: نقترح تخفيض المخصص إلى قريب من الاستهلاك الفعلي + هامش أمان 15%
                new_allocation = round(spent * 1.15, 2)
                savings = round(allocated - new_allocation, 2)
                optimized[dept] = {"current": allocated, "optimized": new_allocation, "savings": savings}
                total_savings += savings
            elif utilization > 0.95:
                # القسم يستهلك كل ميزانيته تقريباً: نقترح زيادة 10%
                new_allocation = round(allocated * 1.10, 2)
                increase = round(new_allocation - allocated, 2)
                optimized[dept] = {"current": allocated, "optimized": new_allocation, "increase": increase}
            else:
                optimized[dept] = {"current": allocated, "optimized": allocated, "savings": 0}

        return StepResult(
            step_name="optimize_allocations",
            success=True,
            data={
                "optimized_budget": optimized,
                "total_savings": round(total_savings, 2),
            }
        )

    async def _step_detect_fraud(self, params: Dict) -> StepResult:
        """
        كشف الاحتيال - تطبيق فعلي لقواعد بسيطة على معاملات آخر 30 يوماً بدل
        القائمة الفارغة الثابتة سابقاً (كانت suspicious=[] و risk_score=0.15 دائماً
        بغض النظر عن أي بيانات، أي أن كشف الاحتيال لم يكن يعمل إطلاقاً).
        """
        period_days = 30
        result = await self.tools.execute(
            "query_database",
            query=f"SELECT id, date, amount, type, vendor, vendor_first_seen, is_flagged "
                  f"FROM transactions WHERE date >= NOW() - INTERVAL '{period_days} days'"
        )
        rows = result.get("rows", [])

        flagged = []
        for row in rows:
            reasons = []
            amount = float(row["amount"] or 0)
            if amount > 100000:
                reasons.append("large_amount")
            if row.get("date") and hasattr(row["date"], "hour"):
                hour = row["date"].hour
                if hour < 6 or hour > 22:
                    reasons.append("off_hours")
            if row.get("vendor_first_seen") and row.get("date"):
                try:
                    age_days = (row["date"] - row["vendor_first_seen"]).days
                    if age_days < 30:
                        reasons.append("new_vendor")
                except TypeError:
                    pass
            if row.get("is_flagged"):
                reasons.append("manually_flagged")

            if reasons:
                flagged.append({
                    "id": row["id"], "amount": amount,
                    "vendor": row.get("vendor"), "reasons": reasons,
                    "risk": "high" if "large_amount" in reasons or "manually_flagged" in reasons else "medium",
                })

        risk_score = round(len(flagged) / len(rows), 3) if rows else 0.0

        return StepResult(
            step_name="apply_anomaly_detection",
            success=True,
            data={
                "flagged_transactions": flagged,
                "risk_score": risk_score,
                "transactions_scanned": len(rows),
                "requires_review": len(flagged) > 0
            }
        )

    async def _step_categorize_expenses(self, params: Dict) -> StepResult:
        """
        تصنيف المصروفات - نسب فعلية محسوبة من جدول transactions (type='expense')
        لآخر 12 شهراً، بدل النسب الثابتة السابقة (0.35/0.20/0.30/0.10/0.05 دائماً).
        """
        result = await self.tools.execute(
            "query_database",
            query="SELECT category, SUM(amount) AS total FROM transactions "
                  "WHERE type = 'expense' AND date >= NOW() - INTERVAL '12 months' "
                  "GROUP BY category"
        )
        rows = result.get("rows", [])
        grand_total = sum(float(r["total"] or 0) for r in rows)

        if grand_total <= 0:
            return StepResult(
                step_name="categorize_expenses",
                success=True,
                data={"categories": {}, "note": "لا توجد معاملات مصروفات مسجّلة خلال آخر 12 شهراً"}
            )

        categories = {}
        uncategorized = 0.0
        for row in rows:
            share = float(row["total"] or 0) / grand_total
            if row["category"]:
                categories[row["category"]] = round(share, 4)
            else:
                uncategorized += share

        return StepResult(
            step_name="categorize_expenses",
            success=True,
            data={
                "categories": categories,
                "uncategorized": round(uncategorized, 4),
                "total_expenses": round(grand_total, 2),
            }
        )

    async def _step_gather_transactions(self, params: Dict) -> StepResult:
        """جمع المعاملات - عدد ومصادر فعلية من transactions بدل count=15000 الثابت سابقاً"""
        period = params.get("period", "5_years")
        years = 5
        if period.endswith("_years"):
            try:
                years = int(period.split("_")[0])
            except ValueError:
                years = 5

        result = await self.tools.execute(
            "query_database",
            query=f"SELECT COUNT(*) AS count FROM transactions "
                  f"WHERE date >= NOW() - INTERVAL '{years} years'"
        )
        rows = result.get("rows", [])
        count = int(rows[0]["count"]) if rows else 0

        return StepResult(
            step_name="gather_transactions",
            success=True,
            data={
                "period": period,
                "count": count,
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        """تجميع النتائج المالية"""

        combined = {}
        for result in results:
            combined.update(result.data)

        # توليد الرؤى
        insights = []
        recommendations = []
        warnings = []

        if "forecast" in combined and combined.get("trend"):
            # إصلاح: كانت العبارة "إيجابي" ثابتة دائمًا بغض النظر عن اتجاه forecast['trend']
            # الفعلي - حتى عند وجود اتجاه سلبي واضح. الآن تُشتق من بيانات الاتجاه الفعلية.
            trend_values = combined.get("trend", [])
            trend_direction = "إيجابي" if trend_values[-1] >= trend_values[0] else "سلبي"
            insights.append(f"التدفق النقدي المتوقع للـ 90 يوم القادمة: {trend_direction}")

            if any(v < 0 for v in trend_values):
                warnings.append("⚠️ هناك انخفاض متوقع في التدفق النقدي بعد 60 يوم")
                recommendations.append("💡 يُنصح بتأجيل المصروفات غير الضرورية")

        if "optimized_budget" in combined:
            savings = combined.get("total_savings", 0)
            if savings > 0:
                insights.append(f"💰 تم تحديد فرص توفير بقيمة ${savings:,}")
                recommendations.append("📊 راجع اقتراحات إعادة تخصيص الميزانية")

        if "flagged_transactions" in combined:
            flagged = combined["flagged_transactions"]
            if len(flagged) > 0:
                warnings.append(f"🚨 تم رفع {len(flagged)} معاملة مشبوهة للمراجعة")
                recommendations.append("🔍 راجع المعاملات المرفوعة فوراً")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.92,
            explanation=f"تم تحليل البيانات المالية وإعداد {len(insights)} رؤى و {len(recommendations)} توصية",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
