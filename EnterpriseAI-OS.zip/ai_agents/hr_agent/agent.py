#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - HR Agent
وكيل الموارد البشرية
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class HRAgent(BaseAgent):
    """وكيل الموارد البشرية المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="HRAgent",
            description="وكيل متخصص في التوظيف الذكي وإدارة الأداء",
            capabilities=[
                "resume_screening",
                "performance_prediction",
                "retention_analysis",
                "succession_planning",
                "skill_gap_analysis",
                "compensation_benchmarking",
                "engagement_scoring",
                "diversity_analytics"
            ],
            models=["resume-parser", "performance-predictor", "retention-model"],
            data_sources=["employees", "applicants", "performance_reviews", "payroll", "surveys"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        # إصلاح (الجولة الثانية عشرة): راوتات /hr/ai/recruitment-screening و
        # /hr/ai/retention-analysis ترسلان task_type="recruitment"/"performance"
        # (مطابقة لمفاتيح orchestrator.select_optimal_agent التي توجّه بنجاح لهذا
        # الوكيل)، لكن هذا الشرط كان يتحقق من "resume_screening" حصرًا (وأدناه
        # "retention_analysis" حصرًا) - فكان التوجيه للوكيل ينجح لكن plan() يسقط
        # دومًا للخطة العامة بلا أي منطق HR فعلي.
        if task.type in ("resume_screening", "recruitment"):
            return Plan(steps=[
                Step("parse_resume", {"extract": ["skills", "experience", "education"]}),
                Step("match_jd", {"threshold": 0.75}),
                Step("score_candidate", {"criteria": ["technical", "cultural", "potential"]}),
                Step("check_red_flags", {}),
                Step("rank_candidates", {}),
                Step("generate_interview_questions", {})
            ], estimated_time=20.0)
        elif task.type in ("retention_analysis", "performance"):
            return Plan(steps=[
                Step("gather_employee_data", {"period": "2_years"}),
                Step("calculate_engagement", {"sources": ["surveys", "activity", "peers"]}),
                Step("predict_churn_risk", {"horizon": 90}),
                Step("identify_factors", {}),
                Step("generate_retention_plan", {})
            ], estimated_time=35.0)
        else:
            return Plan(steps=[
                Step("analyze_hr_request", {}),
                Step("process_data", {}),
                Step("generate_recommendation", {})
            ], estimated_time=20.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "score_candidate":
            return await self._step_score_candidate(step.params)
        elif step.name == "predict_churn_risk":
            return await self._step_predict_churn_risk(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_score_candidate(self, params: Dict) -> StepResult:
        """
        لا يوجد جدول 'applicants' في المخطط الحالي، لذا لا يمكن تصنيف مرشح فعلي حاليًا
        (كانت النتيجة 0.87/Strong Hire ثابتة دومًا سابقًا بغض النظر عن أي مدخل).
        بدلًا من الادعاء بتقييم مرشح غير موجود، نرجّع مقارنة معيارية حقيقية مبنية على
        متوسط performance_score للموظفين الحاليين في نفس القسم، لتُستخدم كخط أساس.
        """
        department = params.get("department")
        query = "SELECT AVG(performance_score) AS avg_perf, COUNT(*) AS n FROM employees WHERE is_active = true"
        if department:
            query += " AND department = :department"
        result = await self.tools.execute("query_database", query=query,
                                           params={"department": department} if department else None)
        rows = result.get("rows", [])
        avg_perf = float(rows[0]["avg_perf"]) if rows and rows[0].get("avg_perf") else None

        return StepResult(
            step_name="score_candidate",
            success=True,
            data={
                "candidate_id": None,
                "baseline_department_performance": round(avg_perf, 3) if avg_perf is not None else None,
                "note": "لا يوجد جدول applicants/سير ذاتية في المخطط الحالي — "
                        "لا يمكن تصنيف مرشح فعلي؛ هذا خط أساس من أداء الموظفين الحاليين فقط"
            }
        )

    async def _step_predict_churn_risk(self, params: Dict) -> StepResult:
        """
        تقدير خطر مغادرة الموظفين من بيانات employees الفعلية (بدل قائمة Ahmed/Sara
        ثابتة سابقًا): موظف عالي الخطورة إن كان performance_score منخفضًا نسبيًا للقسم
        أو الراتب أقل من متوسط القسم بشكل ملحوظ (فجوة تعويض تقريبية).
        """
        employees_result = await self.tools.execute(
            "query_database",
            query="SELECT id, full_name, department, salary, performance_score, hire_date "
                  "FROM employees WHERE is_active = true"
        )
        employees = employees_result.get("rows", [])

        if not employees:
            return StepResult(
                step_name="predict_churn_risk", success=True,
                data={"at_risk_employees": [], "overall_turnover_prediction": 0.0, "cost_of_turnover": 0}
            )

        by_dept: Dict[str, List[Dict]] = {}
        for e in employees:
            by_dept.setdefault(e.get("department") or "unknown", []).append(e)

        at_risk = []
        for dept, emps in by_dept.items():
            salaries = [float(e["salary"]) for e in emps if e.get("salary") is not None]
            avg_salary = sum(salaries) / len(salaries) if salaries else 0
            for e in emps:
                perf = e.get("performance_score")
                salary = float(e["salary"]) if e.get("salary") is not None else None
                risk_score = 0.0
                reason = None
                if perf is not None and perf < 0.6:
                    risk_score = max(risk_score, 0.8 - perf)
                    reason = "low_engagement"
                if salary is not None and avg_salary > 0 and salary < avg_salary * 0.85:
                    comp_risk = round((avg_salary - salary) / avg_salary, 2)
                    if comp_risk > risk_score:
                        risk_score = comp_risk
                        reason = "compensation_gap"
                if risk_score >= 0.3:
                    at_risk.append({
                        "id": e["id"], "name": e["full_name"],
                        "risk_score": round(risk_score, 2), "reason": reason
                    })

        at_risk.sort(key=lambda a: a["risk_score"], reverse=True)
        overall_turnover_prediction = round(len(at_risk) / len(employees), 3) if employees else 0.0
        avg_salary_all = sum(float(e["salary"]) for e in employees if e.get("salary") is not None) / max(
            sum(1 for e in employees if e.get("salary") is not None), 1
        )
        cost_of_turnover = round(len(at_risk) * avg_salary_all * 0.5, 2)  # تقدير: نصف الراتب السنوي لكل استبدال

        return StepResult(
            step_name="predict_churn_risk",
            success=True,
            data={
                "at_risk_employees": at_risk[:20],
                "overall_turnover_prediction": overall_turnover_prediction,
                "cost_of_turnover": cost_of_turnover
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if "at_risk_employees" in combined:
            at_risk = combined["at_risk_employees"]
            if len(at_risk) > 0:
                warnings.append(f"⚠️ {len(at_risk)} موظفين معرضين لمغادرة الشركة")
                recommendations.append("🤝 اجتماعات فردية مع الموظفين المعرضين للمخاطر")

        if "overall_score" in combined and combined["overall_score"] > 0.85:
            insights.append("🌟 مرشح ممتاز - يُنصح بالتوظيف السريع")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.88,
            explanation="تم تحليل الموارد البشرية وإعداد التوصيات",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
