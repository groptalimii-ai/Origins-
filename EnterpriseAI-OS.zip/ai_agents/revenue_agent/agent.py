#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Revenue Agent
وكيل الإيرادات
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class RevenueAgent(BaseAgent):
    """وكيل الإيرادات المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="RevenueAgent",
            description="وكيل متخصص في تحسين الإيرادات والتسعير الديناميكي",
            capabilities=[
                "revenue_forecasting",
                "dynamic_pricing",
                "sales_cycle_analysis",
                "lead_scoring",
                "churn_prediction",
                "upsell_opportunity",
                "pricing_elasticity",
                "revenue_attribution"
            ],
            models=["revenue-forecaster", "pricing-optimizer", "churn-predictor"],
            data_sources=["sales_data", "customer_data", "pricing_history", "market_data"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        if task.type == "revenue_forecast":
            return Plan(steps=[
                Step("gather_sales_history", {"period": "3_years"}),
                Step("segment_customers", {"method": "rfm"}),
                Step("analyze_pipeline", {"stages": "all"}),
                Step("build_forecast", {"models": ["arima", "prophet", "ensemble"]}),
                Step("calculate_confidence", {}),
                Step("generate_scenarios", {"best": True, "worst": True})
            ], estimated_time=40.0)
        elif task.type in ("pricing_optimization", "pricing"):
            # إصلاح (الجولة الثانية عشرة): راوت /revenue/ai/pricing-optimization يرسل
            # task_type="pricing" (مطابق لمفتاح orchestrator الذي يوجّه بنجاح لهذا
            # الوكيل)، لكن هذا الشرط كان يتحقق من "pricing_optimization" حصرًا -
            # فيسقط دومًا للخطة العامة بلا أي تحليل تسعير فعلي.
            return Plan(steps=[
                Step("gather_pricing_data", {}),
                Step("calculate_elasticity", {"method": "log_log_regression"}),
                Step("analyze_competitors", {"sources": ["web_scraping", "reports"]}),
                Step("optimize_prices", {"objective": "max_revenue"}),
                Step("simulate_impact", {}),
                Step("generate_pricing_table", {})
            ], estimated_time=50.0)
        else:
            return Plan(steps=[
                Step("analyze_revenue_request", {}),
                Step("process_data", {}),
                Step("generate_insights", {})
            ], estimated_time=20.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "build_forecast":
            return await self._step_build_forecast(step.params)
        elif step.name == "optimize_prices":
            return await self._step_optimize_prices(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_build_forecast(self, params: Dict) -> StepResult:
        """
        تنبؤ الإيرادات من بيانات transactions الفعلية (النوع income) عبر نمو المتوسط
        الشهري لآخر سنة (بدل 2,850,000 ثابت سابقًا). يُستخدم growth_rate الفعلي
        المُشتق من مقارنة نصفي الفترة.
        """
        txn_result = await self.tools.execute(
            "query_database",
            query="SELECT date, amount, department FROM transactions "
                  "WHERE type = 'income' AND date >= NOW() - INTERVAL '365 days' ORDER BY date"
        )
        rows = txn_result.get("rows", [])

        if not rows:
            return StepResult(
                step_name="build_forecast", success=True,
                data={"next_quarter_revenue": None, "growth_rate": None, "confidence": 0.0,
                      "note": "لا توجد معاملات دخل مسجّلة في آخر سنة"}
            )

        total_revenue = sum(float(r["amount"]) for r in rows)
        n_days = 365
        monthly_avg = total_revenue / (n_days / 30.0)

        half = len(rows) // 2
        first_half = sum(float(r["amount"]) for r in rows[:half]) if half else 0
        second_half = sum(float(r["amount"]) for r in rows[half:]) if half else total_revenue
        growth_rate = round((second_half - first_half) / first_half, 3) if first_half > 0 else 0.0

        next_quarter_expected = round(monthly_avg * 3 * (1 + growth_rate), 2)
        best_case = round(next_quarter_expected * 1.15, 2)
        worst_case = round(next_quarter_expected * 0.85, 2)

        by_dept: Dict[str, float] = {}
        for r in rows:
            dept = r.get("department") or "unassigned"
            by_dept[dept] = by_dept.get(dept, 0.0) + float(r["amount"])

        return StepResult(
            step_name="build_forecast",
            success=True,
            data={
                "next_quarter_revenue": next_quarter_expected,
                "growth_rate": growth_rate,
                "confidence": 0.7 if len(rows) > 30 else 0.4,
                "scenarios": {"best_case": best_case, "expected": next_quarter_expected, "worst_case": worst_case},
                "by_segment": {k: round(v, 2) for k, v in by_dept.items()}
            }
        )

    async def _step_optimize_prices(self, params: Dict) -> StepResult:
        """
        لا يوجد جدول أسعار منتجات (product pricing) صريح في المخطط الحالي، فلا يمكن
        تحسين تسعير فعلي (كانت product_a/b/c ثابتة سابقًا). نُرجع بدلاً من ذلك تحليل
        مرونة تقريبي من متوسط قيمة المعاملة حسب القسم كمؤشر استرشادي فقط.
        """
        txn_result = await self.tools.execute(
            "query_database",
            query="SELECT department, AVG(amount) AS avg_amount, COUNT(*) AS n "
                  "FROM transactions WHERE type = 'income' AND date >= NOW() - INTERVAL '180 days' "
                  "GROUP BY department"
        )
        rows = txn_result.get("rows", [])

        if not rows:
            return StepResult(
                step_name="optimize_prices", success=True,
                data={"recommended_prices": {}, "overall_impact": "0%",
                      "note": "لا يوجد جدول تسعير منتجات في المخطط الحالي، ولا بيانات كافية لمؤشر استرشادي"}
            )

        recommended = {}
        for r in rows:
            dept = r.get("department") or "unassigned"
            avg_amount = float(r["avg_amount"])
            recommended[dept] = {
                "avg_transaction_value": round(avg_amount, 2),
                "sample_size": r["n"]
            }

        return StepResult(
            step_name="optimize_prices",
            success=True,
            data={
                "recommended_prices": recommended,
                "overall_impact": None,
                "note": "لا يوجد جدول تسعير منتجات صريح؛ هذه متوسطات قيمة المعاملات فقط كمرجع استرشادي"
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if combined.get("next_quarter_revenue") is not None:
            insights.append(f"💰 الإيرادات المتوقعة للربع القادم: ${combined['next_quarter_revenue']:,.2f}")

        if combined.get("recommended_prices"):
            insights.append("📊 تم إعداد تحليل استرشادي لمتوسط قيم المعاملات حسب القسم")
            recommendations.append("🔄 راجع مؤشرات القيمة قبل أي تعديل فعلي على التسعير")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.86,
            explanation="تم تحليل الإيرادات وتحسين التسعير",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
