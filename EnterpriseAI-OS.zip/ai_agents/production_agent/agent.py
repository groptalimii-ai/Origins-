#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Production Agent
وكيل إدارة الإنتاج
"""

import logging
from typing import Dict, Any, List
from datetime import datetime, timedelta

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class ProductionAgent(BaseAgent):
    """وكيل إدارة الإنتاج المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="ProductionAgent",
            description="وكيل متخصص في جدولة الإنتاج والصيانة التنبؤية",
            capabilities=[
                "production_scheduling",
                "predictive_maintenance",
                "quality_control",
                "capacity_planning",
                "energy_optimization",
                "waste_reduction",
                "oee_calculation",
                "bottleneck_analysis"
            ],
            models=[
                "production-scheduler",
                "maintenance-predictor",
                "quality-inspector"
            ],
            data_sources=[
                "production_lines",
                "machinery_data",
                "quality_records",
                "energy_consumption",
                "work_orders"
            ]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        if task.type == "production_schedule":
            return Plan(steps=[
                Step("gather_orders", {"period": "next_30_days"}),
                Step("check_capacity", {"lines": "all"}),
                Step("optimize_sequence", {"objective": "minimize_changeover"}),
                Step("allocate_resources", {"workers": True, "materials": True}),
                Step("schedule_maintenance", {"avoid_peak": True}),
                Step("generate_gantt", {})
            ], estimated_time=50.0)

        elif task.type in ("predictive_maintenance", "quality_check"):
            # إصلاح (الجولة الثانية عشرة): راوت /production/ai/quality-check يرسل
            # task_type="quality_check" (مطابق لمفتاح orchestrator الذي يوجّه بنجاح
            # لهذا الوكيل)، لكن لم يكن له أي فرع مطابق هنا إطلاقًا - فيسقط دومًا
            # للخطة العامة. لا توجد خطوة "فحص جودة" منفصلة فعليًا في execute_step
            # (فقط optimize_sequence وpredict_failures)، وpredict_failures أصلاً
            # مبنية على avg_defect_rate الفعلي من production_orders - وهو بالضبط
            # مؤشر الجودة المطلوب - لذا رُبطت quality_check بنفس خطة الصيانة
            # التنبؤية بدل تركها بلا أي تنفيذ فعلي.
            return Plan(steps=[
                Step("gather_sensor_data", {"machines": "all", "period": "90_days"}),
                Step("analyze_vibration", {"threshold": 0.8}),
                Step("predict_failures", {"horizon": 30}),
                Step("prioritize_repairs", {"cost_impact": True}),
                Step("schedule_downtime", {"minimize_production_impact": True})
            ], estimated_time=35.0)

        else:
            return Plan(steps=[
                Step("analyze_production_request", {}),
                Step("gather_line_data", {}),
                Step("optimize_with_ai", {}),
                Step("generate_schedule", {})
            ], estimated_time=25.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "optimize_sequence":
            return await self._step_optimize_sequence(step.params)
        elif step.name == "predict_failures":
            return await self._step_predict_failures(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_optimize_sequence(self, params: Dict) -> StepResult:
        """
        ترتيب أوامر الإنتاج المجدولة فعليًا من production_orders (بدل تسلسل ثابت
        Product A/C/B/D سابقًا): نرتّب حسب موعد البدء المجدوَل ونجمّع حسب product_sku
        لتقليل التبديل بين نفس المنتج.
        """
        orders_result = await self.tools.execute(
            "query_database",
            query="SELECT id, product_sku, quantity, machine_id, scheduled_start, scheduled_end, status "
                  "FROM production_orders WHERE status IN ('scheduled', 'in_progress') "
                  "ORDER BY scheduled_start ASC LIMIT 200"
        )
        orders = orders_result.get("rows", [])

        if not orders:
            return StepResult(
                step_name="optimize_sequence", success=True,
                data={"optimized_sequence": [], "changeover_time_saved": "0 minutes", "efficiency_gain": "0%",
                      "note": "لا توجد أوامر إنتاج مجدولة حاليًا"}
            )

        # تجميع حسب SKU للحد من عدد مرات التبديل بين المنتجات على نفس الآلة
        grouped_sequence = sorted(orders, key=lambda o: (o.get("machine_id") or "", o.get("product_sku") or ""))
        optimized_sequence = [o["product_sku"] for o in grouped_sequence]

        # تقدير الوقت الموفَّر: عدد مرات التبديل الفعلية قبل/بعد إعادة الترتيب
        original_switches = sum(
            1 for i in range(1, len(orders)) if orders[i]["product_sku"] != orders[i - 1]["product_sku"]
        )
        optimized_switches = sum(
            1 for i in range(1, len(grouped_sequence))
            if grouped_sequence[i]["product_sku"] != grouped_sequence[i - 1]["product_sku"]
        )
        switches_saved = max(original_switches - optimized_switches, 0)
        efficiency_gain = round((switches_saved / original_switches) * 100, 1) if original_switches else 0.0

        return StepResult(
            step_name="optimize_sequence",
            success=True,
            data={
                "optimized_sequence": optimized_sequence,
                "changeover_time_saved": f"{switches_saved * 15} minutes",
                "efficiency_gain": f"{efficiency_gain}%"
            }
        )

    async def _step_predict_failures(self, params: Dict) -> StepResult:
        """
        تقدير خطر التعطل بناءً على معدل العيوب الفعلي defect_rate وحالة delayed
        في production_orders (بدل قائمة ثابتة M-001/M-003 سابقًا)، كبديل معقول
        لعدم وجود بيانات اهتزاز/حساسات فعلية في هذا المشروع.
        """
        machines_result = await self.tools.execute(
            "query_database",
            query="SELECT machine_id, AVG(defect_rate) AS avg_defect_rate, "
                  "SUM(CASE WHEN status = 'delayed' THEN 1 ELSE 0 END) AS delayed_count, "
                  "COUNT(*) AS total_orders "
                  "FROM production_orders WHERE machine_id IS NOT NULL "
                  "GROUP BY machine_id"
        )
        rows = machines_result.get("rows", [])

        machines_at_risk = []
        for r in rows:
            avg_defect = float(r.get("avg_defect_rate") or 0)
            delayed_ratio = (r["delayed_count"] / r["total_orders"]) if r["total_orders"] else 0
            failure_probability = round(min(avg_defect * 2 + delayed_ratio, 1.0), 2)
            if failure_probability > 0.4:
                machines_at_risk.append({
                    "machine_id": r["machine_id"],
                    "failure_probability": failure_probability,
                    "component": "غير محدد - يتطلب بيانات حساسات",
                    "basis": {"avg_defect_rate": round(avg_defect, 3), "delayed_ratio": round(delayed_ratio, 3)}
                })

        machines_at_risk.sort(key=lambda m: m["failure_probability"], reverse=True)

        return StepResult(
            step_name="predict_failures",
            success=True,
            data={
                "machines_at_risk": machines_at_risk,
                "maintenance_cost_avoided": None,
                "note": "التقدير مبني على معدل العيوب والتأخير الفعلي، وليس بيانات اهتزاز/حساسات (غير متوفرة في المخطط الحالي)"
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for result in results:
            combined.update(result.data)

        insights = []
        recommendations = []
        warnings = []

        if "machines_at_risk" in combined:
            machines = combined["machines_at_risk"]
            high_risk = [m for m in machines if m["failure_probability"] > 0.7]
            if high_risk:
                warnings.append(f"🚨 {len(high_risk)} آلة بحاجة صيانة عاجلة")
                recommendations.append("🔧 جدولة صيانة وقائية خلال 48 ساعة")

        if "efficiency_gain" in combined:
            insights.append(f"⚡ تم تحسين الكفاءة بنسبة {combined['efficiency_gain']}")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.90,
            explanation="تم تحليل الإنتاج وإعداد الجدول والتوصيات",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
