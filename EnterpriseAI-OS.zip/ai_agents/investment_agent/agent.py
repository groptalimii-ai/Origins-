#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Investment Agent
وكيل الاستثمارات
"""

import logging
import numpy as np
from typing import Dict, Any, List
from datetime import datetime, timedelta

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class InvestmentAgent(BaseAgent):
    """وكيل الاستثمارات المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="InvestmentAgent",
            description="وكيل متخصص في تحليل الفرص الاستثمارية وإدارة المحافظ",
            capabilities=[
                "opportunity_analysis",
                "portfolio_optimization",
                "risk_assessment",
                "monte_carlo_simulation",
                "market_sentiment_analysis",
                "due_diligence",
                "asset_allocation",
                "performance_attribution"
            ],
            models=["portfolio-optimizer", "risk-model", "sentiment-analyzer"],
            data_sources=["market_data", "portfolio_holdings", "economic_indicators", "news_feeds"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        # إصلاح (الجولة الثانية عشرة): راوت /investment/ai/portfolio-review يرسل
        # task_type="portfolio"، وراوت /investment/ai/analyze يرسل
        # task_type="investment_analysis" (كلاهما مطابق لمفاتيح orchestrator التي
        # توجّه بنجاح لهذا الوكيل)، لكن هذا الشرط كان يتحقق من "portfolio_analysis"
        # حصرًا (وأدناه "opportunity_screening" حصرًا لـ"investment_analysis") -
        # فيسقط كلا الراوتين دومًا للخطة العامة بلا أي محاكاة مونت كارلو أو تحليل
        # فعلي رغم توجيههما للوكيل الصحيح.
        if task.type in ("portfolio_analysis", "portfolio"):
            return Plan(steps=[
                Step("gather_holdings", {}),
                Step("calculate_metrics", {"sharpe": True, "sortino": True, "var": True}),
                Step("analyze_correlations", {}),
                Step("run_monte_carlo", {"simulations": 10000, "horizon": 252}),
                Step("optimize_allocation", {"objective": "max_sharpe"}),
                Step("generate_report", {"include_stress_test": True})
            ], estimated_time=60.0)
        elif task.type in ("opportunity_screening", "investment_analysis"):
            return Plan(steps=[
                Step("scan_market", {"universe": "all", "filters": task.data.get("filters", {})}),
                Step("fundamental_analysis", {"metrics": ["pe", "pb", "roe", "debt_ratio"]}),
                Step("technical_analysis", {"indicators": ["rsi", "macd", "bollinger"]}),
                Step("sentiment_scoring", {"sources": ["news", "social", "analyst"]}),
                Step("rank_opportunities", {}),
                Step("generate_watchlist", {})
            ], estimated_time=45.0)
        else:
            return Plan(steps=[
                Step("analyze_investment_request", {}),
                Step("gather_market_data", {}),
                Step("run_analysis", {}),
                Step("generate_recommendation", {})
            ], estimated_time=30.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "run_monte_carlo":
            return await self._step_run_monte_carlo(step.params)
        elif step.name == "optimize_allocation":
            return await self._step_optimize_allocation(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_run_monte_carlo(self, params: Dict) -> StepResult:
        """
        محاكاة مونت كارلو فعلية باستخدام numpy على expected_return/risk_level من
        investment_opportunities الفعلية (بدل قيم ثابتة 0.12/0.18/-0.05 سابقًا).
        risk_level يُحوَّل لتقلب تقريبي (low/medium/high) بغياب بيانات تقلب تاريخية فعلية.
        """
        n_sims = params.get("simulations", 10000)
        horizon_days = params.get("horizon", 252)

        opp_result = await self.tools.execute(
            "query_database",
            query="SELECT expected_return, risk_level FROM investment_opportunities WHERE status = 'approved'"
        )
        opportunities = opp_result.get("rows", [])

        if not opportunities:
            return StepResult(
                step_name="run_monte_carlo", success=True,
                data={"simulations": 0, "note": "لا توجد فرص استثمارية معتمدة (status='approved') لمحاكاتها"}
            )

        risk_to_vol = {"low": 0.08, "medium": 0.15, "high": 0.28}
        returns = [float(o["expected_return"]) for o in opportunities if o.get("expected_return") is not None]
        vols = [risk_to_vol.get(o.get("risk_level"), 0.15) for o in opportunities]

        mean_return = float(np.mean(returns)) if returns else 0.08
        mean_vol = float(np.mean(vols)) if vols else 0.15

        rng = np.random.default_rng(42)
        daily_mean = mean_return / horizon_days
        daily_vol = mean_vol / (horizon_days ** 0.5)
        simulated_paths = rng.normal(daily_mean, daily_vol, size=(int(n_sims), horizon_days))
        cumulative_returns = np.prod(1 + simulated_paths, axis=1) - 1

        expected_return = float(np.mean(cumulative_returns))
        volatility = float(np.std(cumulative_returns))
        var_95 = float(np.percentile(cumulative_returns, 5))
        cvar_95 = float(np.mean(cumulative_returns[cumulative_returns <= var_95])) if np.any(cumulative_returns <= var_95) else var_95
        probability_of_profit = float(np.mean(cumulative_returns > 0))

        return StepResult(
            step_name="run_monte_carlo",
            success=True,
            data={
                "simulations": int(n_sims),
                "expected_return": round(expected_return, 4),
                "volatility": round(volatility, 4),
                "var_95": round(var_95, 4),
                "cvar_95": round(cvar_95, 4),
                "probability_of_profit": round(probability_of_profit, 4),
                "worst_case": round(float(np.min(cumulative_returns)), 4),
                "best_case": round(float(np.max(cumulative_returns)), 4)
            }
        )

    async def _step_optimize_allocation(self, params: Dict) -> StepResult:
        """
        تخصيص الوزن على الفرص الاستثمارية المعتمدة فعليًا (وليس فئات أصول ثابتة
        stocks/bonds/alternatives/cash سابقًا) باستخدام تخصيص عكسي للمخاطر
        (Inverse-Volatility Weighting) كتقريب بسيط ومفسَّر لـ max_sharpe.
        """
        opp_result = await self.tools.execute(
            "query_database",
            query="SELECT id, name, expected_return, risk_level, initial_cost FROM investment_opportunities "
                  "WHERE status = 'approved'"
        )
        opportunities = opp_result.get("rows", [])

        if not opportunities:
            return StepResult(
                step_name="optimize_allocation", success=True,
                data={"optimal_weights": {}, "expected_sharpe": None, "rebalancing_needed": False,
                      "rebalancing_trades": [], "note": "لا توجد فرص استثمارية معتمدة"}
            )

        risk_to_vol = {"low": 0.08, "medium": 0.15, "high": 0.28}
        inv_vols = []
        for o in opportunities:
            vol = risk_to_vol.get(o.get("risk_level"), 0.15)
            inv_vols.append(1.0 / vol)

        total_inv_vol = sum(inv_vols)
        optimal_weights = {
            opportunities[i]["name"]: round(inv_vols[i] / total_inv_vol, 3)
            for i in range(len(opportunities))
        }

        returns = [float(o["expected_return"] or 0) for o in opportunities]
        vols = [risk_to_vol.get(o.get("risk_level"), 0.15) for o in opportunities]
        weights_list = list(optimal_weights.values())
        portfolio_return = sum(w * r for w, r in zip(weights_list, returns))
        portfolio_vol = sum(w * v for w, v in zip(weights_list, vols)) or 1e-9
        expected_sharpe = round(portfolio_return / portfolio_vol, 3)

        return StepResult(
            step_name="optimize_allocation",
            success=True,
            data={
                "optimal_weights": optimal_weights,
                "expected_sharpe": expected_sharpe,
                "rebalancing_needed": None,
                "rebalancing_trades": [],
                "note": "لا يوجد جدول محفظة/مراكز حالية (portfolio_holdings) في المخطط الحالي، "
                        "لذا لا يمكن حساب صفقات إعادة توازن فعلية"
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if "var_95" in combined:
            var = combined["var_95"]
            if var < -0.05:
                warnings.append(f"⚠️ VaR 95% = {var:.1%} - مخاطر مرتفعة")
                recommendations.append("🛡️ فكر في التحوط أو تقليل التعرض")

        if "rebalancing_needed" in combined and combined["rebalancing_needed"]:
            insights.append("📊 المحفظة تحتاج إعادة توازن")
            recommendations.append("🔄 نفذ صفقات إعادة التوازن المقترحة")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.85,
            explanation="تم تحليل الاستثمارات وإعداد التوصيات",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
