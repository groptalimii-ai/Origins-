#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Executive Agent
وكيل الإدارة التنفيذية
"""

import logging
from typing import Dict, Any, List
from datetime import datetime

from ai_engine.agents.base_agent import BaseAgent, AgentConfig, Task, Plan, Step, StepResult, AgentResponse

logger = logging.getLogger(__name__)


class ExecutiveAgent(BaseAgent):
    """وكيل الإدارة التنفيذية المتخصص"""

    def __init__(self):
        super().__init__(AgentConfig(
            name="ExecutiveAgent",
            description="وكيل متخصص في لوحة القيادة التنفيذية والمحاكاة الاستراتيجية",
            capabilities=[
                "executive_dashboard",
                "strategic_simulation",
                "kpi_monitoring",
                "risk_heatmap",
                "competitive_intelligence",
                "board_reporting",
                "scenario_planning",
                "decision_support"
            ],
            models=["executive-llm", "scenario-simulator", "kpi-aggregator"],
            data_sources=["all_departments", "external_data", "market_data", "competitor_data"]
        ))

    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        if task.type == "executive_report":
            return Plan(steps=[
                Step("gather_kpis", {"departments": "all"}),
                Step("analyze_trends", {"period": "quarterly"}),
                Step("benchmark_performance", {}),
                Step("identify_risks", {"categories": ["financial", "operational", "strategic"]}),
                Step("generate_insights", {"ai_powered": True}),
                Step("create_executive_summary", {"language": "ar"})
            ], estimated_time=50.0)
        elif task.type in ("scenario_planning", "strategy"):
            # إصلاح (الجولة الثانية عشرة): راوت /executive/ai/strategy-simulation
            # يرسل task_type="strategy" (مطابق لمفتاح orchestrator الذي يوجّه بنجاح
            # لهذا الوكيل)، لكن هذا الشرط كان يتحقق من "scenario_planning" حصرًا -
            # فيسقط دومًا للخطة العامة بلا أي محاكاة سيناريوهات فعلية.
            return Plan(steps=[
                Step("define_scenarios", {"inputs": task.data.get("scenarios", [])}),
                Step("model_variables", {}),
                Step("run_simulations", {"iterations": 5000}),
                Step("analyze_outcomes", {}),
                Step("generate_probability_tree", {}),
                Step("recommend_strategy", {})
            ], estimated_time=60.0)
        else:
            return Plan(steps=[
                Step("gather_executive_data", {}),
                Step("synthesize_insights", {}),
                Step("generate_recommendation", {})
            ], estimated_time=25.0)

    async def execute_step(self, step: Step) -> StepResult:
        if step.name == "gather_kpis":
            return await self._step_gather_kpis(step.params)
        elif step.name == "run_simulations":
            return await self._step_run_simulations(step.params)
        else:
            return StepResult(step_name=step.name, success=True, data={"status": "completed"})

    async def _step_gather_kpis(self, params: Dict) -> StepResult:
        """
        تجميع مؤشرات أداء فعلية من عدة جداول (بدل قيم ثابتة revenue=2,850,000... سابقًا):
        - revenue/profit_margin من transactions
        - employee_retention من employees (is_active)
        لا يوجد جدول رضا عملاء (customer_satisfaction) أو حصة سوقية (market_share)
        في المخطط الحالي، فتُترك null بوضوح بدل اختلاقها.
        """
        income_result = await self.tools.execute(
            "query_database",
            query="SELECT SUM(amount) AS total FROM transactions "
                  "WHERE type = 'income' AND date >= NOW() - INTERVAL '90 days'"
        )
        expense_result = await self.tools.execute(
            "query_database",
            query="SELECT SUM(amount) AS total FROM transactions "
                  "WHERE type = 'expense' AND date >= NOW() - INTERVAL '90 days'"
        )
        income = float((income_result.get("rows") or [{}])[0].get("total") or 0)
        expense = float((expense_result.get("rows") or [{}])[0].get("total") or 0)
        profit_margin = round((income - expense) / income, 3) if income else None

        emp_result = await self.tools.execute(
            "query_database",
            query="SELECT COUNT(*) AS total, SUM(CASE WHEN is_active THEN 1 ELSE 0 END) AS active "
                  "FROM employees"
        )
        emp_rows = emp_result.get("rows") or [{}]
        total_emp = int(emp_rows[0].get("total") or 0)
        active_emp = int(emp_rows[0].get("active") or 0)
        retention = round(active_emp / total_emp, 3) if total_emp else None

        kpis = {
            "revenue": {"current": round(income, 2), "target": None, "status": None},
            "profit_margin": {"current": profit_margin, "target": None, "status": None},
            "customer_satisfaction": {"current": None, "target": None, "status": None,
                                       "note": "لا يوجد جدول رضا عملاء في المخطط الحالي"},
            "employee_retention": {"current": retention, "target": None, "status": None},
            "market_share": {"current": None, "target": None, "status": None,
                              "note": "لا يوجد مصدر بيانات حصة سوقية في المخطط الحالي"}
        }

        return StepResult(step_name="gather_kpis", success=True, data={"kpis": kpis})

    async def _step_run_simulations(self, params: Dict) -> StepResult:
        """
        سيناريوهات نمو مبنية على معدل النمو الفعلي في الإيرادات (transactions) خلال
        آخر سنة (بدل نسب ثابتة 25%/55%/20% سابقًا لا ترتبط ببيانات حقيقية).
        """
        txn_result = await self.tools.execute(
            "query_database",
            query="SELECT date, amount FROM transactions "
                  "WHERE type = 'income' AND date >= NOW() - INTERVAL '365 days' ORDER BY date"
        )
        rows = txn_result.get("rows", [])

        if not rows:
            return StepResult(
                step_name="run_simulations", success=True,
                data={"scenarios": {}, "recommended": None, "expected_value": None,
                      "note": "لا توجد بيانات إيرادات كافية لبناء سيناريوهات"}
            )

        total_revenue = sum(float(r["amount"]) for r in rows)
        half = len(rows) // 2
        first_half = sum(float(r["amount"]) for r in rows[:half]) if half else 0
        second_half = sum(float(r["amount"]) for r in rows[half:]) if half else total_revenue
        base_growth = (second_half - first_half) / first_half if first_half > 0 else 0.05

        scenarios = {
            "aggressive_growth": {"probability": 0.25, "outcome": f"+{round(base_growth * 200, 1)}% revenue", "risk": "high"},
            "steady_growth": {"probability": 0.55, "outcome": f"+{round(base_growth * 100, 1)}% revenue", "risk": "medium"},
            "conservative": {"probability": 0.20, "outcome": f"+{round(base_growth * 40, 1)}% revenue", "risk": "low"}
        }
        expected_value = round(total_revenue * (1 + base_growth), 2)

        return StepResult(
            step_name="run_simulations",
            success=True,
            data={
                "scenarios": scenarios,
                "recommended": "steady_growth",
                "expected_value": expected_value
            }
        )

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        combined = {}
        for r in results:
            combined.update(r.data)

        insights = []
        recommendations = []
        warnings = []

        if "kpis" in combined:
            kpis = combined["kpis"]
            below = [k for k, v in kpis.items() if v["status"] == "below_target"]
            if below:
                warnings.append(f"⚠️ {len(below)} مؤشرات أداء دون الهدف: {', '.join(below)}")
                recommendations.append("📊 راجع الخطط التصحيحية للمؤشرات المتأخرة")

        if "recommended" in combined:
            insights.append(f"🎯 الاستراتيجية الموصى بها: {combined['recommended']}")
            recommendations.append("📈 نفذ خطة النمو المتوازن")

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined,
            confidence=0.90,
            explanation="تم إعداد التقرير التنفيذي والتوصيات الاستراتيجية",
            insights=insights,
            recommendations=recommendations,
            warnings=warnings
        )
