# -*- coding: utf-8 -*-
"""اختبارات تكامل لمسار المصادقة: تسجيل → دخول → /me → رفض دخول خاطئ"""
import pytest

from tests.conftest import unique_email

pytestmark = pytest.mark.asyncio


async def test_register_login_me_flow(client):
    email = unique_email("authflow")
    password = "SecurePass123!"

    # التسجيل
    resp = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Flow Test User"},
    )
    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert body["email"] == email
    assert body["role"] == "user"  # الافتراضي عند عدم تحديد دور

    # تسجيل مكرر لنفس البريد يجب أن يُرفض
    dup = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Flow Test User"},
    )
    assert dup.status_code == 400

    # الدخول
    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200, login.text
    tokens = login.json()
    assert "access_token" in tokens and "refresh_token" in tokens

    # /me بالتوكن الصحيح
    me = await client.get(
        "/api/v1/auth/me", headers={"Authorization": f"Bearer {tokens['access_token']}"}
    )
    assert me.status_code == 200, me.text
    assert me.json()["email"] == email


async def test_login_wrong_password_rejected(client):
    email = unique_email("wrongpass")
    password = "CorrectPass123!"

    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Wrong Pass User"},
    )
    assert reg.status_code == 201

    bad_login = await client.post(
        "/api/v1/auth/login", json={"email": email, "password": "WrongPassword999!"}
    )
    assert bad_login.status_code == 401


async def test_protected_route_requires_token(client):
    resp = await client.get("/api/v1/auth/me")
    assert resp.status_code == 401


async def test_self_signup_cannot_grant_admin_role(client):
    """إصلاح سابق تحقّق: التسجيل الذاتي بدور admin يجب أن يُخفَّض تلقائيًا إلى user"""
    email = unique_email("privesc")
    password = "TryToBeAdmin123!"

    resp = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Privilege Escalation Attempt", "role": "admin"},
    )
    assert resp.status_code == 201
    assert resp.json()["role"] != "admin"
