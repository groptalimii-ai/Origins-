# -*- coding: utf-8 -*-
"""
اختبارات مسار /ai: حالة الوكلاء الـ11 (يتطلب lifespan كامل)، وصلاحية admin فقط
لتدريب وكيل (كانت مفتوحة للجميع قبل إصلاح سابق موثَّق في ai.py).
"""
import pytest

from tests.conftest import unique_email

pytestmark = pytest.mark.asyncio


async def _login_as(client, role: str):
    email = unique_email(role)
    password = "AiTestPass123!"
    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": f"{role} ai-tester", "role": role},
    )
    assert reg.status_code == 201
    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200
    return {"Authorization": f"Bearer {login.json()['access_token']}"}


@pytest.mark.slow
async def test_agents_status_lists_all_11_agents(client, client_with_lifespan):
    headers = await _login_as(client, "manager")

    resp = await client_with_lifespan.get("/api/v1/ai/agents/status", headers=headers)
    assert resp.status_code == 200, resp.text
    agents = resp.json()
    # إصلاح مُتحقَّق منه: الشكل الفعلي كائن (object) مفتاحه اسم الوكيل، وليس
    # {"agents": [...]} كما كانت تتوقع Dashboard.tsx قبل إصلاحها.
    assert isinstance(agents, dict)
    assert len(agents) == 11
    for agent_data in agents.values():
        assert agent_data["status"] in ("idle", "processing", "training", "error", "offline")


async def test_agents_status_requires_manager_role(client):
    """require_min_role('manager') - دور 'user' العادي يجب أن يُرفض بلا حاجة لـ lifespan"""
    headers = await _login_as(client, "user")
    resp = await client.get("/api/v1/ai/agents/status", headers=headers)
    assert resp.status_code == 403


@pytest.mark.slow
async def test_train_agent_requires_admin_not_just_manager(client, client_with_lifespan):
    headers = await _login_as(client, "manager")

    resp = await client_with_lifespan.post(
        "/api/v1/ai/agents/FinancialAgent/train", headers=headers
    )
    assert resp.status_code == 403
