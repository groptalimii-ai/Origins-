# -*- coding: utf-8 -*-
"""
اختبارات RBAC عبر أدوار متعددة + التحقق أن AuditLogger يسجّل فعليًا في audit_logs
(إصلاح الجولة الخامسة: كان جدول audit_logs يبقى فارغًا دائمًا لأن AuditLogger كان
محاصرًا داخل EnterpriseEngine غير المستخدَم).
"""
import pytest
from sqlalchemy import select, text

from tests.conftest import unique_email
from database.session import AsyncSessionLocal
from database.models import AuditLog

pytestmark = pytest.mark.asyncio


async def _register_and_login(client, role: str = "user"):
    email = unique_email(role)
    password = "RbacTestPass123!"
    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": f"{role} tester", "role": role},
    )
    assert reg.status_code == 201, reg.text
    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200, login.text
    return {"Authorization": f"Bearer {login.json()['access_token']}"}, email


async def test_manager_can_create_inventory_item_but_user_cannot(client):
    manager_headers, _ = await _register_and_login(client, role="user")
    # لا يوجد دور "manager" ضمن ALLOWED_SELF_SIGNUP_ROLES عمدًا (فقط user/analyst) -
    # هذا يتحقق أن التسجيل الذاتي لا يمكن أن يمنح دور manager أيضًا (وليس admin فقط).
    manager_check = await client.get("/api/v1/auth/me", headers=manager_headers)
    assert manager_check.json()["role"] == "user"

    resp = await client.post(
        "/api/v1/inventory/items",
        json={"sku": f"SKU-{unique_email('x')[:8]}", "name": "Test Widget", "quantity_on_hand": 10},
        headers=manager_headers,
    )
    # دور user لا يملك صلاحية manager المطلوبة لإنشاء عنصر مخزون
    assert resp.status_code == 403


async def test_hr_routes_require_manager_role(client):
    headers, _ = await _register_and_login(client, role="analyst")

    resp = await client.get("/api/v1/hr/employees", headers=headers)
    # analyst أقل من manager في التسلسل الهرمي (40 < 60) فيُرفض
    assert resp.status_code == 403


async def test_failed_login_is_recorded_in_audit_log(client):
    """
    إصلاح الجولة الخامسة: يتحقق أن AuditLogger مربوط فعليًا الآن بمسار /auth/login
    ويكتب فعليًا في جدول audit_logs (وليس فقط في الذاكرة/اللوق كما كان الحال عندما
    كان محاصرًا داخل EnterpriseEngine غير المستخدَم).
    """
    email = unique_email("audittest")
    password = "CorrectPassword123!"

    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Audit Test User"},
    )
    assert reg.status_code == 201

    bad_login = await client.post(
        "/api/v1/auth/login", json={"email": email, "password": "WrongPassword999!"}
    )
    assert bad_login.status_code == 401

    # AuditLogger يُخزِّن في buffer بالذاكرة ولا يكتب لقاعدة البيانات إلا كل 100 سجل
    # أو كل 30 ثانية أو عند shutdown() - نستدعي flush يدويًا هنا لتفادي انتظار طويل
    # غير ضروري في الاختبار (الوصول المباشر لتفاصيل التنفيذ الداخلي مقبول هنا لأن
    # هذا اختبار تكامل يتحقق تحديدًا من سلوك AuditLogger نفسه).
    from main import app
    await app.state.audit_logger._flush_buffer()

    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(AuditLog).where(AuditLog.event_type == "security").order_by(AuditLog.created_at.desc())
        )
        logs = result.scalars().all()

    matching = [
        log for log in logs
        if log.new_value and log.new_value.get("event_type") == "login_failed"
        and log.new_value.get("details", {}).get("email") == email
    ]
    assert len(matching) >= 1, "لم يُسجَّل حدث login_failed فعليًا في جدول audit_logs"
