# -*- coding: utf-8 -*-
"""
Fixtures مشتركة لاختبارات EnterpriseAI-OS.

⚠️ هذه اختبارات تكامل حقيقية (integration tests) تتطلب قاعدة بيانات Postgres
فعلية قابلة للوصول (وليست SQLite) لأن database/models.py يستخدم أنواع بيانات
خاصة بـ Postgres (JSONB وغيرها). راجع tests/README.md لتشغيلها.

قبل التشغيل، عيّن TEST_DATABASE_URL (أو DATABASE_URL) لتشير إلى قاعدة بيانات
اختبار منفصلة عن قاعدة بيانات التطوير/الإنتاج - الاختبارات تُنشئ وتحذف بيانات فعلياً.
"""
import os
import uuid

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

# يجب تعيين متغيرات البيئة قبل استيراد core.config (تُقرأ عند تحميل الوحدة)
os.environ.setdefault(
    "DATABASE_URL",
    os.environ.get("TEST_DATABASE_URL", "postgresql://enterpriseai:password@localhost:5432/enterpriseai_test"),
)
os.environ.setdefault("JWT_SECRET", "test-secret-not-for-production")
os.environ.setdefault("ENCRYPTION_KEY", "test-encryption-key-not-for-prod")
os.environ.setdefault("MODEL_LOADING_ENABLED", "false")  # إصلاح: تخطي تحميل نماذج وهمية أثناء الاختبار

# إصلاح: محدّد معدل الطلبات (rate limiter) مشترك بين كل الاختبارات في نفس عملية
# pytest (نسخة SecurityManager واحدة على مستوى الوحدة في dependencies.py)، وكل
# طلبات ASGITransport تصل بنفس عنوان IP الوهمي. مجموع الطلبات عبر كل ملفات
# الاختبار (auth + transactions + rbac + users + accounting + ai + smoke test)
# يتجاوز بسهولة الحد الافتراضي (100 طلب/60 ثانية) فيسبب فشلاً عشوائيًا (429) غير
# متعلق بمنطق الاختبار الفعلي. يُرفع الحد هنا فقط لبيئة الاختبار.
os.environ.setdefault("RATE_LIMIT_REQUESTS", "100000")
os.environ.setdefault("RATE_LIMIT_WINDOW", "60")

from database.session import init_models, engine  # noqa: E402
from core.audit import AuditLogger  # noqa: E402
from main import app  # noqa: E402


@pytest_asyncio.fixture(scope="session", autouse=True)
async def _create_tables():
    """إنشاء الجداول مرة واحدة لكل جلسة اختبار (عملية آمنة/idempotent)."""
    await init_models()
    yield
    await engine.dispose()


@pytest_asyncio.fixture
async def client():
    """
    عميل HTTP بلا تشغيل lifespan الكامل (بدون Kafka/AIOrchestrator) - مناسب
    لاختبارات auth/transactions التي لا تحتاج app.state.ai_orchestrator.

    إصلاح: يُهيَّأ app.state.audit_logger هنا مباشرة (بدون بقية lifespan الثقيل)
    لأن auth.py/dependencies.py يستخدمانه فعليًا الآن لتسجيل أحداث الدخول ورفض
    الصلاحيات (الجولة الخامسة) - بلا هذا كانت ستفشل هذه الاختبارات بـ AttributeError.
    محروس بـ hasattr حتى لا يُنشئ نسخة ثانية يتيمة إن استُخدم هذا الفيكستشر معًا مع
    client_with_lifespan (الذي يُنشئ نسخته الخاصة عبر lifespan الكامل) في نفس الاختبار.
    """
    created_here = not hasattr(app.state, "audit_logger")
    if created_here:
        app.state.audit_logger = AuditLogger()
        await app.state.audit_logger.initialize()
    try:
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as ac:
            yield ac
    finally:
        if created_here:
            await app.state.audit_logger.shutdown()


@pytest_asyncio.fixture
async def client_with_lifespan():
    """
    عميل HTTP يشغّل lifespan الكامل فعليًا (يهيّئ AIOrchestrator بكل الوكلاء الـ11
    و EventBus) - مطلوب فقط لاختبارات /ai/query و /ai/agents/status.
    """
    async with app.router.lifespan_context(app):
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as ac:
            yield ac


def unique_email(prefix: str = "test") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:10]}@example.com"


@pytest_asyncio.fixture
async def registered_user(client):
    """يسجّل مستخدمًا جديدًا بدور analyst (يكفي لإنشاء معاملات) ويعيد بياناته + التوكن."""
    email = unique_email("analyst")
    password = "TestPass123!"

    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Test Analyst", "role": "analyst"},
    )
    assert reg.status_code == 201, reg.text

    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200, login.text
    tokens = login.json()

    return {
        "email": email,
        "password": password,
        "access_token": tokens["access_token"],
        "refresh_token": tokens["refresh_token"],
        "headers": {"Authorization": f"Bearer {tokens['access_token']}"},
    }
