# -*- coding: utf-8 -*-
"""
اختبار انحدار مخصَّص لخلل حرج اكتُشف في الجولة السابعة: نقاط نهاية
/finance/ai/* الثلاث كانت تُوجَّه دائمًا وبصمت لـ CrossDepartmentAgent بدل
FinancialAgent الفعلي، بسبب عدم تطابق task_type/department بين finance.py
و orchestrator.select_optimal_agent. هذا الاختبار يستدعي نقاط النهاية الحقيقية
مباشرة (وليس /ai/query العام) للتأكد أن الإصلاح يعمل من طرف المستخدم النهائي فعليًا.
"""
import pytest

from tests.conftest import unique_email

pytestmark = pytest.mark.asyncio


async def _login_as(client, role: str):
    email = unique_email(role)
    password = "RoutingTestPass123!"
    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": f"{role} routing", "role": role},
    )
    assert reg.status_code == 201
    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200
    return {"Authorization": f"Bearer {login.json()['access_token']}"}


@pytest.mark.slow
@pytest.mark.parametrize(
    "path,min_role",
    [
        ("/api/v1/finance/ai/cash-flow-forecast", "analyst"),
        ("/api/v1/finance/ai/budget-optimization", "manager"),
        ("/api/v1/finance/ai/expense-analysis", "analyst"),
    ],
)
async def test_finance_ai_endpoints_route_to_financial_agent(client, client_with_lifespan, path, min_role):
    headers = await _login_as(client, min_role)

    resp = await client_with_lifespan.post(path, json={}, headers=headers)
    assert resp.status_code == 200, resp.text

    body = resp.json()
    # قبل الإصلاح: كانت هذه النقاط تُعيد دائمًا agent="CrossDepartmentAgent" بصمت
    # (بلا أي خطأ ظاهر) بدل التحليل المالي الفعلي المطلوب.
    assert body.get("agent") == "FinancialAgent", (
        f"{path} وُجِّه لـ {body.get('agent')} بدل FinancialAgent - خلل التوجيه لم يُصلَح"
    )
