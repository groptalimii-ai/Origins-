# -*- coding: utf-8 -*-
"""اختبارات مسار /users: إخفاء الحقول الحساسة، صلاحية عرض/تعديل المستخدمين"""
import pytest

from tests.conftest import unique_email

pytestmark = pytest.mark.asyncio


async def _register_and_login(client, role: str = "user"):
    email = unique_email(role)
    password = "UsersTestPass123!"
    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": f"{role} user", "role": role},
    )
    assert reg.status_code == 201, reg.text
    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200
    return {"Authorization": f"Bearer {login.json()['access_token']}"}, reg.json()["id"]


async def test_regular_user_cannot_list_all_users(client):
    headers, _ = await _register_and_login(client, role="user")
    resp = await client.get("/api/v1/users", headers=headers)
    assert resp.status_code == 403


async def test_user_can_view_own_profile_not_others(client):
    headers_a, user_a_id = await _register_and_login(client, role="user")
    _, user_b_id = await _register_and_login(client, role="user")

    own = await client.get(f"/api/v1/users/{user_a_id}", headers=headers_a)
    assert own.status_code == 200
    assert own.json()["id"] == user_a_id

    other = await client.get(f"/api/v1/users/{user_b_id}", headers=headers_a)
    assert other.status_code == 403


async def test_user_response_never_exposes_password_hash_or_mfa_secret(client):
    """إصلاح مُتحقَّق منه: _sanitize() في users.py يجب أن يحذف الحقول الحساسة فعليًا"""
    headers, user_id = await _register_and_login(client, role="user")

    resp = await client.get(f"/api/v1/users/{user_id}", headers=headers)
    assert resp.status_code == 200
    body = resp.json()
    assert "password_hash" not in body
    assert "mfa_secret" not in body


async def test_only_admin_can_change_user_role(client):
    headers, target_id = await _register_and_login(client, role="user")

    # مستخدم عادي (وليس admin) يحاول ترقية نفسه - يجب أن يُرفض
    resp = await client.patch(
        f"/api/v1/users/{target_id}", json={"role": "admin"}, headers=headers
    )
    assert resp.status_code == 403
