# -*- coding: utf-8 -*-
"""
اختبار دخان (smoke test) لكل المسارات الـ13 دفعة واحدة: يتحقق أن كل نقطة نهاية
مسجَّلة فعليًا في التطبيق (لا خطأ استيراد/توجيه) وأنها محمية فعليًا (401/403 بلا
توكن) - يغطي بتكلفة منخفضة المسارات التي لم تحصل على اختبار سيناريو تفصيلي بعد
(production, audit, revenue, investment, marketing, executive)، ويكتشف فورًا أي
تراجع مستقبلي يُسقط RBAC أو يكسر تسجيل راوت بالخطأ.
"""
import pytest

pytestmark = pytest.mark.asyncio


# كل الأزواج (method, path) لنقاط النهاية المحمية عبر الـ13 راوت، مبنية من قراءة
# مباشرة لكل ملف في backend/api/routes/*.py.
PROTECTED_ENDPOINTS = [
    ("GET", "/api/v1/finance/transactions"),
    ("POST", "/api/v1/finance/transactions"),
    ("GET", "/api/v1/inventory/items"),
    ("POST", "/api/v1/inventory/items"),
    ("GET", "/api/v1/production/orders"),
    ("POST", "/api/v1/production/orders"),
    ("POST", "/api/v1/production/ai/schedule-optimization"),
    ("POST", "/api/v1/production/ai/quality-check"),
    ("GET", "/api/v1/accounting/invoices"),
    ("POST", "/api/v1/accounting/invoices"),
    ("GET", "/api/v1/audit/logs"),
    ("GET", "/api/v1/audit/ai-decisions"),
    ("POST", "/api/v1/audit/ai/fraud-detection"),
    ("POST", "/api/v1/audit/ai/compliance-check"),
    ("POST", "/api/v1/revenue/ai/forecast"),
    ("POST", "/api/v1/revenue/ai/pricing-optimization"),
    ("GET", "/api/v1/investment/opportunities"),
    ("POST", "/api/v1/investment/opportunities"),
    ("POST", "/api/v1/investment/ai/analyze"),
    ("GET", "/api/v1/hr/employees"),
    ("POST", "/api/v1/hr/employees"),
    ("GET", "/api/v1/marketing/campaigns"),
    ("POST", "/api/v1/marketing/campaigns"),
    ("POST", "/api/v1/executive/ai/dashboard-report"),
    ("POST", "/api/v1/executive/ai/strategy-simulation"),
    ("GET", "/api/v1/ai/agents/status"),
    ("GET", "/api/v1/users"),
]


@pytest.mark.parametrize("method,path", PROTECTED_ENDPOINTS)
async def test_endpoint_rejects_unauthenticated_request(client, method, path):
    resp = await client.request(method, path, json={} if method == "POST" else None)
    # 401 = غير مصادَق. 422 مقبول أيضًا لو كان الجسم المرسل لا يطابق Pydantic قبل
    # وصول التنفيذ لطبقة المصادقة في بعض تسلسلات FastAPI الداخلية - لكن يجب ألا
    # يكون 200/404 إطلاقًا (200 يعني ثغرة مصادقة، 404 يعني خطأ تسجيل راوت).
    assert resp.status_code in (401, 403, 422), (
        f"{method} {path} أعاد {resp.status_code} غير المتوقَّع - "
        f"يجب أن يكون محميًا (401/403) على الأقل بلا توكن"
    )
    assert resp.status_code != 404, f"{method} {path} غير مسجَّل فعليًا (404) - تحقق من routes/__init__.py"
