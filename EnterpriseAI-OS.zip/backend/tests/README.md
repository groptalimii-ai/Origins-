# اختبارات EnterpriseAI-OS

هذه اختبارات **تكامل حقيقية (integration tests)** — لا تُحاكي (mock) قاعدة البيانات،
بل تتصل فعليًا بـ Postgres حقيقي وتُنشئ/تقرأ بيانات فعلية. لا يمكن استخدام SQLite لأن
`database/models.py` يستخدم أنواع بيانات خاصة بـ Postgres (JSONB وغيرها).

## المتطلبات قبل التشغيل

1. قاعدة بيانات Postgres منفصلة عن قاعدة التطوير/الإنتاج (الاختبارات تُنشئ وتحذف
   بيانات فعليًا). أسهل طريقة عبر docker-compose الموجود أصلًا في المشروع:

   ```bash
   docker compose -f docker-compose.full.yml up -d postgres redis kafka zookeeper
   ```

2. عيّن متغيرات البيئة (أو أنشئ `.env` كما في `config/.env.example`):

   ```bash
   export TEST_DATABASE_URL="postgresql://enterpriseai:changeme@localhost:5432/enterpriseai_test"
   export JWT_SECRET="test-secret"
   export ENCRYPTION_KEY="test-encryption-key"
   ```

   (أنشئ قاعدة `enterpriseai_test` يدويًا مرة واحدة عبر `createdb` أو `psql`، الاختبارات
   تُنشئ الجداول تلقائيًا فيها عند أول تشغيل عبر `init_models()`.)

3. تثبيت تبعيات الاختبار (موجودة أصلًا في `requirements.txt`):

   ```bash
   pip install -r backend/requirements.txt --break-system-packages
   ```

## التشغيل

```bash
cd backend
pytest                      # كل الاختبارات
pytest -m "not slow"        # الاختبارات السريعة فقط (بلا Kafka/تحميل الوكلاء)
pytest tests/test_auth.py   # ملف واحد
```

## ملاحظة عن اختبارات `slow`

اختبار واحد (`test_financial_agent_runs_on_real_data`) يشغّل دورة حياة (lifespan)
التطبيق كاملة فعليًا (اتصال Kafka الحقيقي + تسجيل الوكلاء الـ11)، لذا يتطلب أن يكون
Kafka فعليًا قابلاً للوصول عبر `KAFKA_BOOTSTRAP_SERVERS`، وإلا سينتظر ~15 ثانية (5
محاولات إعادة اتصال) قبل أن يستمر بدون Kafka (سلوك متعمَّد بعد إصلاح الجولة الثالثة —
لا يفشل الاختبار، لكنه يبطئه). لتخطي هذا الاختبار أثناء التطوير السريع، استخدم
`pytest -m "not slow"`.

## لماذا لا توجد اختبارات وحدة (unit tests) منعزلة؟

معظم منطق المشروع (الوكلاء، الراوتس) مبني حول استعلامات SQL حقيقية على مخطط Postgres
محدَّد؛ محاكاتها بالكامل (mock) تقلل من قيمة الاختبار في اكتشاف مشاكل حقيقية مثل تعارض
المخطط الذي اكتُشف في الجولة الثالثة (كان أي اختبار وحدة يعتمد على mocks لن يكتشفه
إطلاقًا). لذلك اختير نهج اختبارات التكامل رغم بطئها النسبي.
