# -*- coding: utf-8 -*-
"""اختبارات مسار /accounting: إنشاء فاتورة، صلاحيات RBAC متدرجة"""
import pytest

from tests.conftest import unique_email

pytestmark = pytest.mark.asyncio


async def _login_as(client, role: str):
    email = unique_email(role)
    password = "AcctTestPass123!"
    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": f"{role} acct", "role": role},
    )
    assert reg.status_code == 201
    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200
    return {"Authorization": f"Bearer {login.json()['access_token']}"}


async def test_create_and_list_invoice(client):
    headers = await _login_as(client, "analyst")

    create = await client.post(
        "/api/v1/accounting/invoices",
        json={"invoice_number": f"INV-{unique_email('n')[:6]}", "customer_name": "Acme Corp", "amount": 2500.0},
        headers=headers,
    )
    assert create.status_code == 200, create.text
    invoice = create.json()
    assert invoice["customer_name"] == "Acme Corp"

    listing = await client.get("/api/v1/accounting/invoices", headers=headers)
    assert listing.status_code == 200
    assert any(i["id"] == invoice["id"] for i in listing.json())


async def test_plain_user_cannot_create_invoice(client):
    """require_min_role('analyst') يجب أن يرفض دور 'user' العادي (20 < 40)"""
    headers = await _login_as(client, "user")

    resp = await client.post(
        "/api/v1/accounting/invoices",
        json={"invoice_number": "INV-X", "customer_name": "Nope Inc", "amount": 100},
        headers=headers,
    )
    assert resp.status_code == 403


async def test_analyst_cannot_run_reconciliation_needs_manager(client):
    """/accounting/ai/reconciliation يتطلب manager تحديدًا، وليس analyst فقط"""
    headers = await _login_as(client, "analyst")

    resp = await client.post("/api/v1/accounting/ai/reconciliation", json={}, headers=headers)
    assert resp.status_code == 403
