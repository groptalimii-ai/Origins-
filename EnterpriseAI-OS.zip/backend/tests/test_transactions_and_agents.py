# -*- coding: utf-8 -*-
"""
اختبار تكامل شامل (end-to-end): تسجيل مستخدم → إنشاء معاملة مالية حقيقية →
تشغيل financial_agent فعليًا عبر /api/v1/ai/query والتحقق أن الاستجابة مبنية
على بيانات حقيقية (وليست الأرقام الثابتة القديمة قبل الإصلاح).
"""
import pytest

from tests.conftest import unique_email

pytestmark = pytest.mark.asyncio


async def _create_analyst_user(client):
    email = unique_email("txn")
    password = "TxnTestPass123!"

    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Transactions Tester", "role": "analyst"},
    )
    assert reg.status_code == 201, reg.text

    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200, login.text
    token = login.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


async def test_create_transaction_and_list(client):
    headers = await _create_analyst_user(client)

    create = await client.post(
        "/api/v1/finance/transactions",
        json={
            "amount": 1500.50,
            "type": "expense",
            "category": "operations",
            "vendor": "Test Vendor Co",
            "description": "معاملة اختبارية",
        },
        headers=headers,
    )
    assert create.status_code == 200, create.text
    created = create.json()
    assert created["amount"] == 1500.50
    assert created["type"] == "expense"

    listing = await client.get("/api/v1/finance/transactions", headers=headers)
    assert listing.status_code == 200
    assert any(t["id"] == created["id"] for t in listing.json())


async def test_user_role_cannot_create_transaction(client):
    """require_min_role('analyst') يجب أن يرفض دور 'user' العادي"""
    email = unique_email("useronly")
    password = "UserOnlyPass123!"

    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": "Plain User"},
    )
    assert reg.status_code == 201

    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    resp = await client.post(
        "/api/v1/finance/transactions",
        json={"amount": 100, "type": "expense"},
        headers=headers,
    )
    assert resp.status_code == 403


@pytest.mark.slow
async def test_financial_agent_runs_on_real_data(client, client_with_lifespan):
    """
    اختبار end-to-end كامل: ينشئ معاملات حقيقية ثم يشغّل financial_agent فعليًا
    عبر orchestrator الحقيقي (يتطلب lifespan كاملاً)، ويتحقق أن الاستجابة تعتمد
    فعليًا على البيانات المُدخَلة (إصلاح الجولة الثالثة) بدل أرقام ثابتة مثل
    count=15000 أو risk_score=0.15 دائمًا.
    """
    headers = await _create_analyst_user(client)

    # إنشاء عدة معاملات حقيقية لضمان وجود بيانات يستعلمها الوكيل
    for i in range(3):
        resp = await client.post(
            "/api/v1/finance/transactions",
            json={
                "amount": 1000 + i * 100,
                "type": "expense",
                "category": "operations",
                "vendor": f"Vendor {i}",
            },
            headers=headers,
        )
        assert resp.status_code == 200

    result = await client_with_lifespan.post(
        "/api/v1/ai/query",
        json={
            # إصلاح (الجولة السابعة): department="finance" هي القيمة الحقيقية التي
            # يرسلها backend/api/routes/finance.py فعليًا لكل نقاط /finance/ai/* -
            # كانت هذه القيمة بالذات (وليست "financial") تفشل في الوصول لـ
            # FinancialAgent بسبب خلل توجيه حقيقي في orchestrator.select_optimal_agent
            # (اكتُشف وأُصلح في هذه الجولة: "finance" ليست سلسلة فرعية من
            # "financialagent"، ومفاتيح task_agent_map لم تكن مطابقة لقيم task_type
            # الفعلية التي يرسلها finance.py). هذا الاختبار يتحقق من الإصلاح الحقيقي
            # باستخدام نفس القيم التي يرسلها الكود الفعلي، وليس حل بديل يتجاوز الخلل.
            "task_type": "cash_flow_forecast",
            "department": "finance",
            "data": {},
        },
        headers=headers,
    )
    assert result.status_code == 200, result.text
    body = result.json()
    assert body["agent"] == "FinancialAgent"
    # إصلاح: قبل الجولة الثالثة كانت _step_gather_transactions تُرجع count=15000
    # ثابتًا دائمًا بلا أي استعلام. الآن يجب أن يعكس العدد الفعلي (3 معاملات على
    # الأقل من المُنشأة أعلاه، أو أكثر إن تراكمت بيانات من تشغيلات سابقة لنفس قاعدة
    # بيانات الاختبار).
    assert body["result"].get("count", 0) >= 3
