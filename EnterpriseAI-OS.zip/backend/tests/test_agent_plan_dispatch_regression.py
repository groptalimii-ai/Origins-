# -*- coding: utf-8 -*-
"""
اختبار انحدار مخصَّص لخلل حرج اكتُشف في الجولة الثانية عشرة، وهو أعمق من خلل
الجولة السابعة (راجع test_finance_routing_regression.py): ذلك الاختبار يتحقق فقط
من أن الطلب وُجِّه لاسم الوكيل الصحيح (response["agent"]) - لكن هذا لا يكفي، لأن
كل وكيل بعد اختياره يشغّل plan() الخاص به الذي يتحقق من task.type بشرط مطابقة
نصية منفصل تمامًا عن المفاتيح المستخدَمة في orchestrator.select_optimal_agent.

اكتُشف أن 9 من أصل 11 راوت AI متخصص (accounting/reconciliation, hr/retention,
hr/recruitment, inventory/demand-forecast, investment/analyze,
investment/portfolio-review, marketing/campaign, marketing/sentiment,
production/quality-check, executive/strategy, revenue/pricing, audit/compliance)
كانت تُوجَّه فعليًا للوكيل الصحيح (فيمر اختبار الجولة السابعة النمطي) لكن plan()
داخل ذلك الوكيل كان يفشل بصمت في التعرّف على task.type فيسقط للخطة العامة الفارغة
(status: "completed" بلا أي بيانات حقيقية) - أي أن كل هذه النقاط كانت "تعمل" ظاهريًا
(200 OK، الوكيل الصحيح) لكن بلا تنفيذ أي منطق ذكاء اصطناعي فعلي إطلاقًا.

هذا الاختبار يتحقق من أن نتيجة التنفيذ الفعلية (result) تحتوي مفاتيح بيانات حقيقية
خاصة بكل نوع مهمة - وليس فقط أن الوكيل الصحيح استُدعي.
"""
import pytest

from tests.conftest import unique_email

pytestmark = pytest.mark.asyncio


async def _login_as(client, role: str, tag: str):
    email = unique_email(f"{role}-{tag}")
    password = "PlanDispatchTest123!"
    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "name": f"{role} plan-dispatch", "role": role},
    )
    assert reg.status_code == 201
    login = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200
    return {"Authorization": f"Bearer {login.json()['access_token']}"}


@pytest.mark.slow
@pytest.mark.parametrize(
    "path,min_role,expected_agent",
    [
        ("/api/v1/accounting/ai/reconciliation", "manager", "AccountingAgent"),
        ("/api/v1/hr/ai/retention-analysis", "manager", "HRAgent"),
        ("/api/v1/hr/ai/recruitment-screening", "manager", "HRAgent"),
        ("/api/v1/inventory/ai/demand-forecast", "analyst", "InventoryAgent"),
        ("/api/v1/investment/ai/analyze", "manager", "InvestmentAgent"),
        ("/api/v1/investment/ai/portfolio-review", "manager", "InvestmentAgent"),
        ("/api/v1/marketing/ai/campaign-optimization", "manager", "MarketingAgent"),
        ("/api/v1/production/ai/quality-check", "analyst", "ProductionAgent"),
        ("/api/v1/executive/ai/strategy-simulation", "executive", "ExecutiveAgent"),
        ("/api/v1/revenue/ai/pricing-optimization", "manager", "RevenueAgent"),
        ("/api/v1/audit/ai/compliance-check", "manager", "AuditAgent"),
    ],
)
async def test_ai_endpoints_execute_real_plan_not_generic_fallback(
    client, client_with_lifespan, path, min_role, expected_agent
):
    headers = await _login_as(client, min_role, path.replace("/", "-"))

    resp = await client_with_lifespan.post(path, json={}, headers=headers)
    assert resp.status_code == 200, resp.text

    body = resp.json()
    assert body.get("agent") == expected_agent, (
        f"{path} وُجِّه لـ {body.get('agent')} بدل {expected_agent}"
    )

    # قبل الإصلاح: result كان يحتوي فقط {"status": "completed"} من الخطوات العامة
    # غير المعالَجة، بلا أي مفتاح بيانات حقيقي خاص بالمهمة.
    result = body.get("result") or {}
    assert result != {"status": "completed"}, (
        f"{path}: الوكيل نفّذ الخطة العامة الفارغة بدل خطته الحقيقية "
        f"(نفس عطل عدم تطابق task_type الذي أُصلح في الجولة 12)"
    )
