#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Shared API Dependencies
تبعيات مشتركة: مصادقة حقيقية، صلاحيات، حدود معدل الطلبات
"""

from typing import Awaitable, Callable, Optional

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from core.security import SecurityManager, ROLE_HIERARCHY
from database.session import get_db
from database.models import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)

_security_manager = SecurityManager()


async def get_current_user(
    request: Request,
    token: Optional[str] = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    """يفك تشفير JWT الحقيقي ويجلب المستخدم من قاعدة البيانات - لا مصادقة وهمية."""
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="بيانات اعتماد غير صالحة أو منتهية",
        headers={"WWW-Authenticate": "Bearer"},
    )

    if not token:
        raise credentials_error

    payload = _security_manager.verify_token(token)
    if not payload or payload.get("type") != "access":
        raise credentials_error

    user_id = payload.get("sub")
    if not user_id:
        raise credentials_error

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if not user or not user.is_active:
        raise credentials_error

    return user


def require_roles(*allowed_roles: str) -> Callable[..., Awaitable[User]]:
    """Dependency factory: يفرض أن يملك المستخدم أحد الأدوار المسموحة"""

    async def _checker(request: Request, user: User = Depends(get_current_user)) -> User:
        if user.role not in allowed_roles and user.role != "admin":
            audit_logger = getattr(request.app.state, "audit_logger", None)
            if audit_logger:
                await audit_logger.log_security_event(
                    "authorization_denied",
                    {"user_id": user.id, "role": user.role, "required_roles": list(allowed_roles)},
                    severity="warning",
                )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"هذا الإجراء يتطلب أحد الأدوار: {', '.join(allowed_roles)}",
            )
        return user

    return _checker


def require_min_role(min_role: str) -> Callable[..., Awaitable[User]]:
    """Dependency factory: يفرض حدًا أدنى في تسلسل الأدوار الهرمي"""

    async def _checker(request: Request, user: User = Depends(get_current_user)) -> User:
        if ROLE_HIERARCHY.get(user.role, 0) < ROLE_HIERARCHY.get(min_role, 0):
            audit_logger = getattr(request.app.state, "audit_logger", None)
            if audit_logger:
                await audit_logger.log_security_event(
                    "authorization_denied",
                    {"user_id": user.id, "role": user.role, "required_min_role": min_role},
                    severity="warning",
                )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"هذا الإجراء يتطلب صلاحية '{min_role}' على الأقل",
            )
        return user

    return _checker


async def enforce_rate_limit(request: Request) -> None:
    """تطبيق فعلي لحد معدل الطلبات لكل IP - كان دائمًا True سابقًا"""
    from core.config import settings

    client_key = request.client.host if request.client else "unknown"
    allowed = _security_manager.check_rate_limit(
        f"http:{client_key}",
        max_requests=settings.RATE_LIMIT_REQUESTS,
        window=settings.RATE_LIMIT_WINDOW,
    )
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="تم تجاوز الحد المسموح من الطلبات، حاول لاحقًا",
        )


def get_security_manager() -> SecurityManager:
    return _security_manager
