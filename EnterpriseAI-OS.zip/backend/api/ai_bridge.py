#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - AI Bridge
دالة مشتركة لتوجيه المهام إلى منسق الذكاء الاصطناعي من أي راوت،
مع تسجيل القرار في جدول ai_decisions فعليًا (بدل التجاهل السابق).
"""

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Request, status

from ai_engine.agents.base_agent import Task
from api.dependencies import get_security_manager, require_min_role
from database.models import User

logger = logging.getLogger(__name__)


@dataclass
class _AuthCommand:
    """كائن بسيط يمرَّر لـ SecurityManager.authorize() (RBAC حسب النوع/القسم)"""
    user_id: str
    role: str
    type: str
    department: str


async def run_agent_task(
    request: Request,
    task_type: str,
    department: str,
    data: Dict[str, Any],
    user_id: str,
    user_role: str,
) -> Dict[str, Any]:
    """
    إصلاح حرج للأمان: كانت SecurityManager.authorize() (RBAC حسب نوع المهمة/القسم،
    بما فيها RESTRICTED_COMMAND_TYPES لعمليات حساسة مثل fraud_detection/
    budget_optimization/investment_analysis) مبنيّة بالكامل في core/security.py
    لكنها لم تكن تُستدعى من أي مكان في مسار الطلبات الفعلي إطلاقًا. النتيجة: نقطة
    النهاية العامة POST /api/v1/ai/query كانت تسمح لأي مستخدم موثّق - حتى بأدنى دور
    "user" - باختيار أي task_type/department حر (بما فيها العمليات التي تتطلب دور
    manager/admin صراحة على راوتاتها المخصصة مثل /finance/ai/budget-optimization
    أو /audit/ai/fraud-detection)، متجاوزًا كل قيود RBAC الدقيقة المطبَّقة على تلك
    الراوتات المخصصة. الإصلاح: استدعاء authorize() هنا مركزيًا (نقطة الدخول
    المشتركة الوحيدة لكل الراوتات) يغلق هذه الثغرة لكل المسارات دفعة واحدة، بما في
    ذلك /ai/query تحديدًا.
    """
    security = get_security_manager()
    authorized = await security.authorize(
        _AuthCommand(user_id=user_id, role=user_role, type=task_type, department=department)
    )
    if not authorized:
        audit_logger = getattr(request.app.state, "audit_logger", None)
        if audit_logger:
            await audit_logger.log_security_event(
                "ai_task_authorization_denied",
                {"user_id": user_id, "role": user_role, "task_type": task_type, "department": department},
                severity="warning",
            )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="لا تملك صلاحية تنفيذ هذه المهمة على هذا القسم",
        )

    orchestrator = request.app.state.ai_orchestrator

    task = Task(
        id=f"{task_type}-{datetime.utcnow().timestamp()}",
        type=task_type,
        data=data,
        user_id=user_id,
        department=department,
    )

    response = await orchestrator.route_task(task)

    # تسجيل القرار فعليًا في قاعدة البيانات (كان مفقودًا سابقًا رغم وجود الجدول)
    try:
        from database.session import AsyncSessionLocal
        from database.models import AIDecision

        async with AsyncSessionLocal() as session:
            session.add(AIDecision(
                agent_type=response.agent_name,
                decision_type=task_type,
                input_data=data,
                output_data=response.result,
                confidence=response.confidence,
                explanation=response.explanation,
            ))
            await session.commit()
    except Exception as e:
        # لا نفشل الطلب بسبب فشل تسجيل القرار، لكن إصلاح: كانت هذه الكتلة `pass`
        # صامتة تماماً رغم تعليق سابق يدّعي أن الفشل "يُسجَّل عبر audit" - لم يكن
        # هناك أي تسجيل فعلي. الآن يُسجَّل الخطأ فعلياً في اللوق.
        logger.error(f"⚠️ فشل حفظ قرار الذكاء الاصطناعي في جدول ai_decisions: {e}")

    return {
        "task_id": response.task_id,
        "agent": response.agent_name,
        "status": response.status,
        "confidence": response.confidence,
        "explanation": response.explanation,
        "result": response.result,
        "insights": response.insights,
        "recommendations": response.recommendations,
        "warnings": response.warnings,
        "processing_time": response.processing_time,
    }


def register_ai_action(
    router: APIRouter,
    path: str,
    task_type: str,
    department: str,
    min_role: str,
) -> None:
    """
    مراجعة معمارية (DRY/Open-Closed): كانت نقاط نهاية AI البسيطة (بلا معاملات
    إضافية خاصة بالراوت) تُكرِّر نفس 6 أسطر حرفيًا - إعلان الدالة، حقن
    request/current_user عبر Depends(require_min_role(...))، واستدعاء
    run_agent_task بنفس القالب - عبر 18 موضعًا مختلفًا في 9 ملفات راوت. أي
    تعديل مستقبلي على نمط هذا التفويض (مثال: إضافة تسجيل قياسي، تغيير توقيع
    run_agent_task) كان يتطلب تعديل 18 نسخة يدويًا بدل مصدر واحد.

    يُستخدَم فقط لنقاط النهاية التي لا تحتاج معاملات إضافية خاصة بالراوت (مثال:
    sku في inventory أو text في marketing تبقى دوال صريحة عمداً - إجبارها على
    قالب موحّد كان سيُعقّد التوقيع بلا داعٍ فعلي، وهذا بالضبط الخط الفاصل بين
    "إزالة تكرار حقيقي" و"تجريد زائد/over-engineering").
    """

    async def _handler(
        request: Request,
        current_user: User = Depends(require_min_role(min_role)),
    ) -> Dict[str, Any]:
        return await run_agent_task(request, task_type, department, {}, current_user.id, current_user.role)

    _handler.__name__ = f"ai_action_{task_type}"
    router.add_api_route(path, _handler, methods=["POST"])
