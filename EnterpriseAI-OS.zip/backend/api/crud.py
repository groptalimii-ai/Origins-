#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Generic CRUD Helpers
دوال CRUD عامة حقيقية (استعلامات SQLAlchemy فعلية، وليست بيانات وهمية)
"""

from typing import Any, Dict, List, Optional, Type, TypeVar

from fastapi import HTTPException
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql.elements import ClauseElement

from database.models import Base

# مراجعة معمارية (Type Hinting صارم): كانت هذه الدوال تستخدم Type خام بلا معامل
# (bare) وتُعيد قيمًا بلا أي إعلان نوع (get_record/create_record/update_record/
# delete_record) - أي مستدعٍ لهذه الدوال (كل ملفات routes/*.py) كان يفقد فحص
# النوع الساكن تمامًا على القيمة المُعادة (يظهر كـ Any ضمنيًا). الآن TModel مقيّد
# بالفئة الأساسية Base الفعلية لكل النماذج، فيعرف أي أداة تحليل ساكن (mypy/pyright)
# فعلياً أن get_record(db, Employee, id) تُعيد Employee تحديدًا، لا أي كائن عام.
TModel = TypeVar("TModel", bound=Base)


def model_to_dict(instance: Base) -> Dict[str, Any]:
    return {c.name: getattr(instance, c.name) for c in instance.__table__.columns}


async def list_records(
    db: AsyncSession,
    model: Type[TModel],
    skip: int = 0,
    limit: int = 50,
    order_by: Optional[ClauseElement] = None,
) -> List[Dict[str, Any]]:
    query = select(model)
    if order_by is not None:
        query = query.order_by(order_by)
    query = query.offset(skip).limit(min(limit, 500))
    result = await db.execute(query)
    return [model_to_dict(r) for r in result.scalars().all()]


async def count_records(db: AsyncSession, model: Type[TModel]) -> int:
    result = await db.execute(select(func.count()).select_from(model))
    return result.scalar_one()


async def get_record(db: AsyncSession, model: Type[TModel], record_id: str) -> TModel:
    result = await db.execute(select(model).where(model.id == record_id))
    obj = result.scalar_one_or_none()
    if not obj:
        raise HTTPException(status_code=404, detail="السجل غير موجود")
    return obj


async def create_record(db: AsyncSession, model: Type[TModel], data: Dict[str, Any]) -> TModel:
    obj = model(**data)
    db.add(obj)
    await db.commit()
    await db.refresh(obj)
    return obj


async def update_record(
    db: AsyncSession, model: Type[TModel], record_id: str, data: Dict[str, Any]
) -> TModel:
    obj = await get_record(db, model, record_id)
    for key, value in data.items():
        if value is not None and hasattr(obj, key):
            setattr(obj, key, value)
    await db.commit()
    await db.refresh(obj)
    return obj


async def delete_record(db: AsyncSession, model: Type[TModel], record_id: str) -> Dict[str, Any]:
    obj = await get_record(db, model, record_id)
    await db.delete(obj)
    await db.commit()
    return {"deleted": True, "id": record_id}
