#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Users Routes"""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import get_current_user, require_min_role
from api.crud import list_records, get_record, update_record, delete_record, model_to_dict
from database.session import get_db
from database.models import User

router = APIRouter()


class UserUpdate(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None


def _sanitize(user_dict: dict) -> dict:
    user_dict.pop("password_hash", None)
    user_dict.pop("mfa_secret", None)
    return user_dict


@router.get("")
async def list_users(
    skip: int = 0,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    users = await list_records(db, User, skip, limit)
    return [_sanitize(u) for u in users]


@router.get("/{user_id}")
async def get_user(
    user_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.id != user_id and current_user.role not in ("admin", "executive", "manager"):
        raise HTTPException(status_code=403, detail="لا تملك صلاحية عرض هذا المستخدم")
    obj = await get_record(db, User, user_id)
    return _sanitize(model_to_dict(obj))


@router.patch("/{user_id}")
async def update_user(
    user_id: str,
    payload: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("admin")),
):
    obj = await update_record(db, User, user_id, payload.model_dump(exclude_unset=True))
    return _sanitize(model_to_dict(obj))


@router.delete("/{user_id}")
async def deactivate_user(
    user_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("admin")),
):
    """تعطيل بدل الحذف الفعلي حفاظًا على سجل التدقيق"""
    obj = await update_record(db, User, user_id, {"is_active": False})
    return _sanitize(model_to_dict(obj))
