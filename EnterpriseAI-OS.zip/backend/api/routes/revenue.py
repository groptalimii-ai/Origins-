#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Revenue Routes"""

from fastapi import APIRouter

from api.ai_bridge import register_ai_action

router = APIRouter()

register_ai_action(router, "/ai/forecast", "revenue_forecast", "revenue", "analyst")
register_ai_action(router, "/ai/pricing-optimization", "pricing", "revenue", "manager")
