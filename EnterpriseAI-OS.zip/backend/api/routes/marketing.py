#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Marketing Routes"""

from typing import Any, Dict, Optional
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import get_current_user, require_min_role
from api.crud import list_records, create_record, model_to_dict
from api.ai_bridge import register_ai_action, run_agent_task
from database.session import get_db
from database.models import User, Campaign

router = APIRouter()


class CampaignCreate(BaseModel):
    name: str
    channel: Optional[str] = None
    budget: float = 0


@router.get("/campaigns")
async def list_campaigns(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await list_records(db, Campaign, limit=200)


@router.post("/campaigns")
async def create_campaign(
    payload: CampaignCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    obj = await create_record(db, Campaign, payload.model_dump())
    return model_to_dict(obj)


register_ai_action(router, "/ai/campaign-optimization", "campaign", "marketing", "manager")


@router.post("/ai/sentiment-analysis")
async def sentiment_analysis(
    request: Request,
    text: str,
    current_user: User = Depends(require_min_role("analyst")),
) -> Dict[str, Any]:
    """
    تبقى دالة صريحة عمداً (بخلاف /ai/campaign-optimization أعلاه) لأنها تحمل
    معامل text المطلوب إدخاله يدوياً - لا تناسبها قالب register_ai_action الموحّد.
    """
    return await run_agent_task(
        request, "sentiment", "marketing", {"text": text}, current_user.id, current_user.role
    )
