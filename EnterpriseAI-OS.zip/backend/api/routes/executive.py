#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Executive Routes"""

from typing import Any, Dict
from fastapi import APIRouter, Depends, Request

from api.dependencies import require_min_role
from api.ai_bridge import register_ai_action, run_agent_task
from database.models import User

router = APIRouter()


# لوحة القيادة التنفيذية - مقيّدة فعليًا لدور executive/admin فقط
register_ai_action(router, "/ai/dashboard-report", "executive_report", "executive", "executive")


@router.post("/ai/strategy-simulation")
async def strategy_simulation(
    request: Request,
    scenario: str = "expected",
    current_user: User = Depends(require_min_role("executive")),
) -> Dict[str, Any]:
    """
    تبقى دالة صريحة عمداً (بخلاف /ai/dashboard-report أعلاه) لأنها تحمل معامل
    scenario إضافياً خاصاً بها يُمرَّر ضمن data - إجبارها على قالب
    register_ai_action الموحّد (المصمَّم لنقاط النهاية بلا معاملات إضافية) كان
    سيتطلب تعقيد توقيع تلك الدالة المشتركة بلا داعٍ فعلي لبقية الاستخدامات.
    """
    return await run_agent_task(
        request, "strategy", "executive", {"scenario": scenario}, current_user.id, current_user.role
    )
