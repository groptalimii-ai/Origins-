#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Auth Routes
مسارات المصادقة (تسجيل / دخول / تجديد) - تنفيذ فعلي بقاعدة بيانات
"""

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import get_current_user, get_security_manager
from core.security import SecurityManager
from database.session import get_db
from database.models import User

router = APIRouter()


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    name: str
    department: Optional[str] = None
    role: str = "user"  # يُقيَّد لاحقًا: فقط admin يستطيع إنشاء أدوار عليا


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    mfa_code: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


ALLOWED_SELF_SIGNUP_ROLES = {"user", "analyst"}


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(
    payload: RegisterRequest,
    db: AsyncSession = Depends(get_db),
    security: SecurityManager = Depends(get_security_manager),
):
    """تسجيل مستخدم جديد - كلمة المرور تُجزَّأ فعليًا (bcrypt)، لا تخزين نصي"""
    existing = await db.execute(select(User).where(User.email == payload.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="البريد الإلكتروني مسجل مسبقًا")

    role = payload.role if payload.role in ALLOWED_SELF_SIGNUP_ROLES else "user"

    user = User(
        email=payload.email,
        password_hash=security.hash_password(payload.password),
        name=payload.name,
        department=payload.department,
        role=role,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    return {"id": user.id, "email": user.email, "name": user.name, "role": user.role}


@router.post("/login", response_model=TokenResponse)
async def login(
    request: Request,
    payload: LoginRequest,
    db: AsyncSession = Depends(get_db),
    security: SecurityManager = Depends(get_security_manager),
):
    """تسجيل الدخول - يتحقق فعليًا من كلمة المرور و MFA إن كان مفعّلاً"""
    result = await db.execute(select(User).where(User.email == payload.email))
    user = result.scalar_one_or_none()

    # رسالة خطأ موحّدة لتجنب تسريب وجود/عدم وجود البريد (user enumeration)
    invalid_creds = HTTPException(status_code=401, detail="بيانات دخول غير صحيحة")

    # إصلاح (الجولة الخامسة): AuditLogger كان مُهيَّأً بالفعل منذ الجولة الثالثة
    # لكنه كان محاصرًا داخل EnterpriseEngine غير المستخدَم إطلاقًا - جدول audit_logs
    # كان يبقى فارغًا دائمًا رغم وجود كل البنية اللازمة. الآن يُسجَّل كل محاولة دخول
    # فاشلة/ناجحة فعليًا في audit_logs عبر app.state.audit_logger. getattr احترازي
    # لعدم كسر السياقات التي لا تُشغّل lifespan الكامل (مثل بعض الاختبارات الخفيفة).
    audit = getattr(request.app.state, "audit_logger", None)

    async def _log(event_type: str, details: dict, severity: str = "info"):
        if audit:
            await audit.log_security_event(event_type, details, severity=severity)

    if not user or not user.is_active:
        await _log("login_failed", {"email": payload.email, "reason": "user_not_found_or_inactive"}, "warning")
        raise invalid_creds

    if not security.verify_password(payload.password, user.password_hash):
        await _log("login_failed", {"email": payload.email, "reason": "wrong_password"}, "warning")
        raise invalid_creds

    if user.mfa_enabled:
        if not payload.mfa_code or not security.verify_mfa(user.mfa_secret, payload.mfa_code):
            await _log("login_mfa_failed", {"email": payload.email}, "warning")
            raise HTTPException(status_code=401, detail="رمز MFA غير صحيح أو مفقود")

    user.last_login = datetime.utcnow()
    await db.commit()

    await _log("login_success", {"user_id": user.id, "email": user.email})

    token_data = {"sub": user.id, "role": user.role, "email": user.email}
    return TokenResponse(
        access_token=security.create_access_token(token_data),
        refresh_token=security.create_refresh_token(token_data),
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    payload: RefreshRequest,
    db: AsyncSession = Depends(get_db),
    security: SecurityManager = Depends(get_security_manager),
):
    """تجديد رمز الوصول باستخدام refresh token فعلي"""
    decoded = security.verify_token(payload.refresh_token)
    if not decoded or decoded.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="refresh token غير صالح")

    result = await db.execute(select(User).where(User.id == decoded.get("sub")))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="المستخدم غير موجود أو معطّل")

    token_data = {"sub": user.id, "role": user.role, "email": user.email}
    return TokenResponse(
        access_token=security.create_access_token(token_data),
        refresh_token=security.create_refresh_token(token_data),
    )


@router.get("/me")
async def get_me(current_user: User = Depends(get_current_user)):
    """بيانات المستخدم الحالي المستخرجة من JWT حقيقي، وليست ثابتة"""
    return {
        "id": current_user.id,
        "email": current_user.email,
        "name": current_user.name,
        "role": current_user.role,
        "department": current_user.department,
        "mfa_enabled": current_user.mfa_enabled,
    }


@router.post("/mfa/setup")
async def setup_mfa(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    security: SecurityManager = Depends(get_security_manager),
):
    """توليد سر MFA حقيقي للمستخدم الحالي"""
    secret = security.generate_mfa_secret()
    current_user.mfa_secret = secret
    await db.commit()

    provisioning_uri = pyotp_uri(secret, current_user.email)
    return {"secret": secret, "provisioning_uri": provisioning_uri}


@router.post("/mfa/verify")
async def verify_mfa_setup(
    code: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    security: SecurityManager = Depends(get_security_manager),
):
    """تفعيل MFA بعد التحقق الفعلي من الرمز الأول"""
    if not current_user.mfa_secret:
        raise HTTPException(status_code=400, detail="لم يتم توليد سر MFA بعد")

    if not security.verify_mfa(current_user.mfa_secret, code):
        raise HTTPException(status_code=400, detail="رمز MFA غير صحيح")

    current_user.mfa_enabled = True
    await db.commit()
    return {"mfa_enabled": True}


def pyotp_uri(secret: str, email: str) -> str:
    import pyotp
    from core.config import settings
    return pyotp.totp.TOTP(secret).provisioning_uri(name=email, issuer_name=settings.MFA_ISSUER)
