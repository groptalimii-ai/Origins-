#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Investment Routes"""

from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import get_current_user, require_min_role
from api.crud import list_records, create_record, model_to_dict
from api.ai_bridge import register_ai_action
from database.session import get_db
from database.models import User, InvestmentOpportunity

router = APIRouter()


class OpportunityCreate(BaseModel):
    name: str
    expected_return: Optional[float] = None
    risk_level: Optional[str] = "medium"
    initial_cost: Optional[float] = None
    horizon_years: Optional[float] = None


@router.get("/opportunities")
async def list_opportunities(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await list_records(db, InvestmentOpportunity, limit=200)


@router.post("/opportunities")
async def create_opportunity(
    payload: OpportunityCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    obj = await create_record(db, InvestmentOpportunity, payload.model_dump())
    return model_to_dict(obj)


register_ai_action(router, "/ai/analyze", "investment_analysis", "investment", "manager")
register_ai_action(router, "/ai/portfolio-review", "portfolio", "investment", "manager")
