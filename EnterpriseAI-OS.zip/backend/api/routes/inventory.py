#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Inventory Routes"""

from typing import Any, Dict, Optional
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from api.dependencies import get_current_user, require_min_role
from api.crud import list_records, create_record, model_to_dict
from api.ai_bridge import register_ai_action, run_agent_task
from database.session import get_db
from database.models import User, InventoryItem, InventoryMovement

router = APIRouter()


class InventoryItemCreate(BaseModel):
    sku: str
    name: str
    quantity_on_hand: int = 0
    reorder_point: int = 0
    reorder_quantity: int = 0
    unit_cost: float = 0
    lead_time_days: int = 7
    supplier: Optional[str] = None


class MovementCreate(BaseModel):
    sku: str
    quantity: int
    movement_type: str  # sale | restock | adjustment


@router.get("/items")
async def list_items(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await list_records(db, InventoryItem, limit=500)


@router.post("/items")
async def create_item(
    payload: InventoryItemCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    obj = await create_record(db, InventoryItem, payload.model_dump())
    return model_to_dict(obj)


@router.post("/movements")
async def create_movement(
    payload: MovementCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("user")),
):
    """تسجيل حركة مخزون فعلية وتحديث الكمية الحالية بشكل ذري"""
    obj = await create_record(db, InventoryMovement, payload.model_dump())

    result = await db.execute(select(InventoryItem).where(InventoryItem.sku == payload.sku))
    item = result.scalar_one_or_none()
    if item:
        item.quantity_on_hand += payload.quantity
        await db.commit()

    return model_to_dict(obj)


@router.post("/ai/demand-forecast")
async def demand_forecast(
    request: Request,
    sku: Optional[str] = None,
    current_user: User = Depends(require_min_role("analyst")),
) -> Dict[str, Any]:
    """
    تبقى دالة صريحة عمداً (بخلاف /ai/reorder-check أدناه) لأنها تحمل معامل sku
    اختياري إضافي يُمرَّر ضمن data - لا تناسبها قالب register_ai_action الموحّد.
    """
    return await run_agent_task(
        request, "demand_prediction", "inventory", {"sku": sku}, current_user.id, current_user.role
    )


register_ai_action(router, "/ai/reorder-check", "inventory_check", "inventory", "analyst")
