#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Production Routes"""

from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import get_current_user, require_min_role
from api.crud import list_records, create_record, model_to_dict
from api.ai_bridge import register_ai_action
from database.session import get_db
from database.models import User, ProductionOrder

router = APIRouter()


class ProductionOrderCreate(BaseModel):
    product_sku: str
    quantity: int
    machine_id: Optional[str] = None


@router.get("/orders")
async def list_orders(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await list_records(db, ProductionOrder, limit=200, order_by=ProductionOrder.created_at.desc())


@router.post("/orders")
async def create_order(
    payload: ProductionOrderCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    obj = await create_record(db, ProductionOrder, payload.model_dump())
    return model_to_dict(obj)


register_ai_action(router, "/ai/schedule-optimization", "production_schedule", "production", "manager")
register_ai_action(router, "/ai/quality-check", "quality_check", "production", "analyst")
