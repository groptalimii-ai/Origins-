#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - HR Routes"""

from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import require_min_role
from api.crud import list_records, create_record, model_to_dict
from api.ai_bridge import register_ai_action
from database.session import get_db
from database.models import User, Employee

router = APIRouter()


class EmployeeCreate(BaseModel):
    full_name: str
    department: Optional[str] = None
    position: Optional[str] = None
    salary: Optional[float] = None
    performance_score: Optional[float] = None


@router.get("/employees")
async def list_employees(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    return await list_records(db, Employee, limit=500)


@router.post("/employees")
async def create_employee(
    payload: EmployeeCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    obj = await create_record(db, Employee, payload.model_dump())
    return model_to_dict(obj)


register_ai_action(router, "/ai/retention-analysis", "performance", "hr", "manager")
register_ai_action(router, "/ai/recruitment-screening", "recruitment", "hr", "manager")
