#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Accounting Routes"""

from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import get_current_user, require_min_role
from api.crud import list_records, create_record, model_to_dict
from api.ai_bridge import register_ai_action
from database.session import get_db
from database.models import User, Invoice

router = APIRouter()


class InvoiceCreate(BaseModel):
    invoice_number: str
    customer_name: str
    amount: float
    due_date: Optional[str] = None


@router.get("/invoices")
async def list_invoices(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await list_records(db, Invoice, limit=200, order_by=Invoice.issued_at.desc())


@router.post("/invoices")
async def create_invoice(
    payload: InvoiceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("analyst")),
):
    obj = await create_record(db, Invoice, payload.model_dump())
    return model_to_dict(obj)


register_ai_action(router, "/ai/journal-entry", "journal_entry", "accounting", "analyst")
register_ai_action(router, "/ai/reconciliation", "reconciliation", "accounting", "manager")
