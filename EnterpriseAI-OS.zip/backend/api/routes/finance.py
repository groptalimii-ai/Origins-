#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Finance Routes"""

from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import get_current_user, require_min_role
from api.crud import list_records, create_record, model_to_dict
from api.ai_bridge import register_ai_action
from database.session import get_db
from database.models import User, Transaction, Budget

router = APIRouter()


class TransactionCreate(BaseModel):
    amount: float
    type: str  # income | expense
    category: Optional[str] = None
    vendor: Optional[str] = None
    department: Optional[str] = None
    description: Optional[str] = None


@router.get("/transactions")
async def list_transactions(
    skip: int = 0, limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await list_records(db, Transaction, skip, limit, order_by=Transaction.date.desc())


@router.post("/transactions")
async def create_transaction(
    payload: TransactionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("analyst")),
):
    data = payload.model_dump()
    data["created_by"] = current_user.id
    data["date"] = datetime.utcnow()
    obj = await create_record(db, Transaction, data)
    return model_to_dict(obj)


@router.get("/budgets")
async def list_budgets(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await list_records(db, Budget, limit=200)


# مراجعة معمارية (DRY): الثلاث نقاط أدناه كانت 18 سطراً مكرَّرة (6 أسطر × 3)
# بنفس القالب حرفياً - أصبحت الآن 3 أسطر تصريحية عبر register_ai_action
# المشتركة (انظر api/ai_bridge.py لتفاصيل المبرر المعماري الكامل).
register_ai_action(router, "/ai/cash-flow-forecast", "cash_flow_forecast", "finance", "analyst")
register_ai_action(router, "/ai/budget-optimization", "budget_optimization", "finance", "manager")
register_ai_action(router, "/ai/expense-analysis", "expense_analysis", "finance", "analyst")
