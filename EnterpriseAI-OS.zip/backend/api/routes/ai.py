#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - AI Engine Routes"""

from typing import Any, Dict
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from api.dependencies import get_current_user, require_min_role
from api.ai_bridge import run_agent_task
from database.models import User

router = APIRouter()


class AIQueryBody(BaseModel):
    task_type: str
    department: str
    data: Dict[str, Any] = {}


@router.post("/query")
async def ai_query(
    request: Request,
    payload: AIQueryBody,
    current_user: User = Depends(get_current_user),
):
    """استعلام عام موجّه للمنسق - يمرر هوية المستخدم الحقيقية (لم يعد anonymous ثابتة)"""
    return await run_agent_task(
        request, payload.task_type, payload.department, payload.data, current_user.id, current_user.role
    )


@router.get("/agents/status")
async def agents_status(
    request: Request,
    current_user: User = Depends(require_min_role("manager")),
):
    return await request.app.state.ai_orchestrator.get_agents_status()


@router.post("/agents/{agent_id}/train")
async def train_agent(
    agent_id: str,
    request: Request,
    current_user: User = Depends(require_min_role("admin")),
):
    """تدريب وكيل - مقيّد لـ admin فقط (كان مفتوحًا للجميع سابقًا)"""
    return await request.app.state.ai_orchestrator.train_agent(agent_id, {})
