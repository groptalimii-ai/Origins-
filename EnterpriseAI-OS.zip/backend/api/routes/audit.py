#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EnterpriseAI-OS - Audit Routes"""

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from api.dependencies import require_min_role
from api.crud import list_records
from api.ai_bridge import register_ai_action
from database.session import get_db
from database.models import User, AuditLog, AIDecision

router = APIRouter()


@router.get("/logs")
async def list_audit_logs(
    skip: int = 0, limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    """سجل التدقيق الفعلي - الآن يُكتب فعليًا (كان في الإصدار السابق مجرد logger.info بلا حفظ)"""
    return await list_records(db, AuditLog, skip, limit, order_by=AuditLog.created_at.desc())


@router.get("/ai-decisions")
async def list_ai_decisions(
    skip: int = 0, limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_min_role("manager")),
):
    return await list_records(db, AIDecision, skip, limit, order_by=AIDecision.created_at.desc())


# مقيّدة لـ manager فأعلى - تتعامل مع بيانات حساسة (كانت بلا أي قيد سابقًا)
register_ai_action(router, "/ai/fraud-detection", "fraud_detection", "audit", "manager")
register_ai_action(router, "/ai/compliance-check", "audit", "audit", "manager")
