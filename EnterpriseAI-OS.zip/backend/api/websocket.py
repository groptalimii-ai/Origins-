#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - WebSocket Manager
كان هذا الملف مفقودًا بالكامل رغم أن main.py يستورده مباشرة (سبب فشل الإقلاع)
"""

import logging
from typing import Dict, Any, Set

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class WebSocketManager:
    """مدير اتصالات WebSocket للتحديثات الفورية"""

    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
        self.subscriptions: Dict[str, Set[WebSocket]] = {}

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)
        logger.info(f"🔌 اتصال WebSocket جديد ({len(self.active_connections)} نشط)")

    async def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)
        for subs in self.subscriptions.values():
            subs.discard(websocket)
        logger.info(f"🔌 قُطع اتصال WebSocket ({len(self.active_connections)} نشط)")

    async def handle_message(self, websocket: WebSocket, data: Dict[str, Any]):
        """معالجة رسالة واردة من العميل"""
        action = data.get("action")

        if action == "subscribe":
            channel = data.get("channel", "general")
            self.subscriptions.setdefault(channel, set()).add(websocket)
            await websocket.send_json({"type": "subscribed", "channel": channel})

        elif action == "unsubscribe":
            channel = data.get("channel", "general")
            self.subscriptions.get(channel, set()).discard(websocket)
            await websocket.send_json({"type": "unsubscribed", "channel": channel})

        elif action == "ping":
            await websocket.send_json({"type": "pong"})

        else:
            await websocket.send_json({"type": "error", "message": f"إجراء غير معروف: {action}"})

    async def broadcast(self, channel: str, message: Dict[str, Any]):
        """بث رسالة لكل المشتركين في قناة معينة"""
        subscribers = self.subscriptions.get(channel, set())
        dead = []
        for ws in subscribers:
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            await self.disconnect(ws)

    async def broadcast_all(self, message: Dict[str, Any]):
        """بث لكل الاتصالات النشطة"""
        dead = []
        for ws in self.active_connections:
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            await self.disconnect(ws)


websocket_manager = WebSocketManager()
