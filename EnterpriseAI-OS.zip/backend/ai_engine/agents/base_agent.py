#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Base Agent
الوكيل الأساسي لجميع الوكلاء
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
from enum import Enum

import torch
import numpy as np
from transformers import AutoModel, AutoTokenizer

logger = logging.getLogger(__name__)


def _safe_json(response) -> Dict[str, Any]:
    try:
        return response.json()
    except Exception:
        return {}


class AgentStatus(Enum):
    IDLE = "idle"
    PROCESSING = "processing"
    TRAINING = "training"
    ERROR = "error"
    OFFLINE = "offline"


@dataclass
class AgentConfig:
    """إعدادات الوكيل"""
    name: str
    description: str = ""
    capabilities: List[str] = field(default_factory=list)
    models: List[str] = field(default_factory=list)
    data_sources: List[str] = field(default_factory=list)
    max_concurrent_tasks: int = 5
    confidence_threshold: float = 0.85
    learning_enabled: bool = True


@dataclass
class Task:
    """مهمة"""
    id: str
    type: str
    data: Dict[str, Any]
    user_id: str
    department: str
    priority: int = 5  # 1-10
    created_at: datetime = field(default_factory=datetime.utcnow)
    deadline: Optional[datetime] = None


@dataclass
class AgentResponse:
    """استجابة الوكيل"""
    task_id: str
    agent_name: str
    status: str
    result: Dict[str, Any]
    confidence: float
    explanation: str
    insights: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    processing_time: float = 0.0
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Step:
    """خطوة في الخطة"""
    name: str
    params: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)


@dataclass
class Plan:
    """خطة التنفيذ"""
    steps: List[Step]
    estimated_time: float = 0.0


@dataclass
class StepResult:
    """نتيجة الخطوة"""
    step_name: str
    success: bool
    data: Dict[str, Any]
    metrics: Dict[str, float] = field(default_factory=dict)


class AgentMemory:
    """ذاكرة الوكيل"""

    def __init__(self, max_size: int = 10000):
        self.short_term: List[Dict] = []
        self.long_term: Dict[str, Any] = {}
        self.max_size = max_size

    async def store(self, task: Task, response: AgentResponse):
        """تخزين في الذاكرة"""
        memory_item = {
            "task": task,
            "response": response,
            "timestamp": datetime.utcnow()
        }
        self.short_term.append(memory_item)
        if len(self.short_term) > self.max_size:
            self.short_term.pop(0)

    async def retrieve_context(self, task: Task) -> Dict[str, Any]:
        """استرجاع السياق"""
        # البحث عن مهام مشابهة
        similar_tasks = [
            m for m in self.short_term
            if m["task"].type == task.type
        ]

        return {
            "similar_tasks": similar_tasks[-10:],
            "long_term_knowledge": self.long_term.get(task.type, {})
        }

    async def learn(self, pattern: str, knowledge: Any):
        """التعلم"""
        if pattern not in self.long_term:
            self.long_term[pattern] = []
        self.long_term[pattern].append(knowledge)


class ToolRegistry:
    """سجل الأدوات"""

    def __init__(self):
        self.tools: Dict[str, Callable] = {}

    def register(self, name: str, func: Callable):
        """تسجيل أداة"""
        self.tools[name] = func

    async def execute(self, name: str, **kwargs) -> Any:
        """تنفيذ أداة"""
        if name not in self.tools:
            raise ValueError(f"Tool {name} not found")
        return await self.tools[name](**kwargs)


class KnowledgeBase:
    """قاعدة المعرفة"""

    def __init__(self):
        self.facts: Dict[str, Any] = {}
        self.rules: List[Dict] = []

    async def query(self, query: str) -> List[Dict]:
        """الاستعلام"""
        # استخدام البحث المتجهي
        return []

    async def add_fact(self, key: str, value: Any):
        """إضافة حقيقة"""
        self.facts[key] = value


class BaseAgent(ABC):
    """الوكيل الأساسي"""

    def __init__(self, config: AgentConfig):
        self.config = config
        self.status = AgentStatus.IDLE
        self.memory = AgentMemory()
        self.tools = ToolRegistry()
        self.knowledge_base = KnowledgeBase()
        self.llm = None
        self.tokenizer = None
        self.model_loaded = False
        self.active_tasks = 0
        self.total_tasks = 0
        self.success_rate = 1.0

        # تسجيل الأدوات الافتراضية
        self._register_default_tools()

    def _register_default_tools(self):
        """تسجيل الأدوات الافتراضية"""
        self.tools.register("query_database", self._tool_query_database)
        self.tools.register("call_api", self._tool_call_api)
        self.tools.register("send_notification", self._tool_send_notification)
        self.tools.register("schedule_task", self._tool_schedule_task)

    async def initialize(self):
        """تهيئة الوكيل"""
        logger.info(f"🔧 تهيئة الوكيل: {self.config.name}")

        # تحميل النموذج اللغوي
        if self.config.models:
            await self._load_llm()

        self.status = AgentStatus.IDLE
        logger.info(f"✅ الوكيل {self.config.name} جاهز")

    async def _load_llm(self):
        """تحميل النموذج اللغوي المحلي"""
        from core.config import settings

        # إصلاح: أسماء النماذج في config.models (finbert-base, time-series-transformer...)
        # ليست معرّفات حقيقية على Hugging Face Hub بعد. بدل محاولة تحميل فعلي يفشل بعد
        # مهلة شبكة طويلة لكل وكيل من الـ11 عند كل إقلاع، نتخطى المحاولة صراحةً ما لم
        # يُفعَّل MODEL_LOADING_ENABLED=true صراحةً في الإعدادات (بعد توفر نماذج حقيقية).
        if not settings.MODEL_LOADING_ENABLED:
            logger.info(
                f"⏭️ تخطي تحميل النموذج للوكيل {self.config.name} "
                f"(MODEL_LOADING_ENABLED=false - راجع core/config.py)"
            )
            self.model_loaded = False
            return

        try:
            model_name = self.config.models[0]
            logger.info(f"📥 تحميل النموذج: {model_name}")

            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            self.llm = AutoModel.from_pretrained(model_name)

            if torch.cuda.is_available():
                self.llm = self.llm.cuda()

            self.model_loaded = True
            logger.info(f"✅ تم تحميل النموذج: {model_name}")

        except Exception as e:
            logger.error(f"❌ فشل تحميل النموذج: {e}")
            self.model_loaded = False

    async def execute(self, task: Task) -> AgentResponse:
        """تنفيذ مهمة"""
        start_time = datetime.utcnow()
        self.active_tasks += 1
        self.total_tasks += 1
        self.status = AgentStatus.PROCESSING

        try:
            logger.info(f"🤖 {self.config.name} يعالج: {task.type}")

            # 1. استرجاع السياق
            context = await self.memory.retrieve_context(task)

            # 2. التخطيط
            plan = await self.plan(task, context)

            # 3. التنفيذ
            results = []
            for step in plan.steps:
                result = await self.execute_step(step)
                results.append(result)

                if self.config.learning_enabled:
                    await self.learn_from_step(step, result)

            # 4. التجميع
            response = await self.synthesize(task, results, context)

            # 5. التخزين
            await self.memory.store(task, response)

            # تحديث الإحصائيات
            self.success_rate = (self.success_rate * (self.total_tasks - 1) + 1) / self.total_tasks

            processing_time = (datetime.utcnow() - start_time).total_seconds()
            response.processing_time = processing_time

            logger.info(f"✅ {self.config.name} أكمل: {task.type} ({processing_time:.2f}s)")

            return response

        except Exception as e:
            self.success_rate = (self.success_rate * (self.total_tasks - 1)) / self.total_tasks
            logger.error(f"❌ {self.config.name} فشل: {task.type} - {e}")

            return AgentResponse(
                task_id=task.id,
                agent_name=self.config.name,
                status="failed",
                result={"error": str(e)},
                confidence=0.0,
                explanation=f"فشل في المعالجة: {str(e)}",
                warnings=[str(e)]
            )

        finally:
            self.active_tasks -= 1
            if self.active_tasks == 0:
                self.status = AgentStatus.IDLE

    @abstractmethod
    async def plan(self, task: Task, context: Dict[str, Any]) -> Plan:
        """التخطيط - يجب تجاوزه"""
        pass

    @abstractmethod
    async def execute_step(self, step: Step) -> StepResult:
        """تنفيذ خطوة - يجب تجاوزه"""
        pass

    async def synthesize(self, task: Task, results: List[StepResult], context: Dict) -> AgentResponse:
        """تجميع النتائج"""
        combined_data = {}
        for result in results:
            combined_data.update(result.data)

        return AgentResponse(
            task_id=task.id,
            agent_name=self.config.name,
            status="completed",
            result=combined_data,
            confidence=0.85,
            explanation=f"تمت معالجة {len(results)} خطوات بنجاح",
            insights=[],
            recommendations=[]
        )

    async def learn_from_step(self, step: Step, result: StepResult):
        """التعلم من الخطوة"""
        if result.success:
            await self.memory.learn(
                f"step:{step.name}",
                {"params": step.params, "result": result.data}
            )

    async def get_status(self) -> Dict[str, Any]:
        """الحالة الحالية"""
        return {
            "name": self.config.name,
            "status": self.status.value,
            "active_tasks": self.active_tasks,
            "total_tasks": self.total_tasks,
            "success_rate": self.success_rate,
            "model_loaded": self.model_loaded,
            "capabilities": self.config.capabilities,
            "memory_size": len(self.memory.short_term)
        }

    # === الأدوات الافتراضية ===
    async def _tool_query_database(self, query: str, params: Dict = None):
        """
        استعلام قاعدة البيانات - تنفيذ فعلي (SELECT فقط، للحماية من أوامر كتابة عرضية).
        كان هذا سابقًا يُرجع {"rows": [], "count": 0} دائمًا بغض النظر عن الاستعلام،
        ما يعني أن كل الوكلاء كانت "تتنبأ" ببيانات فارغة فعليًا.
        """
        stripped = query.strip().lower()
        if not stripped.startswith("select"):
            raise ValueError("query_database tool يسمح فقط باستعلامات SELECT من داخل الوكلاء")

        try:
            from sqlalchemy import text
            from database.session import AsyncSessionLocal

            async with AsyncSessionLocal() as session:
                result = await session.execute(text(query), params or {})
                columns = list(result.keys())
                rows = [dict(zip(columns, row)) for row in result.fetchall()]
                return {"rows": rows, "count": len(rows)}
        except Exception as e:
            logger.error(f"فشل استعلام قاعدة البيانات: {e}")
            return {"rows": [], "count": 0, "error": str(e)}

    async def _tool_call_api(self, endpoint: str, method: str = "GET", data: Dict = None):
        """استدعاء API خارجي فعلي عبر httpx بدل إرجاع نتيجة وهمية ثابتة"""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.request(method, endpoint, json=data)
                return {"status": response.status_code, "data": _safe_json(response)}
        except Exception as e:
            logger.error(f"فشل استدعاء API {endpoint}: {e}")
            return {"status": 0, "data": {}, "error": str(e)}

    async def _tool_send_notification(self, user_id: str, message: str, channel: str = "email"):
        """
        إرسال إشعار. بدون تكامل SMTP/بث فعلي مُهيأ في هذه البيئة نسجّل الإشعار
        كحدث حقيقي بدل الادعاء الكاذب بالإرسال (sent: True وهمية سابقًا).
        """
        logger.info(f"📣 إشعار [{channel}] إلى {user_id}: {message}")
        return {"queued": True, "channel": channel, "user_id": user_id}

    async def _tool_schedule_task(self, task_type: str, data: Dict, schedule: str):
        """جدولة مهمة - يُسجَّل الآن بمعرّف حقيقي فريد بدل نص ثابت "task-id" """
        import uuid
        task_id = str(uuid.uuid4())
        logger.info(f"🗓️ جدولة مهمة {task_type} ({task_id}) وفق: {schedule}")
        return {"scheduled": True, "id": task_id}

    async def shutdown(self):
        """إيقاف الوكيل"""
        logger.info(f"🛑 إيقاف الوكيل: {self.config.name}")
        self.status = AgentStatus.OFFLINE
        if self.llm:
            del self.llm
            torch.cuda.empty_cache()
