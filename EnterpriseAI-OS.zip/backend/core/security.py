#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Security Manager
مدير الأمان (RBAC + JWT + Rate Limiting حقيقي)

ملاحظة: في الإصدار السابق كانت authorize() و check_rate_limit()
تُرجع True دائمًا بغض النظر عن أي شيء. تم استبدالها بمنطق فعلي.
"""

import logging
import time
import base64
from collections import defaultdict, deque
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

from jose import JWTError, jwt
from passlib.context import CryptContext
from cryptography.fernet import Fernet
import pyotp

from core.config import settings

logger = logging.getLogger(__name__)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


ROLE_HIERARCHY = {
    "admin": 100,
    "executive": 80,
    "manager": 60,
    "analyst": 40,
    "user": 20,
}

ROLE_SCOPES: Dict[str, List[str]] = {
    "admin": ["*"],
    "executive": ["*"],
    # إصلاح: كانت "audit" و"investment" غائبتين تمامًا هنا رغم أن راوتات
    # audit.py/investment.py تسمح لـ manager فأعلى فعليًا (require_min_role("manager")).
    # هذا لم يكن يسبب مشكلة سابقًا فقط لأن authorize() لم تكن تُستدعى من أي مكان -
    # الآن بعد ربطها في ai_bridge.run_agent_task (انظر أدناه)، لا بد من إضافتهما هنا
    # وإلا كانت ستحجب وصول manager الشرعي المسموح به فعليًا على مستوى الراوت.
    "manager": ["finance", "inventory", "production", "accounting", "hr", "marketing", "revenue", "audit", "investment"],
    "analyst": ["finance", "inventory", "accounting", "revenue", "marketing", "production"],
    "user": ["inventory", "hr"],
}

RESTRICTED_COMMAND_TYPES = {
    "fraud_detection", "audit", "investment_analysis",
    "budget_optimization", "train_agent", "delete_user",
}


class RateLimiter:
    """محدد معدل الطلبات - نافذة منزلقة في الذاكرة (fallback عند غياب Redis)"""

    def __init__(self):
        self._hits: Dict[str, deque] = defaultdict(deque)

    def allow(self, key: str, max_requests: int, window_seconds: int) -> bool:
        now = time.monotonic()
        bucket = self._hits[key]

        while bucket and now - bucket[0] > window_seconds:
            bucket.popleft()

        if len(bucket) >= max_requests:
            return False

        bucket.append(now)
        return True


class SecurityManager:
    """مدير الأمان"""

    def __init__(self):
        key = settings.ENCRYPTION_KEY.encode()
        if len(key) < 32:
            key = key.ljust(32, b"0")[:32]
            logger.warning("ENCRYPTION_KEY تم تمديده إلى 32 بايت - يُنصح بشدة بتعيين مفتاح 32 بايت حقيقي في .env")

        self.encryption_key = base64.urlsafe_b64encode(key[:32])
        self.cipher = Fernet(self.encryption_key)
        self.active_sessions: Dict[str, Dict] = {}
        self.rate_limiter = RateLimiter()

    async def initialize(self):
        """تهيئة مدير الأمان"""
        logger.info("🔒 تهيئة مدير الأمان...")
        if settings.JWT_SECRET in ("change-me-in-production", ""):
            logger.warning(
                "⚠️ JWT_SECRET لا يزال بالقيمة الافتراضية! غيّره فورًا في .env قبل أي نشر إنتاجي."
            )

    async def authorize(self, command: Any) -> bool:
        """التحقق الفعلي من الصلاحيات (RBAC) بدل إرجاع True دائمًا"""
        role = getattr(command, "role", None)
        user_id = getattr(command, "user_id", None)

        if not user_id or user_id == "anonymous":
            logger.warning("🚫 رفض تفويض: لا يوجد مستخدم موثّق (user_id مفقود أو anonymous)")
            return False

        if role is None:
            role = await self._lookup_user_role(user_id)

        if not role:
            logger.warning(f"🚫 رفض تفويض: تعذر تحديد دور المستخدم {user_id}")
            return False

        command_type = getattr(command, "type", "")
        department = (getattr(command, "department", "") or "").lower()

        if command_type in RESTRICTED_COMMAND_TYPES and ROLE_HIERARCHY.get(role, 0) < ROLE_HIERARCHY["manager"]:
            logger.warning(f"🚫 رفض: الدور '{role}' لا يملك صلاحية تنفيذ أمر حساس '{command_type}'")
            return False

        scopes = ROLE_SCOPES.get(role, [])
        if "*" in scopes:
            return True

        if department and department not in scopes:
            logger.warning(f"🚫 رفض: الدور '{role}' لا يملك صلاحية الوصول لقسم '{department}'")
            return False

        return True

    async def _lookup_user_role(self, user_id: str) -> Optional[str]:
        """جلب دور المستخدم الفعلي من قاعدة البيانات"""
        try:
            from database.session import AsyncSessionLocal
            from database.models import User
            from sqlalchemy import select

            async with AsyncSessionLocal() as session:
                result = await session.execute(select(User.role).where(User.id == user_id))
                row = result.first()
                return row[0] if row else None
        except Exception as e:
            logger.error(f"خطأ أثناء جلب دور المستخدم: {e}")
            return None

    def hash_password(self, password: str) -> str:
        return pwd_context.hash(password)

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        return pwd_context.verify(plain_password, hashed_password)

    def create_access_token(self, data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
        to_encode = data.copy()
        expire = datetime.utcnow() + (expires_delta or timedelta(hours=settings.JWT_EXPIRY_HOURS))
        to_encode.update({"exp": expire, "type": "access"})
        return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)

    def create_refresh_token(self, data: Dict[str, Any]) -> str:
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(days=settings.JWT_REFRESH_EXPIRY_DAYS)
        to_encode.update({"exp": expire, "type": "refresh"})
        return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)

    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        try:
            payload = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
            return payload
        except JWTError:
            return None

    def encrypt_data(self, data: str) -> str:
        return self.cipher.encrypt(data.encode()).decode()

    def decrypt_data(self, encrypted: str) -> str:
        return self.cipher.decrypt(encrypted.encode()).decode()

    def generate_mfa_secret(self) -> str:
        return pyotp.random_base32()

    def verify_mfa(self, secret: str, code: str) -> bool:
        totp = pyotp.TOTP(secret)
        return totp.verify(code)

    def check_rate_limit(self, key: str, max_requests: int = None, window: int = None) -> bool:
        """التحقق الفعلي من حد الطلبات (نافذة منزلقة في الذاكرة)"""
        max_requests = max_requests or settings.RATE_LIMIT_REQUESTS
        window = window or settings.RATE_LIMIT_WINDOW
        return self.rate_limiter.allow(key, max_requests, window)

    async def shutdown(self):
        logger.info("🔒 إيقاف مدير الأمان")
