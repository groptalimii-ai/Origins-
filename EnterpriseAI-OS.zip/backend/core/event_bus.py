#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Event Bus
ناقل الأحداث
"""

import asyncio
import json
import logging
from typing import Dict, List, Callable, Any, Optional
from datetime import datetime

from aiokafka import AIOKafkaProducer, AIOKafkaConsumer
try:
    from aiokafka.errors import KafkaError
except ImportError:  # احتياط لتغيّر اسم/مسار الاستثناء بين إصدارات aiokafka
    KafkaError = Exception
from core.config import settings
from core.models import DomainEvent

logger = logging.getLogger(__name__)

# إصلاح: عدد محاولات إعادة الاتصال بـ Kafka عند الإقلاع، وفاصل الانتظار بينها.
# كان الاتصال إلزامياً وبلا أي إعادة محاولة: أي فشل عابر (Kafka لم يُقلع بعد داخل
# docker-compose، مهلة زمنية، ...) كان يُسقط EnterpriseEngine.initialize() بالكامل،
# وبالتالي يمنع إقلاع تطبيق FastAPI بأكمله (lifespan فشل = لا يبدأ الخادم إطلاقاً)،
# رغم أن EventBus غير حرج لعمل أي ميزة فعلية حالياً في المشروع.
_CONNECT_MAX_ATTEMPTS = 5
_CONNECT_RETRY_SECONDS = 3


class EventBus:
    """ناقل أحداث Kafka-based"""

    def __init__(self):
        self.producer: Optional[AIOKafkaProducer] = None
        self.consumers: Dict[str, AIOKafkaConsumer] = {}
        self.subscribers: Dict[str, List[Callable]] = {}
        self.event_store: List[Dict] = []
        self.connected = False

    async def connect(self):
        """
        الاتصال بـ Kafka - يعيد المحاولة عدة مرات، وإن استمر الفشل يستمر التطبيق
        في العمل بدون Kafka (self.connected=False) بدل إسقاط الإقلاع بالكامل.
        publish()/subscribe() ستتجاهل الطلب بأمان (مع تحذير في اللوق) طالما
        connected=False، بدل رفع استثناء غير متوقَّع لمستدعيها.
        """
        if self.connected:
            return

        logger.info("🔗 الاتصال بـ Kafka...")

        for attempt in range(1, _CONNECT_MAX_ATTEMPTS + 1):
            try:
                self.producer = AIOKafkaProducer(
                    bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                    value_serializer=lambda v: json.dumps(v, default=str).encode("utf-8"),
                    key_serializer=lambda k: k.encode("utf-8") if k else None
                )
                await self.producer.start()
                self.connected = True
                logger.info("✅ تم الاتصال بـ Kafka")
                return
            except (KafkaError, OSError, asyncio.TimeoutError) as e:
                logger.warning(
                    f"⚠️ فشلت محاولة الاتصال بـ Kafka رقم {attempt}/{_CONNECT_MAX_ATTEMPTS}: {e}"
                )
                self.producer = None
                if attempt < _CONNECT_MAX_ATTEMPTS:
                    await asyncio.sleep(_CONNECT_RETRY_SECONDS)

        logger.error(
            "❌ تعذّر الاتصال بـ Kafka بعد عدة محاولات — سيستمر التطبيق بدون ناقل "
            "أحداث (نشر/اشتراك الأحداث سيُتجاهَل بأمان حتى إعادة المحاولة لاحقاً)."
        )
        self.connected = False

    async def disconnect(self):
        """قطع الاتصال"""
        if self.producer:
            await self.producer.stop()
        for consumer in self.consumers.values():
            await consumer.stop()
        self.connected = False
        logger.info("🔌 تم قطع الاتصال بـ Kafka")

    async def publish(self, event: DomainEvent, topic: Optional[str] = None):
        """نشر حدث - إصلاح: يتجاهل النشر بأمان (تحذير في اللوق) بدل رفع استثناء
        عند عدم توفر Kafka، حتى لا تفشل عمليات المستدعي (مثل process_command)
        بسبب مكوّن غير حرج للوظائف الفعلية الحالية."""
        if not self.connected:
            logger.warning(f"⚠️ تجاهل نشر الحدث {event.event_type} - EventBus غير متصل بـ Kafka")
            self.event_store.append(event.serialize())
            return

        topic = topic or f"{settings.KAFKA_TOPIC_PREFIX}.{event.aggregate_type}"

        # تخزين في Event Store
        event_data = event.serialize()
        self.event_store.append(event_data)

        # نشر لـ Kafka
        await self.producer.send(
            topic=topic,
            value=event_data,
            key=event_data.get("aggregate_id")
        )

        logger.debug(f"📤 حدث منشور: {topic} - {event_data.get('event_type')}")

    async def subscribe(self, topic: str, handler: Callable):
        """الاشتراك في موضوع - إصلاح: يتجاهل بأمان إن كان Kafka غير متصل"""
        if not self.connected:
            logger.warning(f"⚠️ تجاهل الاشتراك في {topic} - EventBus غير متصل بـ Kafka")
            return

        if topic not in self.subscribers:
            self.subscribers[topic] = []

            # إنشاء مستهلك جديد
            consumer = AIOKafkaConsumer(
                topic,
                bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                value_deserializer=lambda v: json.loads(v.decode("utf-8")),
                group_id=f"enterpriseai-{topic}",
                auto_offset_reset="latest"
            )
            await consumer.start()
            self.consumers[topic] = consumer

            # بدء مهمة الاستماع
            asyncio.create_task(self._consume(topic, consumer))

        self.subscribers[topic].append(handler)
        logger.info(f"👂 اشتراك جديد: {topic}")

    async def _consume(self, topic: str, consumer: AIOKafkaConsumer):
        """استهلاك الرسائل"""
        try:
            async for message in consumer:
                event_data = message.value
                handlers = self.subscribers.get(topic, [])
                for handler in handlers:
                    try:
                        await handler(event_data)
                    except Exception as e:
                        logger.error(f"Error in handler for {topic}: {e}")
        except Exception as e:
            logger.error(f"Consumer error for {topic}: {e}")

    async def get_events(self, aggregate_id: str, limit: int = 100) -> List[Dict]:
        """الحصول على أحداث لمجموع معين"""
        events = [
            e for e in self.event_store
            if e.get("aggregate_id") == aggregate_id
        ]
        return events[-limit:]