#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Audit Logger
مسجل التدقيق
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional

from core.config import settings

logger = logging.getLogger(__name__)


def _is_uuid(value: Any) -> bool:
    if not value or not isinstance(value, str):
        return False
    import uuid
    try:
        uuid.UUID(value)
        return True
    except (ValueError, AttributeError):
        return False


class AuditLogger:
    """مسجل التدقيق"""

    def __init__(self):
        self.log_buffer = []
        self.buffer_size = 100
        # إصلاح: تفريغ دوري كل 30 ثانية بجانب عتبة الـ100 سجل، حتى لا تبقى
        # سجلات تدقيق قليلة عالقة في الذاكرة لفترة طويلة في نظام بحركة منخفضة.
        self._flush_interval_seconds = 30
        self._flush_task: Optional[asyncio.Task] = None
        self._running = False

    async def initialize(self):
        """تهيئة مسجل التدقيق"""
        logger.info("📝 تهيئة مسجل التدقيق...")
        self._running = True
        self._flush_task = asyncio.create_task(self._periodic_flush())

    async def _periodic_flush(self):
        try:
            while self._running:
                await asyncio.sleep(self._flush_interval_seconds)
                if self.log_buffer:
                    await self._flush_buffer()
        except asyncio.CancelledError:
            pass

    async def log_command_start(self, command: Any):
        """تسجيل بداية الأمر"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": "command_started",
            "command_id": command.id,
            "command_type": command.type,
            "user_id": command.user_id,
            "department": command.department,
        }
        await self._write_log(log_entry)

    async def log_command_complete(self, command: Any):
        """تسجيل إكمال الأمر"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": "command_completed",
            "command_id": command.id,
            "command_type": command.type,
            "user_id": command.user_id,
            "status": command.status.value,
            "result_summary": str(command.result)[:200] if command.result else None,
        }
        await self._write_log(log_entry)

    async def log_command_failed(self, command: Any, error: Exception):
        """تسجيل فشل الأمر"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": "command_failed",
            "command_id": command.id,
            "command_type": command.type,
            "user_id": command.user_id,
            "error": str(error),
            "error_type": type(error).__name__,
        }
        await self._write_log(log_entry)

    async def log_ai_decision(self, agent_name: str, decision: Dict[str, Any], user_id: str):
        """تسجيل قرار الذكاء الاصطناعي"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": "ai_decision",
            "agent": agent_name,
            "decision_type": decision.get("type"),
            "user_id": user_id,
            "confidence": decision.get("confidence"),
            "explanation": decision.get("explanation", "")[:500],
        }
        await self._write_log(log_entry)

    async def log_security_event(self, event_type: str, details: Dict[str, Any], severity: str = "info"):
        """تسجيل حدث أمان"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event": "security",
            "event_type": event_type,
            "severity": severity,
            "details": details,
        }
        await self._write_log(log_entry)

    async def _write_log(self, entry: Dict[str, Any]):
        """كتابة السجل"""
        self.log_buffer.append(entry)
        if len(self.log_buffer) >= self.buffer_size:
            await self._flush_buffer()

    async def _flush_buffer(self):
        """تفريغ المخزن المؤقت - كتابة فعلية في جدول audit_logs"""
        if not self.log_buffer:
            return

        entries = self.log_buffer
        self.log_buffer = []

        for entry in entries:
            logger.info(f"AUDIT: {entry}")

        try:
            from database.session import AsyncSessionLocal
            from database.models import AuditLog

            async with AsyncSessionLocal() as session:
                for entry in entries:
                    session.add(AuditLog(
                        event_type=entry.get("event", "unknown"),
                        user_id=entry.get("user_id") if _is_uuid(entry.get("user_id")) else None,
                        resource_type=entry.get("command_type") or entry.get("agent"),
                        resource_id=entry.get("command_id"),
                        action=entry.get("event_type") or entry.get("event"),
                        new_value=entry,
                    ))
                await session.commit()
        except Exception as e:
            # لا نريد أن يوقف فشل الكتابة في قاعدة البيانات تدفق التطبيق،
            # لكن يجب تسجيله بوضوح لأنه فقدان بيانات تدقيق
            logger.error(f"⚠️ فشل حفظ سجلات التدقيق في قاعدة البيانات: {e}")

    async def shutdown(self):
        """إيقاف مسجل التدقيق - إصلاح: كانت هذه الدالة معشّشة خطأً (بمشكلة إزاحة)
        داخل الدالة المستقلة _is_uuid()، أي أنها لم تكن عضواً في هذا الكلاس إطلاقاً،
        فكان استدعاء self.audit_logger.shutdown() في core/engine.py يرفع
        AttributeError عند كل إيقاف نظيف للتطبيق، وتبقى أي سجلات تدقيق عالقة
        في الذاكرة (أقل من buffer_size) تُفقد نهائياً بدل أن تُكتب لقاعدة البيانات."""
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        await self._flush_buffer()
        logger.info("📝 إيقاف مسجل التدقيق")
