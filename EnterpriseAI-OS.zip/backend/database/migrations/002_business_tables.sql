-- EnterpriseAI-OS - Business Tables
-- الجداول التشغيلية التي تعتمد عليها وكلاء الذكاء الاصطناعي والـ API
-- (كانت مفقودة بالكامل في الإصدار الأولي رغم أن الكود يفترض وجودها)
--
-- ملاحظة إصلاح: هذا الملف هو المصدر الوحيد المعتمد لتعريف transactions/inventory_items/
-- employees الآن (كانت 001_initial_schema.sql تُعرّف نفس الأسماء بأعمدة مختلفة تماماً
-- فتفوز بصمت بسبب ترتيب التنفيذ، تاركة كل استعلامات الوكلاء وواجهات API تفشل على أعمدة
-- غير موجودة). يجب أن يُنفَّذ هذا الملف بعد 001 دائماً (يعتمد على users عبر created_by).

-- === Finance ===
CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    date TIMESTAMP NOT NULL DEFAULT NOW(),
    amount DECIMAL(15,2) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('income','expense')),
    category VARCHAR(50),
    vendor VARCHAR(255),
    vendor_first_seen TIMESTAMP,
    department VARCHAR(50),
    description TEXT,
    created_by UUID REFERENCES users(id),
    is_flagged BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);

CREATE TABLE IF NOT EXISTS invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','paid','overdue')),
    due_date TIMESTAMP,
    issued_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS budgets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    department VARCHAR(50) NOT NULL,
    period VARCHAR(20) NOT NULL,
    allocated DECIMAL(15,2) NOT NULL,
    spent DECIMAL(15,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

-- === Inventory ===
CREATE TABLE IF NOT EXISTS inventory_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    quantity_on_hand INTEGER DEFAULT 0,
    reorder_point INTEGER DEFAULT 0,
    reorder_quantity INTEGER DEFAULT 0,
    unit_cost DECIMAL(15,2) DEFAULT 0,
    lead_time_days INTEGER DEFAULT 7,
    supplier VARCHAR(255),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS inventory_movements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL,
    movement_type VARCHAR(20) NOT NULL CHECK (movement_type IN ('sale','restock','adjustment')),
    date TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_inv_move_sku_date ON inventory_movements(sku, date);

-- === Production ===
CREATE TABLE IF NOT EXISTS production_orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_sku VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL,
    status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_progress','done','delayed')),
    machine_id VARCHAR(50),
    scheduled_start TIMESTAMP,
    scheduled_end TIMESTAMP,
    defect_rate FLOAT DEFAULT 0.0,
    created_at TIMESTAMP DEFAULT NOW()
);

-- === HR ===
CREATE TABLE IF NOT EXISTS employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    full_name VARCHAR(255) NOT NULL,
    department VARCHAR(50),
    position VARCHAR(100),
    salary DECIMAL(15,2),
    hire_date TIMESTAMP,
    performance_score FLOAT,
    is_active BOOLEAN DEFAULT TRUE
);

-- === Marketing ===
CREATE TABLE IF NOT EXISTS campaigns (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    channel VARCHAR(50),
    budget DECIMAL(15,2) DEFAULT 0,
    spend DECIMAL(15,2) DEFAULT 0,
    impressions INTEGER DEFAULT 0,
    clicks INTEGER DEFAULT 0,
    conversions INTEGER DEFAULT 0,
    start_date TIMESTAMP,
    end_date TIMESTAMP
);

-- === Investment ===
CREATE TABLE IF NOT EXISTS investment_opportunities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    expected_return FLOAT,
    risk_level VARCHAR(20) CHECK (risk_level IN ('low','medium','high')),
    initial_cost DECIMAL(15,2),
    horizon_years FLOAT,
    status VARCHAR(20) DEFAULT 'proposed',
    created_at TIMESTAMP DEFAULT NOW()
);

-- === Seed: بيانات تجريبية كافية لكي تعمل التنبؤات والتحليلات من أول تشغيل ===
INSERT INTO inventory_items (sku, name, quantity_on_hand, reorder_point, reorder_quantity, unit_cost, lead_time_days, supplier)
VALUES
    ('SKU-1001', 'مادة خام أ', 120, 50, 200, 15.50, 5, 'مورد الشمال'),
    ('SKU-1002', 'مادة خام ب', 30, 40, 150, 8.75, 10, 'مورد الجنوب'),
    ('SKU-1003', 'منتج نهائي جاهز', 500, 100, 300, 42.00, 3, 'مصنع داخلي')
ON CONFLICT (sku) DO NOTHING;
