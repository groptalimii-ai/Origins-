"""المخطط الأولي + الجداول التشغيلية (موحّدة بعد حل تعارض 001/002)

ملاحظة إصلاح: لم يكن يوجد أي ملف ترحيل Alembic فعلي في المشروع سابقاً —
مجلد migrations/ كان يحوي env.py + ملفي SQL خام فقط بلا مجلد versions/
وبلا أي "revision script"، فكان أمر `alembic upgrade head` (المستخدَم في
scripts/setup.sh) ينجح ظاهرياً بدون فعل أي شيء إطلاقاً. هذا الملف يجعل
`alembic upgrade head` يعمل فعلياً بتنفيذ نفس مخطط 001+002 (بعد إصلاح
تعارضهما) عبر Alembic الحقيقي، بدل الاعتماد فقط على تهيئة Docker
لحاوية Postgres عند أول تشغيل (docker-entrypoint-initdb.d) والتي لا
تعمل خارج Docker أو بعد أول تشغيل.

Revision ID: 0001
Revises:
Create Date: 2026-08-08
"""
from pathlib import Path

from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

_MIGRATIONS_DIR = Path(__file__).resolve().parent.parent
_SQL_FILES_IN_ORDER = [
    "001_initial_schema.sql",
    "002_business_tables.sql",
]


def upgrade() -> None:
    for filename in _SQL_FILES_IN_ORDER:
        sql_text = (_MIGRATIONS_DIR / filename).read_text(encoding="utf-8")
        # تنفيذ الملف كسكربت واحد (psycopg2 يدعم تعدد العبارات المفصولة بـ ; في exec)
        op.get_bind().exec_driver_sql(sql_text)


def downgrade() -> None:
    # تراجع مبسّط: حذف كل الجداول التي أنشأتها هذه المراجعة، بترتيب عكسي لتفادي كسر FKs.
    tables = [
        "investment_opportunities", "campaigns", "employees", "production_orders",
        "inventory_movements", "inventory_items", "budgets", "invoices", "transactions",
        "audit_logs", "ai_decisions", "events", "departments", "users",
    ]
    for table in tables:
        op.get_bind().exec_driver_sql(f"DROP TABLE IF EXISTS {table} CASCADE")
