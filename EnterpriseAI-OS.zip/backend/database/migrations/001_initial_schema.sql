-- EnterpriseAI-OS Database Schema
-- مخطط قاعدة البيانات

-- ملاحظة إصلاح حرجة (راجع تقرير الفحص):
-- 1) أُزيل CREATE EXTENSION "vector" وجدولا knowledge_nodes/knowledge_edges:
--    صورة postgres:16-alpine القياسية المستخدمة في docker-compose.full.yml لا تتضمن
--    امتداد pgvector، فكان هذا السطر يُسقط تنفيذ سكربت التهيئة بالكامل من أول سطر
--    (لا يُنشأ حتى جدول users)، ولا يوجد أي كود في المشروع يستخدم هذين الجدولين أصلاً.
-- 2) أُزيلت تعريفات transactions/inventory_items/employees من هنا لأنها كانت تتعارض
--    مع التعريفات الصحيحة (المطابقة لـ database/models.py وكل استعلامات الوكلاء) في
--    002_business_tables.sql. كان هذا الملف يُنشئ هذه الجداول أولاً بأعمدة مختلفة تماماً،
--    فتفشل عبارات "CREATE TABLE IF NOT EXISTS" في 002 بصمت (الجدول موجود مسبقاً)،
--    ويترك التطبيق يستعلم أعمدة غير موجودة فعلياً. التعريف الوحيد المعتمد الآن لهذه
--    الجداول هو في 002_business_tables.sql.
-- 3) أُزيل إدخال المدير الافتراضي الوهمي (كانت قيمة password_hash نصاً حرفياً '$2b$12$...'
--    وليست تجزئة bcrypt حقيقية، فلا يمكن تسجيل الدخول بها أبداً). أول مستخدم يُنشأ الآن
--    فعلياً عبر backend/scripts/create_superuser.py بعد إصلاحه.
-- 4) صُححت أنواع أعمدة audit_logs (resource_id, ip_address) لتطابق database/models.py
--    (كانت UUID/INET بينما الكود يمرر أحياناً قيماً نصية غير UUID مثل معرّفات المهام).

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'user',
    department VARCHAR(50),
    mfa_secret VARCHAR(255),
    mfa_enabled BOOLEAN DEFAULT FALSE,
    ai_preferences JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Departments
CREATE TABLE departments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,
    manager_id UUID REFERENCES users(id),
    budget_limit DECIMAL(15,2),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Events (Event Sourcing)
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    aggregate_id UUID NOT NULL,
    aggregate_type VARCHAR(100) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    metadata JSONB,
    version INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_events_aggregate ON events(aggregate_id, version);
CREATE INDEX idx_events_type ON events(event_type, created_at);

-- AI Decisions
CREATE TABLE ai_decisions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_type VARCHAR(50) NOT NULL,
    decision_type VARCHAR(100) NOT NULL,
    input_data JSONB,
    output_data JSONB,
    confidence FLOAT,
    explanation TEXT,
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Audit Log
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(100) NOT NULL,
    user_id UUID REFERENCES users(id),
    resource_type VARCHAR(100),
    resource_id VARCHAR(100),
    action VARCHAR(50),
    old_value JSONB,
    new_value JSONB,
    ip_address VARCHAR(64),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_audit_user ON audit_logs(user_id, created_at);
CREATE INDEX idx_audit_resource ON audit_logs(resource_type, resource_id);
