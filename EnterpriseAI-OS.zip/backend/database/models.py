#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - SQLAlchemy ORM Models
نماذج قاعدة البيانات الفعلية (تطابق المايجريشن SQL)
"""

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey, Integer,
    Numeric, String, Text, JSON
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


def gen_uuid():
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    name = Column(String(255), nullable=False)
    role = Column(String(50), nullable=False, default="user")
    department = Column(String(50), nullable=True)
    mfa_secret = Column(String(255), nullable=True)
    mfa_enabled = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Department(Base):
    __tablename__ = "departments"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    name = Column(String(100), nullable=False)
    code = Column(String(20), unique=True, nullable=False)
    manager_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)
    budget_limit = Column(Numeric(15, 2), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Transaction(Base):
    """حركات مالية - أساس التنبؤ المالي وكشف الاحتيال"""
    __tablename__ = "transactions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    date = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    amount = Column(Numeric(15, 2), nullable=False)
    type = Column(String(20), nullable=False)  # income | expense
    category = Column(String(50), nullable=True)
    vendor = Column(String(255), nullable=True)
    vendor_first_seen = Column(DateTime, nullable=True)
    department = Column(String(50), nullable=True)
    description = Column(Text, nullable=True)
    created_by = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)
    is_flagged = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Invoice(Base):
    __tablename__ = "invoices"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    invoice_number = Column(String(50), unique=True, nullable=False)
    customer_name = Column(String(255), nullable=False)
    amount = Column(Numeric(15, 2), nullable=False)
    status = Column(String(20), default="pending")  # pending|paid|overdue
    due_date = Column(DateTime, nullable=True)
    issued_at = Column(DateTime, default=datetime.utcnow)


class Budget(Base):
    __tablename__ = "budgets"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    department = Column(String(50), nullable=False)
    period = Column(String(20), nullable=False)  # e.g. 2026-08
    allocated = Column(Numeric(15, 2), nullable=False)
    spent = Column(Numeric(15, 2), default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class InventoryItem(Base):
    __tablename__ = "inventory_items"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    sku = Column(String(100), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    quantity_on_hand = Column(Integer, default=0)
    reorder_point = Column(Integer, default=0)
    reorder_quantity = Column(Integer, default=0)
    unit_cost = Column(Numeric(15, 2), default=0)
    lead_time_days = Column(Integer, default=7)
    supplier = Column(String(255), nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class InventoryMovement(Base):
    """حركة مخزون (بيع/استلام) - أساس التنبؤ بالطلب"""
    __tablename__ = "inventory_movements"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    sku = Column(String(100), nullable=False, index=True)
    quantity = Column(Integer, nullable=False)  # موجب استلام، سالب بيع
    movement_type = Column(String(20), nullable=False)  # sale|restock|adjustment
    date = Column(DateTime, default=datetime.utcnow, index=True)


class ProductionOrder(Base):
    __tablename__ = "production_orders"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    product_sku = Column(String(100), nullable=False)
    quantity = Column(Integer, nullable=False)
    status = Column(String(20), default="scheduled")  # scheduled|in_progress|done|delayed
    machine_id = Column(String(50), nullable=True)
    scheduled_start = Column(DateTime, nullable=True)
    scheduled_end = Column(DateTime, nullable=True)
    defect_rate = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class Employee(Base):
    __tablename__ = "employees"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)
    full_name = Column(String(255), nullable=False)
    department = Column(String(50), nullable=True)
    position = Column(String(100), nullable=True)
    salary = Column(Numeric(15, 2), nullable=True)
    hire_date = Column(DateTime, nullable=True)
    performance_score = Column(Float, nullable=True)
    is_active = Column(Boolean, default=True)


class Campaign(Base):
    __tablename__ = "campaigns"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    name = Column(String(255), nullable=False)
    channel = Column(String(50), nullable=True)
    budget = Column(Numeric(15, 2), default=0)
    spend = Column(Numeric(15, 2), default=0)
    impressions = Column(Integer, default=0)
    clicks = Column(Integer, default=0)
    conversions = Column(Integer, default=0)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)


class InvestmentOpportunity(Base):
    __tablename__ = "investment_opportunities"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    name = Column(String(255), nullable=False)
    expected_return = Column(Float, nullable=True)
    risk_level = Column(String(20), nullable=True)  # low|medium|high
    initial_cost = Column(Numeric(15, 2), nullable=True)
    horizon_years = Column(Float, nullable=True)
    status = Column(String(20), default="proposed")
    created_at = Column(DateTime, default=datetime.utcnow)


class AIDecision(Base):
    __tablename__ = "ai_decisions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    agent_type = Column(String(50), nullable=False)
    decision_type = Column(String(100), nullable=False)
    input_data = Column(JSON, nullable=True)
    output_data = Column(JSON, nullable=True)
    confidence = Column(Float, nullable=True)
    explanation = Column(Text, nullable=True)
    approved_by = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    event_type = Column(String(100), nullable=False)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)
    resource_type = Column(String(100), nullable=True)
    resource_id = Column(String(100), nullable=True)
    action = Column(String(50), nullable=True)
    old_value = Column(JSON, nullable=True)
    new_value = Column(JSON, nullable=True)
    ip_address = Column(String(64), nullable=True)
    user_agent = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
