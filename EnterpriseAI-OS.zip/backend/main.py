#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Main Application
نظام إدارة المؤسسات المتكامل بالذكاء الاصطناعي
"""

import asyncio
import logging
import uuid
from datetime import datetime
from contextlib import asynccontextmanager
from typing import Dict, Any

from fastapi import FastAPI, Request, WebSocket, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from core.config import settings
from core.event_bus import EventBus
from core.security import SecurityManager
from core.audit import AuditLogger
from api.routes import router as api_router
from api.websocket import websocket_manager
from api.dependencies import get_security_manager, oauth2_scheme, enforce_rate_limit
from ai_engine.orchestrator import AIOrchestrator
from database.session import check_database_health, init_models

# إعداد التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# === نماذج Pydantic ===
class AIQuery(BaseModel):
    query: str
    agent_type: str
    department: str
    context: Dict[str, Any] = {}


class TrainingData(BaseModel):
    training_data: list
    epochs: int = 10


# === دوال فحص الصحة (فحوصات فعلية - كانت TODO ثابتة على "healthy" دائمًا) ===
async def check_database() -> str:
    """فحص قاعدة البيانات - يجري استعلام SELECT 1 فعليًا"""
    try:
        healthy = await check_database_health()
        return "healthy" if healthy else "unhealthy"
    except Exception as e:
        logger.error(f"Database health check error: {e}")
        return "unhealthy"


async def check_redis() -> str:
    """فحص Redis - اتصال فعلي وأمر PING"""
    try:
        import redis.asyncio as aioredis
        client = aioredis.from_url(settings.REDIS_URL, socket_connect_timeout=2)
        pong = await client.ping()
        await client.aclose()
        return "healthy" if pong else "unhealthy"
    except Exception as e:
        logger.error(f"Redis health check error: {e}")
        return "unhealthy"


async def check_ai_engine() -> str:
    """فحص محرك الذكاء الاصطناعي - يتحقق من أن الوكلاء تمت تهيئتهم فعليًا"""
    try:
        orchestrator: AIOrchestrator = app.state.ai_orchestrator
        if orchestrator and orchestrator.initialized and len(orchestrator.agents) > 0:
            return "healthy"
        return "unhealthy"
    except Exception as e:
        logger.error(f"AI engine health check error: {e}")
        return "unhealthy"


@asynccontextmanager
async def lifespan(app: FastAPI):
    """إدارة دورة حياة التطبيق"""
    # بدء التشغيل
    logger.info("🚀 EnterpriseAI-OS يبدأ التشغيل...")

    # إصلاح: شبكة أمان لإنشاء الجداول من database/models.py إن لم تُطبَّق الترحيلات
    # (alembic upgrade head) بعد لأي سبب — create_all لا يمس الجداول الموجودة فعلاً
    # (checkfirst افتراضياً)، فهي آمنة للتشغيل في كل إقلاع بلا خطر إتلاف بيانات.
    try:
        await init_models()
    except Exception as e:
        logger.error(f"⚠️ تعذّر التحقق/إنشاء جداول قاعدة البيانات تلقائياً: {e}")

    # إصلاح (الجولة الخامسة): أُزيلت EnterpriseEngine بالكامل من دورة حياة التطبيق.
    # كانت كودًا معماريًا (نمط CQRS: Command/EventBus) لا يستدعيه أي راوت في المشروع
    # فعليًا (process_command غير مستخدَمة إطلاقًا) - أي أن AuditLogger وSecurityManager
    # داخلها كانا معطَّلين تمامًا رغم إصلاحهما في الجولة الثالثة، وكانت تفتح اتصال Kafka
    # ثانٍ منفصل ومكرر عن app.state.event_bus أدناه (اتصالان بـ Kafka عند كل إقلاع
    # بلا داعٍ). الآن يُهيَّأ AuditLogger مباشرة ويُربط فعليًا بمسارات أمنية حقيقية
    # (فشل تسجيل الدخول، رفض الصلاحيات) بدل أن يبقى محاصرًا داخل طبقة غير مستخدَمة.
    app.state.audit_logger = AuditLogger()
    await app.state.audit_logger.initialize()

    # تهيئة منسق الذكاء الاصطناعي
    app.state.ai_orchestrator = AIOrchestrator()
    await app.state.ai_orchestrator.initialize()

    # تهيئة ناقل الأحداث
    app.state.event_bus = EventBus()
    await app.state.event_bus.connect()

    logger.info("✅ EnterpriseAI-OS جاهز للعمل!")

    yield

    # الإغلاق
    logger.info("🛑 EnterpriseAI-OS يتم إيقافه...")
    await app.state.ai_orchestrator.shutdown()
    await app.state.event_bus.disconnect()
    await app.state.audit_logger.shutdown()
    logger.info("✅ تم الإيقاف بنجاح")


# إنشاء التطبيق
app = FastAPI(
    title="EnterpriseAI-OS",
    description="نظام إدارة المؤسسات المتكامل بالذكاء الاصطناعي",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# === Middleware ===
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(GZipMiddleware, minimum_size=1000)


@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    """إضافة ترويسات الأمان"""
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'self'"
    return response


@app.middleware("http")
async def log_requests(request: Request, call_next):
    """تسجيل الطلبات"""
    start_time = asyncio.get_event_loop().time()
    response = await call_next(request)
    process_time = asyncio.get_event_loop().time() - start_time

    logger.info(
        f"{request.method} {request.url.path} - {response.status_code} - {process_time:.3f}s"
    )
    return response


# === Routes ===
# تطبيق حد معدل طلبات فعلي على كل الـ API (كان check_rate_limit يرجع True دائمًا سابقًا)
app.include_router(api_router, prefix="/api/v1", dependencies=[Depends(enforce_rate_limit)])


# === Health Check ===
@app.get("/health")
async def health_check():
    """فحص صحة النظام"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {
            "database": await check_database(),
            "redis": await check_redis(),
            "ai_engine": await check_ai_engine(),
        }
    }


@app.get("/")
async def root():
    """الصفحة الرئيسية"""
    return {
        "name": "EnterpriseAI-OS",
        "version": "1.0.0",
        "description": "نظام إدارة المؤسسات المتكامل بالذكاء الاصطناعي",
        "docs": "/docs",
        "health": "/health"
    }


# === WebSocket ===
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, token: str = ""):
    """نقطة اتصال WebSocket - تتطلب الآن JWT صالح عبر ?token=... (لم تكن محمية سابقًا)"""
    security = get_security_manager()
    payload = security.verify_token(token) if token else None

    if not payload or payload.get("type") != "access":
        await websocket.close(code=4401)
        return

    await websocket_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            await websocket_manager.handle_message(websocket, data)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        await websocket_manager.disconnect(websocket)


# ملاحظة: نقاط نهاية /api/v1/ai/* لم تعد مُعرَّفة هنا مباشرة.
# كانت في الإصدار السابق تمرر user_id="anonymous" بشكل ثابت بلا أي مصادقة،
# وتسمح لأي شخص بتدريب الوكلاء دون تحقق من الهوية. تم نقلها بالكامل إلى
# api/routes/ai.py حيث تتطلب الآن JWT حقيقي وصلاحيات RBAC (انظر get_current_user / require_min_role).


# === Error Handlers ===
# إصلاح معماري (مراجعة جودة الكود): كان المعالج العام يُعيد str(exc) مباشرةً
# بحقل "message" للعميل - أي استثناء غير متوقَّع (IntegrityError من SQLAlchemy
# يكشف أسماء الأعمدة/القيود، KeyError يكشف بنية القاموس الداخلي، مسارات ملفات
# ضمن رسائل بعض الاستثناءات، إلخ) كان يصل حرفيًا للواجهة الأمامية ولأي عميل خارجي.
# التفاصيل الكاملة (exc_info=True) تبقى في سجلات الخادم فقط للتشخيص، بينما
# العميل يستلم رسالة عامة ثابتة + request_id قابل للربط بسجل الخادم عند الحاجة
# للدعم الفني - بلا أي تفاصيل داخلية.
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """معالج الأخطاء العام - لا يُسرّب أي تفاصيل استثناء داخلية للعميل أبداً"""
    request_id = str(uuid.uuid4())
    logger.error(
        f"Global error [request_id={request_id}] {request.method} {request.url.path}: {exc}",
        exc_info=True,
    )
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": "حدث خطأ غير متوقع أثناء معالجة الطلب. تم تسجيل الحادثة للمراجعة.",
            "request_id": request_id,
        },
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        workers=4 if not settings.DEBUG else 1
    )
