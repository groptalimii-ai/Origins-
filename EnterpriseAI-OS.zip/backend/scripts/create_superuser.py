#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EnterpriseAI-OS - Create Superuser
إنشاء أول مستخدم مدير (admin) فعلياً في قاعدة البيانات.

إصلاح: كان هذا السكربت سابقاً يطبع رسالة نجاح وهمية بعد `# TODO` دون أن يكتب
أي شيء فعلياً في قاعدة البيانات، ولم تكن هناك أي وسيلة أخرى لإنشاء أول حساب
صالح للدخول (صف المدير المزروع في migrations/001 كان بتجزئة كلمة مرور وهمية
غير قابلة للتحقق). الآن يُنشئ المستخدم فعلياً عبر AsyncSessionLocal بنفس آلية
تجزئة كلمة المرور المستخدمة في auth.py (bcrypt عبر SecurityManager).
"""

import asyncio
import getpass
import sys
from pathlib import Path

# للسماح بتشغيل السكربت مباشرة (python backend/scripts/create_superuser.py)
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select  # noqa: E402

from database.session import AsyncSessionLocal  # noqa: E402
from database.models import User  # noqa: E402
from core.security import SecurityManager  # noqa: E402


async def create_superuser():
    print("👤 إنشاء المستخدم الأول (مدير النظام)")
    print("=" * 50)

    email = input("البريد الإلكتروني: ").strip()
    name = input("الاسم الكامل: ").strip()
    password = getpass.getpass("كلمة المرور: ")
    confirm = getpass.getpass("تأكيد كلمة المرور: ")

    if not email or not name:
        print("❌ البريد الإلكتروني والاسم مطلوبان!")
        return

    if password != confirm:
        print("❌ كلمات المرور غير متطابقة!")
        return

    if len(password) < 8:
        print("❌ كلمة المرور يجب أن تكون 8 أحرف على الأقل!")
        return

    security = SecurityManager()

    async with AsyncSessionLocal() as session:
        existing = await session.execute(select(User).where(User.email == email))
        user = existing.scalar_one_or_none()

        if user:
            # المستخدم موجود مسبقاً - تحديثه ليصبح admin بكلمة المرور الجديدة
            # بدل الفشل الصامت أو إنشاء تكرار يخالف قيد UNIQUE على email.
            user.password_hash = security.hash_password(password)
            user.name = name
            user.role = "admin"
            user.is_active = True
            await session.commit()
            print(f"✅ تم تحديث المستخدم الموجود إلى مدير (admin): {email}")
        else:
            user = User(
                email=email,
                password_hash=security.hash_password(password),
                name=name,
                role="admin",
                department="executive",
                is_active=True,
            )
            session.add(user)
            await session.commit()
            print(f"✅ تم إنشاء المستخدم المدير: {email}")

    print("🚀 يمكنك الآن تسجيل الدخول إلى النظام عبر /api/v1/auth/login")


if __name__ == "__main__":
    asyncio.run(create_superuser())
